x = 20 
y = 20 
z = 0 and 20 
print (z)

x = 0 
y = 20 
z = 10 or 20 
print (z)

x = "apple"
y = " "
z = "apple" or " "
print (z)

x = " "
y = "mango"
z = "apple" or "mango"
print (z)

print (0 or 20)
print (10 or 20)
print ("apple" or " ")
print (" " or "apple")
print ("apple" or "mango")

print (not "orange")
print (not 0)
print (not 10)

print (6 and 18)
print (False and True)
print (1,2 & 1.5)
print ("war" & "love")


print (6 and 18)
print (False and true)
print (1,2 & 1.5)
print ("war" & "love")

print("AND 3&5 :", 3&5)
print("OR 3|5 :", 3 | 5)
print("EX OR 3^5 : ",3 ^ 5)
print("COMPLEMENT ~4: ", ~4)
print("Left Shift 10:", 10<<2)
print ("Right Shift 10>>2 :", 10>> 2)


print ("AND 3&5 :", 3&5)
print ("OR 3|5 :", 3 | 5)
print ("EX OR 3^5 :", 3 ^ 5)
print ("COMPLIMENT ~4 :", ~4)
print ("Left Shift 10:", 10<2)
print ("Right Shift 10>>2:", 10>>2)



