a = ['hari','amita','madhu','nethra']
b = ['methra','hari','madhu','amita']
print("Lists that have the same"
        "elements in the different order", a == b)

a = ['Hari','amita','madhu','nethra']
b = ['Hari','amita','madhu','nethra']
print("Lists that have the same"
        "elements in same order", a == b)

