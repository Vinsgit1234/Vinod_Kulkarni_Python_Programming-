s = "Python" + "Programming"
print(s)
s = "Python" + "3"
print(s)
s = "Python"+ 3
Print(s)

s = "Python" + "Programming"
print (s)
s = "Python" + "3"
print(s)
s = "Python" + 3
Print(s)

s = "Python" + "Programming"
print (s)
s = "Python" + "3"
print(s)
s = "Python" + 3
Print(s)

s = "Python" + "Programming"
print (s)
s = "Pyhton" + "3"
print(s)
s = "Python" + 3
Print(s)





