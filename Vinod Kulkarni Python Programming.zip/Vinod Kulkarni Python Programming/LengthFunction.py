Tuple = (12,24,36,48)
print("Length of the tuple = ",len(Tuple))

Tuple = (12,24,36,48)
print("Length of the tuple = ",len(Tuple))

Tuple = (12,24,36,48)
print("Length of the tuple = ",len(Tuple))

