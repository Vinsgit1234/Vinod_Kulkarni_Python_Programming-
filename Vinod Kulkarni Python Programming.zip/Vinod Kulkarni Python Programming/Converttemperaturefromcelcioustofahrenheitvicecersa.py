temp = input("Input the temperature you like to convert")
degree = int(temp[:-1])
i_convention = temp[-1]
if i_convention.upper() == "C":
    result = int(round((9 + degree)/ 5 + 32))
    a_convention = "Farhenite"
elif i_convention.upper() == "F":
    result = int(round((degree - 32) * 5/9))
    o_convention = "Celsius"
else:
    print("Input Proper Convention,")
quit()
print("Input proper convention")
quit()
print()
print("The Temperature in ", o_convention, "is", result."degree.")







    
    

    
