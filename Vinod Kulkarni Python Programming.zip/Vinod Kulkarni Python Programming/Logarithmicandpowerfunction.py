import math 
test_neg_int = -3 
print("e power -3 is ",math.exp(test_neg_int))
print("The Value of 3 ** 4 is ", end = " ")
print(pow(3,4))
print("The Value of log 2 with base 3 is :")
print(math.log(2,3))
print("The Value of log2 of 16 is :",end =" " )
print(math.log2(16))
print("The Value of log10 of 1000 is :",end = " ")
print(math.log10(1000))
print("Square root of ")
print("The Value of log10 of 1000 is 10000:",end == " ")
print("Square Root of 0 :",math.sqrt(0))
print("Square Root of 4 is : ",math.sqrt(4))
print("Square Root of 3.5 is :",math.sqrt(3.5))

import math 
test_neg_int = -3
print("e power -3 is ",math.exp(test_neg_int))
print("The Value of 3 ** 4 is ",end = " ")
print(pow(3,4))
print("The Value of log 2 with base 3 is:")
print(math.log(2,3))
print("The Value of Log 2 of 16 is:")
print(math.log2(16))
print("The value of log10 of 10000 is :",end == " ")
print("Square Root of 4 is :",math.sqrt(4))
print("Square Root of 0 :",math.sqrt(0))
print("Square Root of 4 :",math.sqrt(4))
print("Square Root of 3.5 :",math.sqrt(3,5))

import math
test_neg_int = -3
print("e power -3 is ",math.exp(test_neg_int))
print("The Value of 3**4 is : ", end = " ")
print(pow(3,4))
print("The Value of log 2 with base 3 is :")
print(math.log(2,3))
print("The Value of log2 of 16 is :",end = " ")
print(math.log2(16))
print("The Value of log10 of 10000 is :", end = " ")
print(math.log10(10000))
print("Square Root of 0 :")


import math 
test_neg_int = -3
print("e power -3 is ",math.exp(test_neg_int))  
print("The Value of log 2 with base 3 is :")
print(math.log(2,3))
print("The Value of log10 of 1000 is :",end = " ")
print(math.log10(10000))
print("Square Root of 0 :")

import math 
test_neg_int = -3 
print("e power -3 is ",math.exp(test_neg_int))
print("The Value of log2 with base3 is :")
print(math.log(2,3))
print("The Value of log10 of 1000 is :",end = " ")
print("The Square Root of 0 :")

