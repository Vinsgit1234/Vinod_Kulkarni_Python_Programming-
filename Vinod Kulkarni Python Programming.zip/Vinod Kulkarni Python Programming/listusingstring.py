fruit = list('Apple')
print("Converting string to list",fruit)
data = list(range(0,10,2))
print("List using range Function",data)

fruit = list('Apple')
print("Converting string to list",fruit)
data = list(range(0,10,2))
print("List Using Range Function",data)

