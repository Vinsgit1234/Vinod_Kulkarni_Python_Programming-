print("Computer")
print ("Computer Science")


print ("Computer")
print ("Computer Science")

print ("Computer")
print ("Computer Science")

print ("Computer")
print ("Computer Science")




