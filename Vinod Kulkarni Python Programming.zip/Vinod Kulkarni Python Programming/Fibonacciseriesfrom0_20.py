num1 =1
num2 =  2
print("Fibonacci Series")
for i in range(10):
    print(num1, end =" ")
    res = num1 + num2 
    num1 = num2
    num2 = res 
    
    
num1 = 1
num2 = 2
print("Fibonacci Series")
for i in range(10):
    print(num1, end =" ")
    res = num1 + num2 
    num1 = num2
    num2 = res    