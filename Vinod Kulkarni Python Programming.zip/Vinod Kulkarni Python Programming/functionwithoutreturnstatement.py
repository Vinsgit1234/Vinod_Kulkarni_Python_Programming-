def evenodd(x):
    if(x%2==0):
        print("Given number is even")
    else:
        print("Given number is Even")
        
evenodd(2)
evenodd(3)
evenodd(4)

def evenodd(x):
    if(x%2==0):
        print("Given number is even")
    else:
        print("Given number is Even")
        
evenodd(2)
evenodd(3)
evenodd(4)