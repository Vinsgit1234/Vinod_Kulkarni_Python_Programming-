x = 0 
y = 20 
0 and 20 

x = 0
y = 0
0 and 20 

x = 0 
y = 20 
0 and 20 

