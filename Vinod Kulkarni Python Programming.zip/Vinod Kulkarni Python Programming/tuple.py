Tuple = (19)
print(type(Tuple))
Tuple = 18
print(type(Tuple))
Tuple = (13,)
print(type(Tuple))
Tuple = 13
print(type(Tuple))

Tuple = (19)
print(type(Tuple))
Tuple = 18
print(type(Tuple))
Tuple = (13,)
print(type(Tuple))
Tuple = 13
print(type(Tuple))

Tuple = (19)
print(type(Tuple))
Tuple = 18
print(type(Tuple))
Tuple = (13,)
print(type(Tuple))
Tuple = 13
print(type(Tuple))


