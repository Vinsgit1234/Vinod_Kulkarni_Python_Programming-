list = [10,20,30,40,50,60,70]
print("Original list =",list)
print("Element at 1st position =",list[0])
print("Element at 2nd position=",list[1])
print("Element at 3rd position=",list[2])
print("Element at 3rd position=",list[3])
print("Element at -1 place =",list[-1])
print("Element at -3 place =",list[-3])

list = [10,20,30,40,50,60,70]
print("Original list =",list)
print("Element at 1st position=",list[0])
print("Element at 2nd position=",list[1])
print("Element at 3rd position=",list[2])
print("Element at 4th position=",list[3])
print("Element at -1 place =",list[-1])

list = [10,20,30,40,50,60,70]
print("Original list =",list)
print("Element at 1st position=",list[0])
print("Element at 2nd Position=",list[1])
print("Element at 3rd position=",list[2])
print("Element at 4th position=",list[3])
print("Element at -1 place =",list[4])

