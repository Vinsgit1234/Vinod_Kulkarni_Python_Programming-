list1 = [1,2,3,5,4,8,7,9]
temp_list = list1[:]
list.sort()
if temp_list == list1:
    print("Given List is in Ascending Order")
else:
    print("Given List is Not in Ascending Order")
    
list1 = [1,2,3,5,4,8,7,9]
temp_list = list1[:]
list.sort()
if temp_list == list1:
    print("Given List is in Ascending Order")
else:
    print("Given List is Not in Ascending Order")
    
list1 = [1,2,3,5,4,8,7,9]
temp_list = list1[:]
list.sort()
if temp_list == list1:
    print("Given List is in Ascending Order")
else:
    print("Given List is Not in Ascending Order")
    
list1 = [1,2,3,5,4,8,7,9]
temp_list = list1[:]
list.sort()
if temp_list == list1:
    print("Given List is in Ascending Order")
else:
    print("Given List in Not in Ascending Order")
    
list1 = [1,2,3,5,4,8,7,9]
temp_list = list1[:]
list.sort()
if temp_list == list1:
    print("Given List is in Ascending Order")
else:
    print("Given List in Not in Ascending Order")
    
list1 = [1,2,3,5,4,8,7,9]
temp_list = list1[:]
list.sort()
if temp_list == list1:
    print("Given List is in Ascending Order")
else:
    print("Given List in Not in Ascending Order")
    
list1 = [1,2,3,5,4,8,7,9]
temp_list = list1[:]
list.sort()
if temp_list == list1:
    print("Given List is in Ascending Order")
else:
    print("Given List in Not in Ascending Order")
    
list1 = [1,2,3,5,4,8,7,9]    
temp_list = list1[:]
list.sort()
if temp_list == list1:
    print("Given List is in Ascending Order")
else:
    print("Given List in Not in Ascending Order")
    
list1 = [1,2,3,5,4,8,7,9]
temp_list = list1[:]
list.sort()
if temp_list == list1:
    print("Given List is in Ascending Order")
else:
    print("Given List in Not in Ascending Order")
    
list1 = [1,2,3,5,4,8,7,9]
temp_list = list1[:]
list.sort()
if temp_list == list1:
    print("Given List is in Ascending Order")
else:
    print("Given List is Not in Ascending Order")
    
list1 = [1,2,3,5,4,8,7,9]
temp_list = list1[:]
list.sort()
if temp_list == list1:
    print("Given List is in Ascending Order")
else:
    print("Given List is Not in Ascending Order")
    
list1 = [1,2,3,5,4,8,7,9]
temp_list = list1[:]
list.sort()
if temp_list == list1:
    print("Given List is in Ascending Order")
else:
    print("Given List is Not in Ascending Order")
    
list1 = [1,2,3,5,4,8,7,9]
temp_list = list1[:]
list.sort()
if temp_list == list1:
    print("Given List is in Ascending Order")
else:
    print("Given List is Not in Ascending Order")
    
