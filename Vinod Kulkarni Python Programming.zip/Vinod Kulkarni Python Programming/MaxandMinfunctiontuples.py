Tuple1 = (35,21,60,20)
print("Maximum element=",max(Tuple1))
print("Mninimum element=",min(Tuple1))

Tuple1 = (35,21,60,20)
print("Maximum Element=",max(Tuple1))
print("Minimum Element=",min(Tuple1))

Tuple1 = (35,21,60,20)
print("Maximum Element=",max(Tuple1))
print("Minimum Element=",min(Tuple1))

Tuple1 = (35,21,60,20)
print("Maximum Element=",max(Tuple1))
print("Minimum Element=",min(Tuple1))

Tuple1 = (35,21,60,20)
print("Maximum Element=",max(Tuple1))
print("Minimum Element=",min(Tuple1))








