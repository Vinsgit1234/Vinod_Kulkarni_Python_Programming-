print("Python"[::-1])

print("Python"[::-1])

print("Python"[::-1])

print("Python"[::-1])

