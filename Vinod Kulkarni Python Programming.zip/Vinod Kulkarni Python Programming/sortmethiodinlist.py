lis = [2,1,3,5,3,8]
print("Original List:",lis)
lis.sort()
print("List after sorting:",lis)

lis = [2,1,3,5,3,8]
print("Original List:",lis)
lis.sort()
print("List after sorting:",lis)

lis = [2,1,3,5,3,8]
print("Original List:",lis)
lis.sort()
print("List after sorting:",lis)

lis = [2,1,3,5,3,8]
print("Original List:",list)
lis.sort()
print("List after sorting:",lis)

lis = [2,1,3,5,3,8]
print("Original List:",list)
lis.sort()
print("List after sorting:",lis)

lis = [2,1,3,5,3,8]
print("Original List:",list)
lis.sort()
print("List after sorting:",lis)

lis = [2,1,3,5,3,8]
print("Original List:",list)
lis.sort()
print("List after sorting:",lis)

lis = [2,1,3,5,3,8]
print("Original List:",list)
lis.sort()
print("List after sorting:",lis)

lis = [2,1,3,5,3,8]
print("Original List:",list)
lis.sort()
print("List after sorting:",lis)

lis = [2,1,3,5,3,8]
print("Original List:",list)
lis.sort()
print("List after sorting:",lis)

lis = [2,1,3,5,3,8]
print("Original List:",list)
lis.sort()
print("List after sorting:",lis)

lis = [2,1,3,5,3,8]
print("Original List:",list)
lis.sort()
print("List after sorting:",lis)

lis = [2,1,3,5,3,8]
print("Original List:",list)
lis.sort()
print("List after sorting:",lis)

lis = [2,1,3,5,3,8]
print("Original List:",lis)
lis.sort()
print("List after sorting:",lis)

lis = [2,1,3,5,3,8]
print("Original List:",list)
lis.sort()
print("List after sorting:",lis)

lis = [2,1,3,5,3,8]
print("Original List:",list)
lis.sort()
print("List after sorting:",lis)

lis = [2,1,3,5,3,8]
print("Original List:",list)
lis.sort()
print("List after sorting:",lis)

lis = [2,1,3,5,3,8]
print("Original List:",list)
lis.sort()
print("List after Sorting:",lis)

lis = [2,1,3,5,3,8]
print("Original List:",list)
lis.sort()
print("List after Sorting:",lis)

lis = [2,1,3,5,3,8]
print("Original List:",list)
lis.sort()
print("List after Sorting:",lis)

