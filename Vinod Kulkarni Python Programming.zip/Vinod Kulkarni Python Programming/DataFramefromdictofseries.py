import pandas as pd 
d = {'one': pd.Series([1,2,3],
    index = ['a','b','c','d']),
    'two' : pd.Series([1,2,3,4],
    index = ['a','b','c','d'])}
df = pd.Dataframe(d)
print(df)

import pandas as pd 
s = pd.Series(data = [1,2,3,4,5,6,7,8,8,5,3])
print('Original Data Series')
print(s)
print("Mean of the sale Data Series")
print(s.mean())
print("Standard Deviation of Said Data Series")
print(s.std())

import pandas as pd 
s = pd.Series(data = [1,2,3,4,5,6,7,8,8,5,3])
print('Original Data Series')
print(s)
print("Mean of the sale Data Series")
print(s.mean())
print("Standard Deviation of Said Data Series")
print(s.std())

import pandas as pd 
s = pd.Series(data = [1,2,3,4,5,6,7,8,8,5,3])
print('Original Data Series')
print(s)
print("Mean of the Sale Data Series")
print(s.mean())
print("Standard Deviation of Said Data Series")
print(s.std())

import pandas as pd 
s = pd.Series(data = [1,2,3,4,5,6,7,8,8,5,3])
print('Original Data Series')
print(s)
print("Mean of the Sale Data Series")
print(s.mean())
print("Standard Deviation of Said Data Series")
print(s.std())

