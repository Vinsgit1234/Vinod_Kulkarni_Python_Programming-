x, y = 4, 3 
result = x * x + 2 * x * x + y * y 
print ("({} + {}) ^ 2) = {}".
    format((x , y, result)))
    
x , y = 4, 3 
result = x * x + 2 * x * x + y * y 
print ("({} + {}) ^ 2) = {}". 
    format((x , y, result)))
    
x , y = 4, 3
result = x * x + 2 * x * x + y * y
print ("({}) + {}) ^ 2) = {}".
       format((x, y, result)))
       

       
    

    
    
    
    