List = [1,2,3,4,5,6,7,8,9,10,11,12]
print("Initial List")
List.remove(5)
List.remove(6)
print("\n List after Removal of Two Elements")
print(List)
for i in range(1,5):
    List.remove(i)
print("\n List after removing the range of elements")
print(List)

