class multiplicationforloop:
    x = int(input("Enter a number: "))
    i = 0
    for i in range(1,11):
        print(f"{x} * {i} = {x * i}")