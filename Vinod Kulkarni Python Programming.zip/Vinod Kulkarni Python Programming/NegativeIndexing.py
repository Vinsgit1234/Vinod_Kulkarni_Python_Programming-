tuple1 = {10,20,30,40,50}
print("Element at -1 Place = ",tuple[-1])
print("Element at -4 place = ",tuple[-4])
print("Element from -3 to -1 place =",tuple[-3,-1])
print("Excluding last Element =",tuple[-1])
print("Last two elements=",tuple[-2])

tuple1 = {10,20,30,40,50}
print("Element at -1 Place = ",tuple[-1])
print("Element at -4 place = ",tuple[-4])
print("Element from -3 to -1 place =",tuple[-3,-1])
print("Excluding last Element =",tuple[-1])
print("Last two elements=",tuple[-2])

tuple1 = {10,20,30,40,50}
print{"Element at -1 Place = ",tuple[-1]}
print("Element at -4 place = ",tuple[-4])
print("Element from -3 to -1 place = ",tuple[-3,-1])
print("Excluding last Element =",tuple[-1])

tuple = {10,20,30,40,50}
print{"Elements at -1 Place =",tuple[-1]}
print("Element at -4 Place =",tuple[-4])
print("Element from -3 to -1 place = ",tuple[-3,-1])
print("Excluding last Element = ",tuple[-1])

