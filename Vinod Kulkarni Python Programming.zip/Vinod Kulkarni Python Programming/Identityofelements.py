a= 50 
print ("reference of a :", id(a))
b= a 
print ("reference of b :", id (b))
b = 100
print ("reference of b :" id (b))

a = 50 
print ("reference of a :", id (a))
b = a 
print ("reference of b:", id (b))
b = 100 
print ("reference of b:", id (b))

a= 50
print ("reference of a is :", id (a))
b = a 
print ("reference of b:", id (b))
b = 100 
print ("reference of b:", id (b))



