a = 0 * 123 
print ("Value of a : " , a)
a = 0 * 1556 
print ("Value of a : " , a)
a = 0 * face
print ("Value of a : " , a)
a = 0 * beef 
print ("Value of a : " , a) 
