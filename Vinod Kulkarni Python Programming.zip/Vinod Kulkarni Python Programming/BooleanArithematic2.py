A = True
B = False
C = A or B
D = A and B
F =  not B
G = not A
print (C)
print (D)
print (F)
print (G)




A 



 
