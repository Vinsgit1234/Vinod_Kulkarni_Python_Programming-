numberlist = [15,85,35,89,125,2]
minNum = numberList[0]
for num in numberList:
    if minNum == num
print(minNum)