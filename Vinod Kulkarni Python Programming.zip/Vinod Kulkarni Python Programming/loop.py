for i in range(5):
    print(i)

c = 0
while c < 5:
    print(c)
    c += 1
    
    
for i in range(5):
    print(i)
    
c = 0 
while c < 5:
    c += 1 
    
