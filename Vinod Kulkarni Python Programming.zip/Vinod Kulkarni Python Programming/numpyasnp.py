import numpy as np 
in_array = [-5,1.5,2.5,3.5,4.5,10.1]
print("Input array : \n, in_array")
rintoff_values = np.rint(in_array)
print("Rounded Values : \n",rintoff_values)
in_array = [.53, 1.54, 71]

