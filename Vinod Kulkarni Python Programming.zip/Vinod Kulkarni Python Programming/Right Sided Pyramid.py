print("\n Right sided Pyramid")
for i in range(5):
    x ='*'
    x = x*i
    print(f'{x:<10}')

print("\n Right Sided Pyramid")
for i in range(5):
    x = '*'
    x = x*i
    print(f'{x:<10}')

