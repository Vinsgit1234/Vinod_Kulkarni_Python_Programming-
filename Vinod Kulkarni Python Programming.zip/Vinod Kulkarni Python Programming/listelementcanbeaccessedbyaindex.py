a = ['apple','banana','grapes','oranges','mint']
print("Element at 0th Index",a[0])
print("Element at 2nd Index",a[2])
print("Element at 4th Index",a[4])
print("Element at -1 Index",a[-1])
print("Element at -2 Index",a[-2])

a = ['apple','banana','grapes','oranges','mint']
print("Element at 0th Index",a[0])
print("Element at 2nd Index",a[2])
print("Element at 4th Index",a[4])
print("Element at -1 Index",a[-1])
print("Element at -2 Index",a[-2])

a = ['apple','banana','grapes','oranges','mint']
print("Element at 0th Index",a[0])
print("Element at 2nd Index",a[2])
print("Element at 4th Index",a[4])
print("Element at -1 Index",a[-1])
print("Element at -2 Index",a[-2])

