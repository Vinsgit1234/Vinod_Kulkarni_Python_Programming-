new_list = ['Hari','Anitha', 'Madhu','Poornima']
output = {val: x+1 for x, val in enumerate(new_list)}
print("After index keys :" + str(output))

new_list = ['Hari','Anitha','Madhu','Poornima']
index_key = "Wed"
out = list(my_dict.items())
new_value = [x for x,key in enumerate(out) if key[0] = index_key]
print("Index of Search Key is :"+str(new_value))

new_list = ['Hari','Anitha','Madhu','Poornima']
index_key = "Wed"
out = list(my_dict.items())
new_value = [x for x,key in enumerate(out) if key[0] = index_key]
print("Index of Search Key is :"+str(new_value))

