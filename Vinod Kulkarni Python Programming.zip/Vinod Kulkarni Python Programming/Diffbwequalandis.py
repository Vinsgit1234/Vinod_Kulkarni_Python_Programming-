a = [10,20,30]
b = [10,20,30]
print ("a == b : ", a==b)
print ("a is b : ", a is b)

a = [10,20,30]
b = [10,20,30]
print ("a == b : ", a==b)
print ("a is b :", a is b)

a = [10, 20, 30 ]
b = [10,20,30]
print ("a == b : ", a==b)
print ("a is b :", a is b)

a = [ 10 , 20, 30 ]
b = [10 ,20, 30]
print (" a ==b :", a==b)
print ("a is b:", a is b)

a = [10 , 20, 30 ]
b = [10, 20, 30]
print ("a == b: ", a == b )
print (" a is b:",a is b)

a = [10, 20, 30]
b = [10, 20, 30]
print (" a==b : ", a == b)
print ("a is b:",a is b)

a = [10, 20, 30]
b = [10, 20, 30]
print (" a == b : ", a==b)
print ("a is b", a is b)

a = [10, 20, 30]
b = [10, 20, 30]
print (" a == b :", a ==b)
print ("a is b", a is b)

a = [10, 20, 30]
b = [10, 20, 30]
print ("a == b :", a == b)
print ( "a is b", a is b)

a = [10, 20, 30]
b = [10, 20, 30]
print ("a == b :",a == b)
print ("a is b", a is b)

