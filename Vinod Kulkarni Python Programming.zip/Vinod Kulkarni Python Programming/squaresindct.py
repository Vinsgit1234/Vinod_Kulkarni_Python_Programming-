squares = {}
for x in range(6):
    squares[x]= x*x
print(squares)

squares = {}
for x in range(6):
    squares[x] = x*x
print(squares)

squares = {}
for x in range(6):
    squares[x] = x*x
print(squares)

squares = {}
for x in range(6):
    squares[x] = x*x
print(squares)

