tuple = (10,20,30,10,40,10)
print("number 10 appeared for = " , tuple.count(10),"times")


tuple = (10,20,30,10,40,10)
print("Number 10 appeared for = ", tuple.count(10),"times")

tuple = (10,20,30,10,40,10)
print("Number 10 appeared for =",tuple.count(10),"times")

tuple = (10,20,30,10,40,10)
print("Number 10 appeared for =",tuple.count(10),"times")

tuple = (10,20,30,10,40,10)
print("Number 10 appeared for =",tuple.count(10),"times")

tuple = (10,20,30,10,40,10)
print("Number 10 appeared for =",tuple.count(10),"times")

tuple = (10,20,30,10,40,10)
print("Number 10 appeared for =",tuple.count(10),"times") 

tuple = (10,20,30,10,40,10)
print("Number 10 appeared for =",tuple.count(10),"times") 

tuple = (10,20,30,10,40,10)
print("Number 10 appeared for =",tuple.count(10),"times") 

tuple = (10,20,30,10,40,10)
print("Number 10 appeared for =",tuple.count(10),"times") 

tuple = (10,20,30,10,40,10)
print("Number 10 appeared for =",tuple.count(10),"times") 

tuple = (10,20,30,10,40,10)
print("Number 10 appeared for =",tuple.count(10),"times") 

tuple = (10,20,30,10,40,10)
print("Number 10 appeared for =",tuple.count(10),"times")

tuple = (10,20,30,10,40,10)
print("Number 10 appeared for =",tuple.count(10),"times")

tuple = (10,20,30,10,40,10)
print("Number 10 appeared for =",tuple.count(10),"times")

    