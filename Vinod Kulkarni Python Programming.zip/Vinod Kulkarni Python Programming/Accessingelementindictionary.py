Dict = {1:'Computer','name':'For','3:''Science'}
print("Accessing an Element using key")
print(Dict('name'))
print("Accessing an Element Using the Key:")
print(Dict[1])

Dict = {1:'Computer','name':'For','3:''Science'}
print("Accessing an Element using key")
print(Dict('name'))
print("Accessing an Element Using the Key:")
print(Dict('name')
print("Accessing an Element Using the Keys:")
print(Dict[1])

Dict = {1:'Computer','name':'For','3:''Science'}
print("Accessing an Element using Key")
print(Dict(('name'))
print("Accessing an Element Using the Key:")
print(Dict('name'))
print("Accessing an Element Using the Keys:")
print(Dict[1])

Dict = {1:'Computer','name':'For','3:','Science'}
print("Accessing an Element using Key")
print(Dict(('name')))
print("Accessing an Element Using The Key:")
print(Dict('name'))
print("Accessing an Element Using the Keys:")
print(Dict[1])

Dict = {1:'Computer','name':'For','3:','Science'}
print("Accessing an Element using Key")
print(Dict(('name')))
print("Accessing an Element Using The Key:")
print(Dict('name'))
print("Accessing an Element Using the Keys:")
print(Dict[1])

Dict = {1:'Computer','Name':'For','3:','Science'}
print("Accessing an Element using Key")
print(Dict(('name')))
print("Accessing an Element Using The Key:")
print(Dict('Name'))
print("Accessing an Element Using The Keys:")
print(Dict[1])

Dict = {1:'Computer','Name':'For','3:','Science'}
print("Accessing an Element using Key")
print(Dict(('name')))
print("Accessing an Element Using The Key:")
print(Dict('Name'))
print("Accessing An Element Using The Keys:")
print(Dict[1])

