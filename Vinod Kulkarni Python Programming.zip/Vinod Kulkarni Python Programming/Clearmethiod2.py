lis = [2,1,3,5,3,8]
print("Original List :",lis)
lis.clear()
print("List after executing clear:",lis)

lis = [2,1,3,5,3,8 ]
print("Original List :",lis)
lis.clear()
print("List after executing clear:",lis)

lis = [2,1,3,5,3,8]
print("Original List :",lis)
lis.clear()
print("List after executing clear:",lis)

lis = [2,1,3,5,3,8]
print("Original List :",lis)
lis.clear()
print("List after executing clear:",lis)

lis = [2,1,3,5,3,8]
print("Original List :",lis)
lis.clear()
print("List after executing clear:",lis)

lis = [2,1,3,5,3,8]
print("Original List :",lis)
lis.clear()
print("List after executing clear:",lis)

lis = [2,1,3,5,3,8]
print("Original List :",lis)
lis.clear()
print("List after executing clear:",lis)

lis = [2,1,3,5,3,8]
print("Original List :",lis)
lis.clear()
print("List after executing clear:",lis)

lis = [2,1,3,5,3,8]
print ("Original List :",lis)
lis.clear()
print("List after executing clear:",lis)

lis = [2,1,3,5,3,8]
print ("Original List :",lis)
lis.clear()
print("List after executing clear:",lis)

lis = [2,1,3,5,3,8]
print("Original List :",lis)
lis.clear()
print("List after Executing clear:",lis)

lis = [2,1,3,5,3,8]
print("Original List :",lis)
lis.clear()
print("List after Executing clear:",lis)

lis = [2,1,3,5,3,8]
print("Original List :",lis)
lis.clear()
print("List after Executing clear:",lis)

lis = [2,1,3,5,3,8]
print("Original List :",lis)
lis.clear()
print("List after Executing Clear:",lis)

lis = [2,1,3,5,3,8]
print("Original List :",lis)
lis.clear()
print("List After Execution Clear:",lis)

lis = [2,1,3,5,3,8]
print("Original List:",lis)
lis.clear()
print("List After Execution Clear:",lis)

lis = [2,1,3,5,3,8]
print("Original List :",lis)
lis.clear()
print("List After Execution Clear:",lis)

lis = [2,1,3,5,3,8]
print("Original List:",lis)
lis.clear()
print("List After Execution Clear:",lis)

