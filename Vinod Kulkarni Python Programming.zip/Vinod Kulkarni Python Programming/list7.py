List = ['P','Y','T','H','O','N','P','R','O','G','R','A','M']
print("Initial List:",List)
Sliced_List = List[3:8]
print("\nSlicing element in a range 3-8:")
print(Sliced_List)
Sliced_List = List[5:]
print("\n Elements sliced from 5th"
      "element till the end:")
print(Sliced_List)
Sliced_List = List[:]
print("\n Printing all the elements using slice operation:")
print(Sliced_List)


List = ['P','Y','T','H','O','N','P','R','O','G','R','A','M']
print("Initial List:",List)
Sliced_List = List[3:8]
print("\nSlicing element in a range 3-8:")
print(Sliced_List)
Sliced_List = List[5:]
print("\n Elements sliced from 5th"
      "element till the end:")
print(Sliced_List)
Sliced_List = List[:]
print("\n Printing all the elements using slice operation:")
print(Sliced_List)
