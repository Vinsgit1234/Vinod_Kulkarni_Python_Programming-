def fun():
    str = "Computer Science"
    x = 20 
    return str, x;
str, x = fun()
print("String Value :",str)
print("Integer Value :",x)

def fun():
    str = "Computer Science"
    x = 20 
    return str, x;
str, x = fun()
print("String Value :",str)
print("Integer Value :",x)

def fun():
    str = "Computer Science"
    x = 20 
    return str, x;
str, x = fun()
print("String Value :",str)
print("Integer Value :",x)