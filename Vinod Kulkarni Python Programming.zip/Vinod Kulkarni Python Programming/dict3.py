my_dict = {"m",1,"l":2,"n":7}
new_key = list(my_dict)
index_k = new_key[0]
print("Key at index 0 :",index_k)
index_key = new_key[2]
print("Key at Index 2:",index_key)

my_dict = {"m",1,"1":2,"n":7}
new_key = list(my_dict)
index_k = new_key[0]
print("Key at index 0 :",index_k)
index_key = new_key[2]
print("Key at Index 2:",index_key)

my_dict = {"m",1,"1":"2","n":7}
new_key = list(my_dict)
index_k = new_key[0]
print("Key at index 0 :",index_k)
index_key = new_key[2]
print("Key at Index 2:",index_key)

