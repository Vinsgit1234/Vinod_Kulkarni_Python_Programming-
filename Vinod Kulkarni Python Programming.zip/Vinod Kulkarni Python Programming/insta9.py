nums = [3,1,3,1,5]
res = max(nums) - min(nums)
print(res)

