from import * 
array_num = array ('i',[3,1,3,5,3,7,9,3])
print("Original array :\n" +str(array_num))
print("Number of occurances of the Number"
      "n3 in the said array:"
      +str(array_num.count(3)))

from import * 
array_num = array ('i',[3,1,3,5,3,7,9,3])
print("Original array :\n" +str(array_num))
print("Number of occurance of the Number"
      "n3 in the said array:"
      +str(array_num.count(3)))

