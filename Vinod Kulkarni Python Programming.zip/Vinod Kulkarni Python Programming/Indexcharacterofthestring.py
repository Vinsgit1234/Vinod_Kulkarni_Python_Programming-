def reverse_string_words(text):
    for line in text.split('/n')
    return(' '.join(line.split())[::-1])
