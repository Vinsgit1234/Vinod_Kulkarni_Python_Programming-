def create_adder (x):
    def adder(y):
        return x + y 
    return adder 
add_15 = create_adder(15)
print("The result is :", add_15(10))


    
    