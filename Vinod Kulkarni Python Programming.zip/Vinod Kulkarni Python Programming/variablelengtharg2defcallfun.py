def sum(*number):
    total=0
    for x in number:
        total=total+x
        print("The sum:",total)
    
sum()
sum(10)
sum(10,20)
sum(10,20,30)
    
