print ("Python")
print (type("Python"))


print ("Python")
print (type("Python"))

print ("Python")
print (type("Python"))

