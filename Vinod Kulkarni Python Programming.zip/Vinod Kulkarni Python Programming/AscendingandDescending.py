import operator
d = {1: 2, 3: 4, 4: 3, 2:1, 0: 0}
print('Original Dictionary:',d)
sorted_d = sorted(d.items(),key=operator.itemgetter(1))
print("Dictionary in ascending order by Value :",sorted_d)
sorted_d = dict(sorted(d.items(), key=operator.itemgetter(1),reverse=True))
print('Dictionary in Descending order by value :',sorted_d)

import operator
d = {1: 2, 3: 4, 4:3, 2:1, 0:0}
print('Original Dictionary :',d)
sorted_d = sorted(d.items(),key=operator.itemgetter(1))
print('Dictionary in Descending Order By Value :',sorted_d)
sorted_d = sorted(d.items(),key=operator.itemgetter(1))
print("Dictionary in ascending order by Value :",sorted_d)
sorted_d = dict(sorted(d.items(), key=operator.itemgetter(1),reverse=True))
print('Dictionary in Descending order by value :',sorted_d)

