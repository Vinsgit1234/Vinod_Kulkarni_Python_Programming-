Tuple = (45,55,65)
New_Tuple = Tuple*3
print(New_Tuple)

Tuple = (45,55,65)
New_Tuple = Tuple*3
print(New_Tuple)

Tuple = (45,55,65)
New_Tuple = Tuple*3
print(New_Tuple)

Tuple = (45,55,65)
New_Tuple = Tuple*3
print(New_Tuple)

Tuple = (45,55,65)
New_Tuple = Tuple*3
print(New_Tuple)

Tuple = (45,55,65)
New_Tuple = Tuple*3
print(New_Tuple)

