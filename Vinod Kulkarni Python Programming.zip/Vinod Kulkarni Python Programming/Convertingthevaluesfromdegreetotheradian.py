import math 
a = math.pi / 6 
print("The Value of Sine of pi/6 is :",end = " ")
print(math.sin(a))
print("The Value of Cosine of pi/6 is",end = " ")
print(math.cos(a))
print("The Value of Tangent of pi/6 is :", end = " ")
print(math.tan(a))
a = math.pi / 6 
b = 30 
print("The Converted Value from Radian to the Degree is :")
print(math.degrees(a))
print("The Converted Value from Radian to Degree is:")
print("The Converted Value from the Degree to Radian is :")
print(math.radian(b))

import math 
a = math.pi / 6 
print("The Value of Sine of pi/6 is :",end = " ")
print(math.tan(a))
a = math.pi / 6 
b = 30 
print("The Converted Value from Radian to the Degree is :")
print(math.degrees(a))
print("The Converted Value from Radian to Degree is:")
print("The Converted Value from the Degree to Radian is:")
print(math.radian(b))

