dict1 = {'A':234,'B':456}
dict2 = {'C':678,'D':890}
dict3 = {'A':234,'B':456}
x = dict1 == dict2
y = dict1 == dict3
print("Dict equal to Dict2:",x)

dict1 = {'A':234,'B':456}
dict2 = {'C':678,'D':890}
dict3 = {'A':234,'B':456}
x = dict1 == dict2
y = dict1 == dict3
print("Dict equal to Dict2:",x)

dict1 = {'A':234,'B':456}
dict2 = {'C':678,'D':890}
dict3 = {'A':234,'B':456}
x = dict1 == dict2
y = dict1 == dict3
print("Dict equal to Dict2:",x)

dict1 = {'A':234,'B':456}
dict2 = {'C':678,'D':890}
dict3 = {'A':234,'B':456}
x = dict1 == dict2
y = dict1 == dict3
print("Dict equal to Dict2:",x)

dict1 = {'A':234,'B':456}
dict2 = {'C':678,'D':890}
dict3 = {'A':234,'B':456}
x = dict1 == dict2
y = dict1 == dict3
print("Dict equal to Dict2:",x)

dict1 = {'A':234,'B':456}
dict2 = {'C':678,'D':890}
dict3 = {'A':234,'B':456}
x = dict1 == dict2 
y = dict1 == dict3
print("Dict equal to Dict2:",x)

