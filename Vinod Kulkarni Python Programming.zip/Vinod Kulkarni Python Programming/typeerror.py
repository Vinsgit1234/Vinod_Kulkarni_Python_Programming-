numbers = [1,2,3,4,5,1,4,5]
print("Original List =",numbers)
res = sum(numbers)
print("Sum of given numbers=",res)
average = res/len(numbers)
print("Average of Given number=",average)

numbers = [1,2,3,4,5,1,4,5]
print("Original List =",numbers)
res = sum(numbers)
print("Sum of given numbers=",res)
average = res/len(numbers)
print("Average of Given number=",average)

numbers = [1,2,3,4,5,1,4,5]
print("Original List =",numbers)
res = sum(numbers)
print("Sum of given numbers=",res)
average = res/len(numbers)
print("Average of Given number=",average)

numbers = [1,2,3,4,5,1,4,5]
print("Original List =",numbers)
res = sum(numbers)
print("Sum of given numbers =",res)
average = res/len(numbers)
print("Average of Given numbers = ",average)

