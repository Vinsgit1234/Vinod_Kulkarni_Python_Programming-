print (range(10))
print (list(range(10)))
print (list(range(2,10)))
print (list(range(2,20,3)))

print (range(10))
print (list(range(10)))
print (list(range(2,10)))
print (list(range(2,20,3)))

print (range(10))
print (list(range(10)))
print (list(range(2,10)))
print (list(range(2,20,3)))

