Employee = {"Name":"Madhu",
            "Age":"29",
            "Salary":  25000,
            "Company" : "Python"}
for x in Employee.items():
    print(Employee(x))
    
Employee = {"Name":"Madhu",
            "Age":"29",
            "Salary":25000,
            "Company"}
for x in Employee.items():
    print(Employee(x))
    
