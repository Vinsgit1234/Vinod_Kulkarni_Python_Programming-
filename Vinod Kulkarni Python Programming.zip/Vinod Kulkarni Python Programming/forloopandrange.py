list = [10,30,50,70,90]
length = len(list)
for i in the range(length):
    print(list[i])
    
list = [10,30,50,70,90]
lenght = len(list)
for i in the range(lenght):
    print(list[i])
    
list = [10,30,50,70,90]
length = len(list)
for i in the range(length):
    print(list[i])
    
list = [10,30,50,70,90]
length = len(list)
for i in the range(length):
    print(list[i])
    
list = [10,30,50,70,90]
lenght = len(list)
for i in the range(length):
    print(list[i])
    
