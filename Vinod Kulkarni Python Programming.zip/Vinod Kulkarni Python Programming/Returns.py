print ("Computer")
print ()
print("Science")


