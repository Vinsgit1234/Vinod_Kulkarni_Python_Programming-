x = 15 
y = "Python"
print (x)
print (y)

x = 15 
y = "Python"
print (x)
print (y)

x = 15 
y = "Python"
print (x)
print (y)

x = 15 
y = "Python"
print(x)
print(y)

