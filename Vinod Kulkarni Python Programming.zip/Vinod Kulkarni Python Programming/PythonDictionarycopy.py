original = {1 : 'Computer' , 2:'Science'}
new = original.copy()
print("Original Dictionary :",original)
print("Copied Dictionary :",new)

original = {1 : 'Computer' , 2:'Science'}
new = original.copy()
print("Original Dictionary :",original)
print("Copied Dictionary :",new)

original = {1 : 'Computer' , 2:'Science'}
new = original.copy()
print("Original Dictionary :",original)
print("Copied Dictionary :",new)

