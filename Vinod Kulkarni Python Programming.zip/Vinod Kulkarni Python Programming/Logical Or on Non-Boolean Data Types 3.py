x = 20 
y = 20 
10 and 20 

