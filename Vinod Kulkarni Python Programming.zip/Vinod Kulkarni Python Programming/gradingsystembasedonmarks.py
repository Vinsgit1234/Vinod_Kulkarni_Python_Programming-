marks = int(input("Enter the marks"))
if marks > 85 and marks <= 100:
    print("Congrats ! you scored Grade A")
elif marks >60 and marks <= 85:
    print("You scored grade B + ...")
elif marks > 40 and marks <= 60:
    print("You scored grade B...")
elif (marks >30 and marks <=60):
    print("You can scored grade C..")
else:
    print("Sorry you are fail")
    
marks = int(input("Enter the marks"))
if marks > 85 and marks <= 100:
    print ("Congrats! you scored Grade A")
elif marks >60 and marks <= 85:
    print("You scored grade B..")
elif (marks >30 and marks <= 60):
    print("You Scored grade C..")
else:
    print("Sorry you are a Fail")

marks = int (input("Enter the marks"))
if marks >85 and marks <= 100:
    print ("Congratulations! You Scored Grade A")
elif marks>60 and marks <= 85:
    print("You scored grade B....")
else:
    print ("Sorry Are  a Fail")
    

    
    
    