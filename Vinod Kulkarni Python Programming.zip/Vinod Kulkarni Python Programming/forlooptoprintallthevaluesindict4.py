Employee = {"Name": "Madhu",
            "Age":29,
            "Salary":25000,
            "Company":"Python"}
for x in  Employee:
    print(Employee[x])
    
    