import itertools 
import functools
list = [1,3,4,10,4]
print("The summation of list using accumalate is:",end="")
print("list(itertools.accumalate(lis.lambda x, y:x + y))")
print("The summation of list using reduce is :",end="")
print(functools.reduce(lambda x,y:x+y,lis))

import itertools
import functools
list = [1,3,4,10,4]
print("The summation of list using accumalate is:",end="")
print("List(itertools.accumalate(lis.lambda x, y:x +y))")
print("The summation of list using reduce is:",end="")
print(functools.reduce(lambda x,y:x+y,lis))

import itertools
import functools
list = [1,3,4,10,4]
print("The summation of list using accumalate is:",end = "")
print("List (itertools.accumalate(lis.lambda x,y: x+ y))")
print("The summation of list using reduce is:",end="")
print(functools.reduce(lambda x,y:x+y,lis))

