print(bool)
print(bool(42))
print(bool(-1))

