list1 = [1,2,3,4,5,6]
list2 = [6,7,8,9,2,10]
for x in list1:
    for y in list2:
        if x==y:
            print("The Common Element is:",x)
            
list1 = [1,2,3,4,5,6]
list2 = [6,7,8,9,2,10]
for x in list1:
    for y in list2:
        if x==y:
            print("The Common Element is:",x)
            
list1 = [1,2,3,4,5,6]
list2 = [6,7,8,9,2,10]
for x in list1:
    for y in list2:
        if x==y:
            print("The Common Element is :",x)
            
list1 = [1,2,3,4,5,6]
list2 = [6,7,8,9,2,10]
for x in list1:
    for y in list2:
        if x==y:
            print("The Common Element is :",x)
            
list1 = [1,2,3,4,5,6]
list2 = [6,7,8,9,2,10]
for x in list1:
    for y in list2:
        if x==y:
            print("The Common Element is :",x)

list1 = [1,2,3,4,5,6]
list2 = [6,7,8,9,2,10]
for x in list1:
    for y in list2:
        if x==y:
            print("The Common Element is :",x)
            
list1 = [1,2,3,4,5,6]
list2 = [6,7,8,9,2,10]
for x in list1:
    for y in list2:
        if x==y:
            print("The Common Element is :",x)
            
list1 = [1,2,3,4,5,6]
list2 = [6,7,8,9,2,10]
for x in list1:
    for y in list2:
        if x==y:
            print("The Common Element is :",x)
            
list1 = [1,2,3,4,5,6]
list2 = [6,7,8,9,2,10]
for x in list1:
    for y in list2:
        if x==y:
            print("The Common Element is :",x)
            
list1 = [1,2,3,4,5,6]
list2 = [6,7,8,9,2,10]
for x in list1:
    for y in list2:
        if x==y:
            print("The Common Element is :",x)
            
