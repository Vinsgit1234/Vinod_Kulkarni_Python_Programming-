a = ['Hari','amita','madhu','nethra']
b = ['methre','hari','madhu','amita']
print("Lists that have the same"
      "elements in a different order",a == b)
a = ['hari','amita','madhu','nethra']
b = ['hari','amita','madhu','nethra']
print("Lists that have the same"
      "Elements in same order", a==b)

a = ['Hari','amita','madhu','nethra']
b = ['methra','hari','madhu','amita']
print("Lists that have the same"
    "elements in a different order",a == b)
a = ['hari','amita','madhu','nethra']
b = ['hari','amita','madhu','nethra']
print("Lists that have the same"
      "Elements in same order", a==b)

a = ['Hari','amita','madhu','nethra']
b = ['methra','hari','madhu','amita']
print("Lists that have the same"
      "elements in a differenr order",a ==b)
a = ['hari','amita','madhu','nethra']
print("Lists that have the same"
      "Elements in same order",a==b)

a = ['Hari','amita','madhu','nethra']
b = ['methra','hari','madhu','amita']
print("Lists that have the same"
      "elements in a different order",a ==b)
a = ['hari','amita','madhu','nethra']
print("Lists that have the same"
      "Elements in same order",a==b)

