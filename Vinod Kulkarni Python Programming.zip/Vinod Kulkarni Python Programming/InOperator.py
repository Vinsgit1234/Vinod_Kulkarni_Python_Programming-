my_list = ["Hari",3,"[Sudha]","[Madhu]",4.8,"z"]
print("my_list= ",my_list)
if "Hari" in my_list:
    print("Item found")
else:
    print("Item not Found")
    
    
my_list = ["Hari",3,"[Sudha]","[Madhu]",4.8,"z"]
print("my_list = ", my_list)
if "Hari" in my_list:
    print("Item Found")
else:
    print("Item not Found")
    
my_list = ["Hari",3,"[Sudha]","[Madhu]",4.8,"z"]
print("my_list = ",my_list)
if "Hari" in my_list:
    print("Item Found")
else:
    print("Item not Found")
    
