city = input("Enter the name of the City:-")
if city.lower() == "delhi":
    print("Monument name is : Red Fort")
elif city.lower() == "agra":
    print("Monument name is : Taj Mahal")
elif city.lower() == "jaipur":
    print("Monument name is : Jal Mahal")
else:
    print("Enter the Correct name of the City")
    
    

