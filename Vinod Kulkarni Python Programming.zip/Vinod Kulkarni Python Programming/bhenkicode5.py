a = 10 
def change(x):
    x = 20 
change(a)
print(a)

a = 10 
def change(x):
    x = 20 
    change(a)
    print(a)
    
a = 10 
def change(x):
    x = 20 
    change(a)
    print(a)
    
a = 10 
def change(x):
    x = 20 
    change(a)
    print(a)
    
    
    