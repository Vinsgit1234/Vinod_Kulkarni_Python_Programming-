my_dict = {"m":1,"l":2}
new_key = list(my_dict)
index_key = new_key[0]
print("Key at index 0 :",index_key)

my_dict = {"m":1,"1":2}
new_key = list(my_dict)
index_key = new_key[0]
print("Key at index 0 :",index_key)

my_dict = {"m":1,"1":2}
new_key = list(my_dict)
index_key = new_key[0]
print("Key at index 0 :",index_key)

