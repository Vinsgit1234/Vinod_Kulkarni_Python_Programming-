class A:
    def __init__(self):
        x = int
        self.x = 1 
a = A()
b = a 
b.x = 5 
print(a.x)

class A:
    def __init__(self):
        x = int
        self.x = 1
a = A()
b = a 
b.x = 5 
print(a,x)

