numbers = [1,2,3,4,5,1,4,5]
print ("Original List =",numbers)
res = sum(numbers)
print("sum of given numbers =",res)
average = res/len(numbers)
print("Average of given numbers=",average)

numbers = [1,2,3,4,5,1,4,5]
print ("Original List = ",numbers)
res = sum(numbers)
print("Sum of given numbers =",res)
average = res/len(numbers)
print("Average of given numbers=",average)

numbers = [1,2,3,4,5,1,4,5]
print ("Original List =",numbers)
res = sum(numbers)
print("Sum of Given Numbers =",res)
average = res/len(numbers)

numbers = [1,2,3,4,5,1,4,5]
print ("Original List =",numbers)
res = sum(numbers)
print("Sum of Given Numbers =",res)
average = res/len(numbers)

numbers = [1,2,3,4,5,1,4,5]
print ("Original List =",numbers)
res = sum(numbers)
print("Sum of Given Numbers =",res)
average = res/len(numbers)

numbers = [1,2,3,4,5,1,4,5]
print("Original List =",numbers)
res = sum(numbers)
print("Sum of Given numbers =",res)
average = res/len(numbers)
print("Average of Given Numbers =",average)

numbers = [1,2,3,4,5,1,4,5]
print("Original List = ",numbers)
res = sum(numbers)
print("Sum of Given numbers =",res)
average = res/len(numbers)
print("Average of Given Numbers =",average)

numbers = [1,2,3,4,5,1,4,5]
print("Original List = ",numbers)
res = sum(numbers)
print("Sum of Given numbers =",res)
print("Average of Given Numbers =",average)

numbers = [1,2,3,4,5,1,4,5]
print("Original List =",numbers)
res = sum(numbers)
print("Sum of Given numbers =",res)
print("Average of Given Numbers =",average)

numbers = [1,2,3,4,5,1,4,5]
print("Original List =",numbers)
res = sum(numbers)
print("Sum of Given numbers =",res)
print("Average of Given Numbers =",average)

numbers = [1,2,3,4,5,1,4,5]
print("Original List =",numbers)
res = sum(numbers)
print("Sum of Given numbers =",res)
print("Average of Given Numbers =",average)

numbers = [1,2,3,4,5,1,4,5]
print("Original List =",numbers)
res = sum(numbers)
print("Sum of Given Numbers =",res)
print("Average of Given Numbers =",average)

numbers = [1,2,3,4,5,1,4,5]
print("Original List =",numbers)
res = sum(numbers)
print("Sum of Given Numbers =",res)
print("Average of Given Numbers =",average)

numbers = [1,2,3,4,5,1,4,5]
print("Original List =",numbers)
res = sum(numbers)
print("Sum of Given Numbers =",res)
print("Average of Given Numbers =",average)

numbers = [1,2,3,4,5,1,4,5]
print("Original List =",numbers)
res = sum(numbers)
print("Sum of Given Numbers =",res)
print("Average of Given Numbers =",average)

numbers = [1,2,3,4,5,1,4,5]
print("Original List =",numbers)
res = sum(numbers)
print("Average of Given Numbers =",average)
print("Average of Given Numbers =",average)

numbers = [1,2,3,4,5,1,4,5]
print("Original List =",numbers)
res = sum(numbers)
print("Average of Given Numbers =",average)
print("Average of Given Numbers=",average)

numbers = [1,2,3,4,5,1,4,5]
print("Original List =",numbers)
res = sum(numbers)
print("Average of Given Numbers =",average)
print("Average of Given Numbers=",average)
