var_1 = None
var_2 = None
print("ID of var_1", id(var_1))
print ("ID of var_2",id(var_2))

var_1 = None
var_2 = None
print("ID of var_1", id (var_1))
print("ID of var_2", id(var_2))

var_1 = None
var_2 = None
print ("ID of var_1", id(var_1))
print ("ID of var_2", id(var_2))

var_1 = None
var_2 = None
print("10 of var_1:", id(var_1))
print ("10 of var_2:", id(var_2))

var_1 = None
var_2 = None
print("10 of var_1:",id(var_1))
print ("10 of var_1:",id(var_2))

var_1 = None
var_2 = None
print("10 of var_1: ", id(var_1))
print ("10 of var_1:", id(var_2))

var_1 = None
var_2 = None
print ("10 of var_1:", id(var_1))
print ("10 of var_1:", id(var_2))

var_1 = None
var_2 = None
print ("10 of var_1:", id(var_1))
print ("10 of var_1:", id (var_1))

var_1 = None
var_2 = None
print ("10 of var_1:", id(var_1))
print ("10 of var_1:", id(var_1))

var_1 = None
var_2 = None
print ("10 of var_1:",id(var_1))
print ("10 of var_1:",id(var_1))

var_1 = None
var_2 = None
print ("10 of var_1:", id(var_1))
print ("10 of var_1:", id(var_1))

var_1 = None
var_2 = None
print ("10 of var_1:", id(var_1)) 
print ("10 of var_1:", id(var_1))

var_1 = None
var_2 = None
print ("10 of var_1:" , id(var_1))
print (("10 of var_1:" , id(var_1)))

var_1 = None 
var_2 = None
print ("10 of var_1:", id(var_1))
print ("10 of var_1:", id(var_1))

var_1 = None
var_2 = None
print ("10 of var_1:",id(var_1))
print ("10 of var_1:", id(var_2))


      
       