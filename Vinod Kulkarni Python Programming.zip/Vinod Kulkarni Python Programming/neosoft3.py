list = ["eat","tea","tan","ate","nat","bat"]
res = []
for i in list:
    res.append[::-1]
print(res)








# Input: ["eat", "tea", "tan", "ate", "nat", "bat"]
# Output: [["eat","tea","ate"], ["tan","nat"], ["bat"]]

