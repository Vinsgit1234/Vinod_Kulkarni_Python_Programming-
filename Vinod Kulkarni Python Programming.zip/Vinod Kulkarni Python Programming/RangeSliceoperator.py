# [:] is known as range Slice Operator. It is used to access the characters from the specifies range. It returns the character from the range provided at x:y.
s = "Python"
print ("[] operator :", s[2:5])

s = "Python"
print ("[] operator :", s[2:5])

s = "Python"
print ("[] operator :" ,s[2:5])

s = "Python"
print ("[] operator :" ,s[2:5])

s = "Python"
print ("[] operator :" , s[2:5])

s = "Python"
print ("[] operator :" ,s[2:5])

s = "Python"
print ("[] operator :" ,s[2:5])

