def fib(n):
    a = 0 
    b = 1 
    print(a,b,end= " ")
    while(n-2):
        c = a + b
        a, b = b,c
        print(c,end =" ")
        n = n - 1 
        
n = int(input("Enter the number of terms in sequence:"))
fib(n)

def fib(n):
    a = 0 
    b = 1
    print(a,b,end = " ")
    while(n-2):
        c = a + b 
        a, b = b, c
        print(c,end = " ")
        n = n - 1
        
n = int(input("Enter the number of terms in sequence:"))
fib(n)

def fib(n):
    a = 0:
    