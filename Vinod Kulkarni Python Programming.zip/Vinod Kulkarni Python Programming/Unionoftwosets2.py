Days1 = {"Monday","Tuesday","Wednesday","Thursday","Sunday"}
Days2 = {"Friday","Saturday","Sunday"}
Days = (Days1|Days2)
print(Days)
        
Days1 = {"Monday","Tuesday","Wednesday","Thursday","Sunday"}
Days2 = {"Friday","Saturday","Sunday"}
Days = (Days1|Days2)
print(Days)

Days1 = {"Monday","Tuesday","Wednesday","Thursday","Sunday"}
Days2 = {"Friday","Saturday","Sunday"}
Days = (Days1|Days2)
print(Days)

Days1 = {"Monday","Tuesday","Wednesday","Thursday","Sunday"}
Days2 = {"Friday","Saturday","Sunday"}
Days = (Days1|Days2)
print(Days)

Days1 = {"Monday","Tuesday","Wednesday","Thursday","Sunday"}
Days2 = {"Friday","Saturday","Sunday"}
Days = (Days1|Days2)
print(Days)

