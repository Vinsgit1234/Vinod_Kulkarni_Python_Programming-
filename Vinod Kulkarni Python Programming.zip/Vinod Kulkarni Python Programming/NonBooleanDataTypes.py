x = 10 
y = 20 
z = 10 or 20 
print(z)


X = 10 
Y = 20 
Z = 10 or 20 
print (z)

x = 10 
y = 20 
z = 10 or 20
print (z)

x = 10 
y = 20 
z = 10 or 20 
print (z)

x = 0 
y = 20 
z = 10 and 20  
print (z)

x = " apple "
y = " "
z = "apple " and " "
print (z)

x = " apple "
y = " "
z = "apple " and " "
print (z)

x = " apple "
y = " "
z = " apple " and " "
print (z)

x = " apple "
y = " "
z = " apple " and " "
print (z)

x = " apple "
y = " "
z = " apple " and " "
print (z)






