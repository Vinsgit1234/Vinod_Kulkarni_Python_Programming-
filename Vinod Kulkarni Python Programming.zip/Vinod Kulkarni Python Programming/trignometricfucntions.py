import numpy as np 
import math 
in_array = [0,math.pi/2, np.pi/3,np.pi]
print("Input array :\n", in_array)
Sin_values = np.sin(in_array)
print("\n Sine Values :\n",Sin_values)
cos_Values = np.cos(in_array)
print("\n Cosine values :\n",cos_Values)

import numpy as np 
import math 
in_array = [0,math.pi/2,np.pi/3,np.pi]
print("Input array :\n", in_array)
Sin_values = np.sin(in_array)
print("\n Sine Values :\n",Sin_values)
cos_Values = np.cos(in_array)
print("\n Cosine values :\n",cos_Values)

