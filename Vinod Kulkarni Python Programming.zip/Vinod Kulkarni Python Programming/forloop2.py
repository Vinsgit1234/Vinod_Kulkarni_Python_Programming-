List = [0,1,2,3,4,5]
print("Content of the List using for loop")
for x in List:
    print(x)
    
List = [0,1,2,3,4,5]
print("Content of the List using for loop")
for x in list:
    print(x)
    
List = [0,1,2,3,4,5]
print("Content of the List using for Loop")
for x in list:
    print(x)
    
List = [0,1,2,3,4,5]
print("Content of the List using for loop")
for x in list:
    print(x)
    
List = [0,1,2,3,4,5]
print("Content of the List using for loop")
for x in list:
    print(x)
    

    