a = 123 
str = "456"
print("Data type of a:", type(a))
print ("Data type of str before Type Casting:", type(str))
str = int(str)
print("Data type of str after Type Casting:", type(str))
sum = a + str
print ("Sum of a and str:",sum) 
print("Data type of the sum:" , type(sum))

a = 123
str = "456"
print("Data type of a:",type(a))
print ("Data type of str before Type Casting:", type(str))
str = int(str)
print("Data type of str after type Casting:", type(str))
sum = a + str
print("Sum of a and str:", sum)
print("Data type of the sum:" , type(sum))

a = 123 
str = "456"
print ("Data type of a:", type (a))
print ("Data type of str before type Casting:",type(str))
str = int(str)
print ("Data type of str after typr Casting:",type(str) )
sum = a + str
print ("Sum of a and str:", sum)
print("Data type of the sum:", type(sum))

