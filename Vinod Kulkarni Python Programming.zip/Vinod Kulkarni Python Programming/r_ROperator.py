s1 = "Python \n Programming"
s2 = " Python" r" \n Programming"
print (s1)
print  (s2)

s1 = "Python \n Programming"
s2 = "Python" r" \n Programming"
print (s1)
print (s2)

s1 = "Python \n Programming"
s2 = "Python" r" \n Programming"
print (s1)
print (s2)

s1 = "Python \n Programming"
s2 = "Python" r" \n Programming"
print (s1)
print (s2)

s1 = "Python \n Programming"
s2 = "Python" r" \n Programming"
print (s1)
print (s2)

