x = 5.8 
print(type(x))

x = 5.8 
print(type(x))

x = 5.8 
print(type(x))

x = 5.8 
print(type(x))

x = 5.8 
print(type(x))

x = 5.8 
print(type(x))
