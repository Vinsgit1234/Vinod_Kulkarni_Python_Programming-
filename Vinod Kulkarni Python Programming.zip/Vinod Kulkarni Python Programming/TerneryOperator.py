a, b = 10, 20 
min= a if a<b else b 
print ("Minimum value :", min)

a, b = 10, 20 
min = a if a<b else b 
print ("Minimum value :",min)

a, b = 10, 20 
min= a if a<b else b 
print ("Minimum value :", min)

a, b = 10, 20 
min= a if a<b else b
print ("Minimum value :", min)

a, b = 10, 20 
min= a if a<b else b
print ("Minimum value :", min)

a, b = 10, 20 
min= a if a<b else b 
print ("Minimum value :", min)

a, b = 10, 20 
min= a if a<b else b 
print ("Minimum value :", min)

a, b = 10, 20 
min = a if a<b else b 
print ("Minimum value:", min)

a, b = 10, 20 
min = a if a<b else b 
print ("Minimum value:",min)

a, b = 10, 20 
min = a if a<b else b 
print ("Minimum value:", min)

a, b = 10, 20 
min = a if a<b else b 
print ("Minimum value", min)

a, b = 10, 20 
min = a if a<b else b 
print ("Minimum value ",min)

a, b = 10, 20 
min = a if a<b else b 
print ("Minimum value ", min)

