A = True 
B = False 
print ("A or B :", A or B )
C = False 
print ("A or (C and B):", A or (C and B))
print ("(A and B) or C : ", (A and B) or C)

A = True
B = False 
print ("A or B :" , A or B)
C = False 
print ("A or (C and B):", A or (C and B))
print ("(A  and B) or C : ", (A  and B) or C)

A = True 
B = False 
print ("A or B :" , A or B)
C = False 
print ("A or (C and B): ", A or (C and B))
print ("(A and B)) or C : ", (A and B) or C)

A = True 
B = False 
print ("A or B :" , A or B)
C = False 
print ("A or (C and B):", A or (C and B ))
print ("(A and B)) or C : ", (A and B) or C)

A = True 
B = False 
print ("A or B:" , A or B)
C = False 
print ("A or (C and B):", A or (C and B))
print ("(A and B) or C :", (A and B) or C)

A = True 
B = False
print ("A or B:" , A or B)
C = False 
print ("A or (C and B):", A or (C and B))
print ("(A and B) or C :", (A and B) or C)

A = True 
B = False 
print ("A or B:" , A or B)
C = False 
print ("A or (C and B):", A or (C and B))
print ("A and B) or C:", (A and B) or C)

A = True 
B = False 
print ("A or B:", A or B) 
C = False 
print ("A or (C and B):", A or (C and B))
print ("A and B) or C:", (A and B) or C)

A = True 
B = False 
print ("A or B:", A or B)
C = False 
print ("A or (C and B):", A or (C and B))
print ("A and B) or C : ",(A and B) or C)

A = True 
B = False 
print (" A or B:", A or B)
C = False 
print (" A or (C and B):", A or (C and B))
print ("A and B) or C : ", (A and B) or C)

A = True 
B = False 
print ("A or B:" , A or B)
C = False 
print ("A or (C and B):", A or (C and B))
print ("A and B) or C : ", (A and B) or C)

A = True 
B = False 
print ("A or B:", A or B)
C = False 
print ("A or (C and B):", A or (C and B))
print ("A and B) or C : ", (A and B) or C)

A = True 
B = True 
print ("A or B:", A or B)
C = True
print ("A or (C and B):", A or (C and B))
print ("(A and B) or C : ", (A and B) or C)

A = True 
B = True 
print ("A or B:", A or B)
C = True 
print ("A or (C and B):", A or (C and B))
print ("(A and B ) or C: ", (A and B) or C)

