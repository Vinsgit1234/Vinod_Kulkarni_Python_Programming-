def find_longest_word(word_list):
    word_len = []
    for n in words_list:
        word_len.append((len(n),n))
        word_len.sort()
        return word_len[-1][0], word_len[-1][1]
    result = find_longest_word(["Computer","Python","Code"])
    print("\n Longest Word:", result[1])
    print("Length of the Longest Word:",result[0])
    
def find_longest_word(word_list):
    word_len = []
    for n in words_list:
        word_len.append((len(n),n))
        word_len.sort()
        return word_len[-1][0], word_len[-1][1]
    result = find_longest_word(["Computer","Python","Code"])
    print("\n Longest Word:", result[1])
    print("Length of the Longest Word:",result[0])
    
    