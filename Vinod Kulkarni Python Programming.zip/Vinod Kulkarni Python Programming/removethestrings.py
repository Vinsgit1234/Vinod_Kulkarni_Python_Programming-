## Remove the special character and reverse each word in the sentence
 
## Input:
## Welc&&&@@ome to Inter$$$$view
 
## output
## emocleW ot weivretnI

str = "Welc&&@@ome"
rev = rev*10
r = rev(str)
print(r)


