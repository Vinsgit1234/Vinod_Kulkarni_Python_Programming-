L = [10 ,20, 52, 255]
b = bytearray(L)
print("b[0]=" , b [0])
print ("b[-1] = ", b[-1])
b [0] = 11
print ("After modification")
print ("b[0] = " , b[0])

L = [10, 20, 52, 255]
b = bytearray(L)
print ("b[0]=",b[0])
print ("b[-1] = ", b[-1])
b [0] = 11
print ("After modification")
print ("b[0] = " , b[0])

L =[10,20,52,225]
b = bytearray(L)
print ("b[0]=",b[0])
print ("b[0]=",b[0])
print ("b[-1] = ",b[-1])
b[0] = 11
print ("After modification")
print ("b[0]", b[0])

L =[10,20,52,255] 
b = bytearray(L)
print ("b[0]=",b[0])
print ("b[0]=",b[0])
print ("b[-1]=",b[-1])
b[0] = 11 
print ("After modification")
print ("b[0]", b[0])

L = [10,20,52,255]
b = bytearray(L)
print ("b[0]",b[0])
print ("b[0]=",b[0])
print ("b[-1]=",b[-1])
b[0] = 11 
print ("After Modification")
print ("b[0]", b[0])

L = [10,20,52,255]
b = bytearray(L)
print ("b[0]",b[0])
print ("b[0]=",b[0])
print ("After Modification")
print ("b[0]",b[0])

L = [10,20,30,255]
b = bytearray(L)
print ("b[0]",b[0])
print ("b[0]",b[0])
print ("b[0]=",b[0])
print ("After Modificatoin")
print ("b[0]",b[0])

L = [10,20,30,255]
b = bytearray(L)
print ("b[0]",b[0])
print ("b[0]",b[0])
print ("b[0]=", b[0])
print ("After Modification")
print ("b[0]",b[0])

L = [10,20,30,255]
b = bytearray(L)
print ("b[0]",b[0])
print ("b[0]",b[0])
print ("b[0]",b[0])
print ("After Modification")
print ("b[0]",b[0])

L = [10,20,30,255]
b = bytearray(L)
print ("b[0]",b[0])
print ("b[0]",b[0])
print ("b[0]",b[0])
print ("After Modification")
print ("b[0]",b[0])

L = [10,20,30,255]
b = bytearray(L)
print ("b[0]",b[0])
print ("b[0]",b[0])
print ("b[0]",b[0])
print ("After Modification")
print ("After Modification")
print ("b[0]",b[0])

L = [10,20,30,255]
b = bytearray(L)
print ("b[0]",b[0])
print ("b[0]",b[0])
print ("b[0]",b[0])
print ("After Modification")
print ("After Modification")
print ("b[0]",b[0])

L = [10,20,30,255]
b = bytearray(L)
print ("b[0]",b[0])
print ("b[0]",b[0])
print ("b[0]",b[0])
print ("After Modification")
print("After Modification")
print ("b[0]",b[0])

L = [10,20,30,255]
b = bytearray(L)
print ("b[0]",b[0])
print ("b[0]",b[0])
print("After Modification")
print ("After Modification")
print ("b[0]",b[0])

L = [10,20,30,255] 
b = bytearray(L)
print ()      

