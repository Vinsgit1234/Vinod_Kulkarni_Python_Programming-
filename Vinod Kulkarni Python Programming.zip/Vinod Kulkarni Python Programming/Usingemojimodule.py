import emoji 
print(emoji.emojize(":grinning_face_with_big_eyes:"))
print(emoji.emojize(": winking_face_with_tongue:"))
print(emoji.emojze(":zipper-mouht_face:"))
|
print(emoji.demojize(' '))
print(emoji.demojize(' '))

