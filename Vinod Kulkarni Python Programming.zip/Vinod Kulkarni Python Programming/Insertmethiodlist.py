List = [1,2,3,4]
print("Initial List:")
print(List)
List.insert(3,12)
List.insert(0,'Python')
print("\n List after performing Insert Operation")
print(List)

List = [1,2,3,4]
print("Initial List:")
print(List)
List.insert(3,12)
List.insert(0,'Python')
print("\n List after performing Insert Operation")
print(List)


