def string_length(str1):
    count = 0
    for char in str1:
        count += 1 
        return count
    print("Lenght of a string =", 
          string_length('Python Programming'))
    
