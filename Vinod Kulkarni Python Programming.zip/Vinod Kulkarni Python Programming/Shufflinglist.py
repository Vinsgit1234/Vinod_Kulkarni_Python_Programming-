import random 
sample_list = [1,2,3,4,5]
print("Original List :")
print(sample_list)
random.shuffle(sample_list)
print("After the first shuffle")
print(sample_list)
random.shuffle(sample_list)
print("After the second shuffle :")
print(sample_list)

import random 
sample_list = [1,2,3,4,5]
print("Original List :")
print(sample_list)
random.shuffle(sample_list)
print("After the first shuffle")
print(sample_list)
random.shuffle(sample_list)
print("After the second shuffle :")
print(sample_list)

import random 
sample_list = [1,2,3,4,5]
print("Original List :")
print(sample_list)
random.shuffle(sample_list)
print(sample_list)
random.shuffle(sample_list)
print("After the second shuffle :")
print(sample_list)

import random 
sample_list = [1,2,3,4,5]
print("Original List:")
print(sample_list)
random.shuffle(sample_list)
print(sample_list)
random.shuffle(sample_list)
print("After the second shuffle :")
print(sample_list)

import random 
sample_list = [1,2,3,4,5]
print("Original List:")
print(sample_list)
random.shuffle(sample_list)
print("After the second shuffle :")
print(sample_list)

import random 
sample_list = [1,2,3,4,5]
print("Origianl List:")
print(sample_list)
random.shuffle(sample_list)
print(sample_list)
random.shuffle(sample_list)
print("After the Second Shuffle")
print(sample_list)

import random 
sample_list = [1,2,3,4,5]
print("Original List:")
print(sample_list)
random.shuffle(sample_list)
print(sample_list)
random.shuffle(sample_list)
print("After the Second Shuffle")
print(sample_list)

