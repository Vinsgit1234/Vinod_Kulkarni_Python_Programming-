list1 = ['physics','chemistry',1997,2000]:
    print("Before deleting value at Index 1 :")
    print(list1)
    del(list[1]):
        del(list1[1]):
            print("After deleting value at index 1:")
            print(list1)
            
            
list1 = ['physics','chemistry',1997,2000]:
    print("Before deleting value at Index 1 :")
    print(list1)
    del(list[1]):
        del(list1[1]):
            print("After deleting value at index 1:")
            print(list1)
            
