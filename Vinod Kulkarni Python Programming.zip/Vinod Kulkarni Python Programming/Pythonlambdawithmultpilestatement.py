List = [[2,3,4],[1,4,16,64],[3,6,9,12]]
sortList = lambda x: (sorted(i) for i in x)
secondLargest = lambda x,f : [y[len(y)-2] for y in f(x)]
res = secondLargest(List.sortList)
print("Second Largest Number =",res)

List = [[2,3,4],[1,4,16,64],[3,6,9,12]]
sortList = lambda x: (sorted(i) for i in x)
secondLargest = lambda x,f : [y[len(y)-2] for y in f(x)]
res = secondLargest(List.sortList)
print("Second Largest Number =",res)

List = [[2,3,4],[1,4,16,64],[3,6,9,12]]
sortlist = lambda x: (sorted(i) for i in x)
secondLargest = lambda x,f : [y[len(y)-2] for y in f(x)]
res = secondLargest(List.sortlist)
print("Second Largest Number =",res)

