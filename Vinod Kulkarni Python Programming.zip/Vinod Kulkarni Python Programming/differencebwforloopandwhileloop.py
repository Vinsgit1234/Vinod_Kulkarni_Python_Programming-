class Solution {
  public:
    pair<int, int> getMinMax(vector<int> arr) {
        // code here
        
    }
};
    
    