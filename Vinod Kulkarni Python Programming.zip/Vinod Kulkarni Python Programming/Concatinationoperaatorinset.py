set1 = {11,23,45}
set2 = {23,45,11}
set3 = set1 + set2 
print(set3)

set1 = {11,23,45}
set2 = {23,45,11}
set3 = set1 + set2
print(set3)

set1 = {11,23,45}
set2 = {23,45,11}
set3 = set1 + set2
print(set3)

set1 = {11,23,45}
set2 = {23,45,11}
set3 = set1 + set2
print(set3)

set1 = {11,23,45}
set2 = {23,45,11}
set3 = set1 + set2
print(set3)

set1 = {11,23,45}
set2 = {23,45,11}
set3 = set1 + set2
print(set3)

