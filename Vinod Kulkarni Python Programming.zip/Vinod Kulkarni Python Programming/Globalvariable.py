a = 19 
def first():
    print("Inside first function value of a =",a)
def second():
    print("Inside Second function value of a =",a)
first()
second()

a = 19 
def first():
    print("Inside first function value of a =",a)
def second():
    print("Inside Second function Value of a =",a)
first()
second()

a = 19 
def first():
    print("Inside first function value of a =",a)
def second():
    print("Inside Second function value of a =",a)
first()
second()

a = 19 
def first():
    print("Inside first function value of a =",a)
def second():
    print("Inside Second function Value of a =",a)
first()
second()

a = 19 
def first():
    print("Inside first function value of a=",a)
def second():
    print("Inside Second function value of a =",a)
first()
second()

