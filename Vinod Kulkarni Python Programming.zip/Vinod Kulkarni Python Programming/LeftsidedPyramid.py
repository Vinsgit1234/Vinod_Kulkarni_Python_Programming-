print("\nLeft sided Pyramid")
for i in range(5):
    x='* '
    x=x*i
    print(f'{x:<10}')

print("\nLeft Sided Pyramid")
for i in range(5):
    x='* '
    x =x*i
    print(f'{x:<10}')

print("\nLeft sided Pyramid")
for i in range(5):
    x ='x '
    x = x*i
    print(f'{x:<10}')