d = {1:10,2:20,3:30,4:40,5:50,6:60}
def is_key_present(x):
    if x in d:
        print("Key is present in the Dictionary")
    else:
        print("Key is not Present in the Dictionary")
        
is_key_present(5)
is_key_present(10)

