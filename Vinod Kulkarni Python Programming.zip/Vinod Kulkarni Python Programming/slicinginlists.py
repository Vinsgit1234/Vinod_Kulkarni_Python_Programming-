a = ['apple','banana','grapes','oranges','mint']
print("Slicing Demo",a[2:4])

a = ['apple','banana','grapes','oranges','mint']
print("Slicing Demo",a[2:4])

