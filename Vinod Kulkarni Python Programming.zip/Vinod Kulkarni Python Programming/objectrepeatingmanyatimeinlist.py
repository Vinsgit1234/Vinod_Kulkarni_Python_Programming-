a = ['apple','banana','grapes','apple']
print('List Object repeating many a time',a)

a = ['apple','banana','grapes','apple']
print('List Object repeating many a time',a)

a = ['apple','banana','grapes','apple']
print('List Object repeating many a time',a)

a = ['apple','banana','grapes','apple']
print('List Object repeating many a time',a)


