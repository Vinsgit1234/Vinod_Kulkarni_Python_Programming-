x = ['a',['bb'],['ccc',['ddd'],['ee'],'ff'],'g',['hh','ii'],'j']
print("Nested list demp",x)

x = ['a',['bb',['ccc','ddd'],['ee','ff'],'g',['hh','ii'],'j']]
print("Nested List Demo",x)

x = ['a',['bb'],['ccc',['ddd'],['ee'],'ff'],'g',['hh','ii'],'j']
print("Nested list demp",x)

x = ['a',['bb',['ccc','ddd'],['ee','ff'],'g',['hh','ii'],'j']]
print("Nested List Demo",x)

     