a = 1111
print ("Class type of a :", type(a))
print ("Value of a:",a)
a = 0b1111
print ("Class type of a:", type(a))
print ("Value of a:",a)

a = 1111 
print ("Class type of a :", type (a))
print ("Value of a:",a)
a = 0b1111 
print ("Class type of a:", type(a))
print ("Value of a:",a)

