## Function to sum of array
##Input: [1, 2, 3, 4, 5]

def array():
    arr = [1, 2, 3, 4, 5]
    arr2 = []  # list to store even numbers

    for i in arr:
        if i % 2 == 0:  # check even
            arr2.append(i)  # add even number to arr2

    ans2 = sum(arr2)
    print("The sum of even numbers of the array is:", ans2)


array()