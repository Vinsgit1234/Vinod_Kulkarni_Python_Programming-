x = 21 
x += 27 
print(x)

x = 21
x += 27
print(x)

