def fun():
    str = "Computer Science"
    x = 20
    return(str, x);
list = fun()
print("List Contents :",list)

def fun():
    str = "Computer Science"
    x = 20 
    return(str,x);
list = fun()
print("list Contents:",list)

def fun():
    str = "Computer Science"
    x = 20 
    return(str,x);
list = fun()
print("List Contents:",list)

def fun():
    str = "Computer Science"
    x = 20 
    return(str,x);
list = fun()
print("List  Contents:",list)

