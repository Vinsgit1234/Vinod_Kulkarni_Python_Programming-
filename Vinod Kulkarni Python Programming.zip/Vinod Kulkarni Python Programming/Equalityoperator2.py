dict1 = {'A':234,'B':456}
dict2 = {'C':678,'D':890}
dict3 = {'A':234,'B':256}
x = dict1 == dict2
y = dict1 == dict2 
print("Dict1 equal to Dict2 :",x)
print("Dict1 equal to Dict3 :",y)

dict1 = {'A':234,'B':456}
dict2 = {'C':678,'D':890}
dict3 = {'A':234,'B':256}
x = dict1 == dict2
y = dict1 == dict2
print("Dict1 equal to Dict2 :",x)
print("Dict1 equal to Dict3 :",y)

dict1 = {'A':234,'B':456}
dict2 = {'C':678,'D':890}
dict3 = {'A':234,'B':256}
x = dict1 == dict2
y = dict1 == dict2 
print("Dict1 equal to Dict2 :",x)
print("Dict2 equal to Dict3 :",y)

dict1 = {'A':234,'B':456}
dict2 = {'C':678,'D':890}
dict3 = {'A':678,'D':256}
x = dict1 == dict2
y = dict1 == dict2
print("Dict1 equal to Dict2 :",x)
print("Dict2 equal to Dict3 :",y)

dict1 = {'A':234,'B':456}
dict2 = {'C':678,'D':890}
dict3 = {'A':678,'D':256}
x = dict1 == dict2
y = dict1 == dict2
print("Dict1 equal to Dict2 :",x)
print("Dict2 equal to Dict1 :",y)

dict1 = {'A':234,'B':456}
dict2 = {'C':678,'D':890}
dict3 = {'A':678,'D':256}
x = dict1 == dict2
y = dict1 == dict2 
print("Dict1 equal to Dict2 :",x)
print("Dict2 equal to Dict1 :",y)

dict1 = {'A':234,'B':456}
dict2 = {'C':678,'D':890}
dict3 = {'A':678,'D':256}
x == dict1 == dict2
y == dict1 == dict2
print("Dict1 equal to Dict2 :",x)
print("Dict2 equal to Dict1 :",y)

