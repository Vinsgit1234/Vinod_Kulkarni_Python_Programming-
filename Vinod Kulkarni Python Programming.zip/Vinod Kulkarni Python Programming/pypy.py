import java.io.* 
import java.util.*;
class GFG {
    public static void main (String [] args)
    int array = [10, 20, 30, 40, 50, 60, 70]
List<Integer> my_list = new arrayList<>();
array.add(10);
array.add(20);
array.add(30);
array.add(40);
array.add(50);
array.add(60);
array.add(70);

System.out.println("List before rotation:",array)

for (int i =0;i < 4; i++)
{
    int temp = my_list.get(6);
    for (int j = 6; j>0; j--)

    {
        my_list.set(j,my_list.get(j -1));
        my_list.set(0,temp);
        System.out.println("List After Rotation:" + Array.toString(my_list.toArray));
    }
}

}
