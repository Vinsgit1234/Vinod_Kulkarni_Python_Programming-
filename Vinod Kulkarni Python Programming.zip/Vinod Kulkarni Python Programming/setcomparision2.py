a = {1,2,3,4,5,6}
b = {1,2,9,8,10}
c = a ^ b
print("Using ^ operator",c)
a = {1,2,3,4,5,6}
b = {1,2,9,8,10}
c = a.symmetric_difference(b)
print("Using symmetric_difference() method",c)


a = {1,2,3,4,5,6}
b = {1,2,9,8,10}
c = a ^ b 
print("Using ^ operator",c)
a = {1,2,3,4,5,6}
b = (1,2,9,8,10)
c = a.symmetric_difference(b)
print("Using symmetric_difference() methiod")

a = {1,2,3,4,5,6}
b = {1,2,9,8,10}
c = a ^ b
print("Using ^ operator",c)
a = a.symmetric_difference(b)
print("Using symmetric_difference() methiod")

a = {1,2,3,4,5,6}
b = {1,2,9,8,10}
c = a ^ b 
print("Using ^ operator ",c)
a = a.symmetric_difference(b)
print("Using symmetric_difference() methiod")

a = {1,2,3,4,5,6}
b = {1,2,9,8,10}
c = a ^ b
print("Using ^ operator ",c)
a = a.symmetric_difference(b)
print("Using symmetric_difference() methiod")

a = {1,2,3,4,5,6}
b = {1,2,9,8,10}
c = a ^ b
print("Using ^ operator ", c)
a = a.symmetric_difference(b)
print("Using symmetric_difference() methiod")

a = {1,2,3,4,5,6}
b = {1,2,9,8,10}
c = a ^ b
print("Using ^ operator ",c)
a = a.symmetric_difference(b)
print("Using symmetric_difference() methiod")

a = {1,2,3,4,5,6}
b = {1,2,9,8,10}
c = a ^ b
print("Using ^ operator ",c)
a = a.symmetric_difference(b)
print("Using symmetric_difference() methiod")

