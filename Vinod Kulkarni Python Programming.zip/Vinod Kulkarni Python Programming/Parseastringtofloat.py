n = "246.2458"
print ("Float value :", float (n))
print ("int value :", int(float(n)))

n = "246.2458"
print ("Float value :", float(n))
print ("int value :", int (float(n)))

n = "246.2458"
print ("Float value :", float(n))
print ("int value :", int(float(n)))

n = "246.2458"
print ("Float value :", float(n))
print ("int value :", int(float(n)))

n = "246.2458"
print ("Float value :", float(n))
print ("int value :", int(float(n)))

n = "246.2458"
print ("Float value :",float(n))
print ("int value :",int(float(n)))

n = "246.2458"
print ("Float value :",float(n))
print ("int value :",int(float(n)))

n = "246.2458"
print ("Flaot value :",float(n))
print ("int value :",int(float(n)))


