x = 10 
y = 20 
z = 10 or 20 
print (z)

x = 10 
y = 20 
z = 10 or 20 
print (z)

x = 10 
y = 20 
z = 10 or 20 
print (z)

x = 10 
y = 20 
z = 10 or 20 
print (z)

x = 0 
y = 20 
z = 10 and 20
print (z)

x = 0 
y = 20 
z = 10 and 20 
print (z)

 
