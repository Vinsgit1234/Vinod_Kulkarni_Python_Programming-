set = {28,32,47,56}
print(47 in set)
print (65 in set)

set = {28,32,47,56}
print(47 in set)
print (65 in set)

set = {28,32,47,56}
print(47 in set)
print (65 in set)

set = {28,32,47,56}
print(47 in set)
print (65 in set)

