num1 = int(input("Enter integer"))
num2 = int(input("Enter Integer"))
print(num1 + num2)
num1 = float(input("Enter the Float"))
num2 = float(input("Enter the float"))
print(num1 + num2)
string = str(input("Enter the String"))
print(string)

