a = {"Devansh","Bob","Castle"}
b = {"Castle","Dude","Emyway"}
c = {"Fusion","Gaurav","Castle"}
a.intersection_update(b,c)
print("Intersection Update=",a)

a = {"Devansh","Bob","Castle"}
b = {"Castle","Dude","Emyway"}
c = {"Fusion","Gaurav","Castle"}
a.intersection_update(b,c)
print("Intersection Update=",a)

a = {"Devansh","Bob","Castle"}
b = {"Castle","Dude","Emyway"}
c = {"Fusion","Gaurav","Castle"}
a.intersection_update(b,c)
print("Intersection Update=",a)


