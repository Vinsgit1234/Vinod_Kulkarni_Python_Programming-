a = 15
b = 12

# Adding two numbers
res = a + b
print(res)

a = 15 
b = 12

res = a + b 
print(res)

a = 15 
b = 12 

res = a + b 
print(res)

a = 15 
b = 12 

res = a + b
print(res)

a = int(input("Enter the Given Number"))
b = int(input("Enter the Given Number"))
sum = a + b 
print("The Sum of the two Given Numbers", sum)

a = int(input("Enter the Given Number"))
b = int(input("Enter the Given Number"))
sum = a + b 
print("The Sum of Two Given Numbers",sum)

# taking user input
a = input("First number: ")
b = input("Second number: ")
# converting input to float and adding
res = float(a) + float(b)
print(res)

a = input("First Number:")
b = input("Second Number")
# Converting input to Float and Adding
res = float(a) + float(b)
print(res)


