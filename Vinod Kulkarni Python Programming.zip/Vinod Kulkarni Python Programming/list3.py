x = ("POLYTECHNIC")
print("Original Tuple",x)
print("Length of tuple =", len(x))

x = ("POLYTECHNIC")
print("Original Tuple",x)
print("Length of the tuple",len(x))

x = ("POLYTECHNIC")
print("Original Tuple",x)
print("Length of the tuple",len(x))

x = ("POLYTECHNIC")
print("Original Tuple",x)
print("Length of the tuple",len(x))

x = ("POLYTECHNIC")
print("Original Tuple",x)
print("Length of the tuple",len(x))

x = ("POLYTECHNIC")
print("Original Tuple",x)
print("Length of the Tuple",len(x))

x = ("POLYTECHNIC")
print("Original Tuple",x)
print("Lenght of the Tuple",len(x))

x = ("POLYTECHNIC")
print("Original Tuple",x)
print("Lenght of the Tuple",len(x))

