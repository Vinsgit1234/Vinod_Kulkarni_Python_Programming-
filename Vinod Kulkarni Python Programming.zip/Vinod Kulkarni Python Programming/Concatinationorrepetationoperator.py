dict1 = {'A':234,'B':456}
dict2 = {'C':678,'D':890}
dict3 = {'A':234,'B':456}
print(dict1>dict2)
print(dict3<dict2)

dict1 = {'A':234,'B':456}
dict2 = {'C':678,'D':890}
dict3 = {'A':234,'D':456}
print(dict1>dict2)
print(dict3<dict2)

dict1 = {'A':234,'B':456}
dict2 = {'C':678,'D':890}
dict3 = {'A':234,'D':456}
print(dict1>dict2)
print(dict3>dict2)

dict1 = {'A':234,'B':456}
dict2 = {'C':678,'D':890}
dict3 = {'A':234,'D':456}
print(dict1>dict2)
print(dict3>dict2)

dict1 = {'A':234,'B':456}
dict2 = {'C':678,'D':890}
dict3 = {'A':234,'D':456}
print(dict1>dict2)
print(dict3>dict2)

dict1 = {'A':234,'B':456}
dict2 = {'C':678,'D':890}
dict3 = {'A':234,'D':456}
print(dict1>dict2)
print(dict3>dict2)

