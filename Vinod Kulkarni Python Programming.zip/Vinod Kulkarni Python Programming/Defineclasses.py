a = 123 
print ("Class type of a : ",type (a))
print ("value of a :", a)
a = 0o123
print ("Class type of a :" , type(a))
print ("value of a  : " , a)

a = 123 
print (" Class type of a : ", type (a))
print ("value of a : " , a)
a = 0o123
print ("Class type of type a :"type(a))
print("Value of a :", a)

a = 123 
print ("Class type of a : " , type (a))
print ("Value of a "  , a)
a = 0o123
print("Class type of type a "type(a))
print("Value of a :", a)

a = 123 
print ("Class type of a :" , type (a))
print ("Value of a" , a)
a = 0o123 
print ("Class type of a :" , type (a))
print ("Value of a:" a)

a = 123 
print ("Class type of a :", type (a))
print ("Value of a",a)
a = 0o123
print ("Class type of a :", type (a))
print ("Value of a")

a = 123 
print ("Class type of a :", type (a))
print ("Value of a",a)
a = 0o123 
print ("Class type of a :", type(a))
print ("Value of a")

a = 123 
print ("Class type of a :", type(a))
a = 0o123 
print ("Class type of a :" , type (a))
print ("Value of a")

a = 123 
print ("Class type of a :", type(a))
a = 0o123 
print ("Class type of a :", type (a))
print ("Value of a")

a = 123 
print ("Class type of a :", type (a))
a = 0o123 
print ("Class type of a :", type(a))
print ("Value of a")

a = 123 
print ("Class type of a :" , type (a))
a = 0o123 
print ("Class type of a :", type (a))
print ("Value of a")

a = 123 
print ("Class type of a: ", type (a))
a = 0o123
print ("Class type of a :". type (a))
print ("Value of a ")

a = 123 
print ("Class type of a:", type (a))
a = 0o123 
print ("Class type of a :", type (a))
print ("Value of a")

a = 123 
print ("Class type of a:", type (a))
a = 0o123
print ("Class type of a :", type(a))
print ("Value of a")

a = 123 
print ("Class type of a:",type (a))
a = 0o123 
print ("Class type of a:" , type (a))
print ("Value of a")

a = 123 
print ("Class type of a :", type(a))
a = 0o123 
print ("Class type of a: ", type (a))
print ("Value of a")

a = 123 
print ("Class type of a :", type(a))
a = 0o123 
print ("Class type of a:", type(a))
print ("Value of a")

a = 123 
print ("Class type of a :", type (a))
a = 0o123 
print ("Class type of a:", type(a))
print ("Value of a")

a = 123 
print ("Class type of a :", type (a))
a = 0o123 
print ("Class type of a:", type (a))
print ("Value of a")

a = 123 
print ("Class type of a :", type (a))
a = 0o123
print ("Class type of a :", type (a))
print ("Value of a")

a = 123 
print ("Class type of a :", type (a))
a = 0o123 
print ("Class type of a:", type (a))
print ("Value of a ")

