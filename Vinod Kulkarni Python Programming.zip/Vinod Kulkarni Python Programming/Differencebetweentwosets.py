Days1 = {"Monday","Tuesday","Wednesday","Thursday"}
Days2 = {"Monday","Tuesday","Sunday"}
Days = Days1-Days2 
print(Days)
Days1 = {"Monday","Tuesday","Wednesday","Thursday"}
Days2 = {"Monday","Tuesday","Sunday"}
res = Days1.difference(Days2)
print(res)

