Employee = {"Name" : "Madhu" ,
            "Age" : 29, 
            "Salary": 25000,
            "Company" : "Python"}
for x in Employee.values():
    print(x)

Employee = {"Name" : "Madhu" ,
            "Age" : 29,
            "Salary" : 25000,
            "Company" : "Python"}
for x in Employee.values():
    print(x)
    
Employee = {"Name" : "Madhu" ,
            "Age" :29, 
            "Salary" : 25000,
            "Company" : "Python"}
for x in Employee.values():
    print(x)
            
