a = 19
print(a // 5)

a = 19 
print(a // 5)

a = 19 
print(a // 5)

a = 19
print(a // 5)

b = 27 
print(b // 5)

b = 27 
print(b // 5)

b = 27 
print(b // 5)

b = 27 
print(b // 5)



