def change_list(list1):
    list1.append(25)
    list1.append(35)
    print("List Inside Function =",list1)
    list1 = [10,30,40,50]
    change_list(list1)
    print("List Outside Function =",list1)
    
def change_list(list1):
    list1.append(25)
    list1.append(35)
    print("List Inside Function =",list1)
    list1 = [10,30,40,50]
    change_list(list1)
    print("List Outside Function =",list1)
    
    