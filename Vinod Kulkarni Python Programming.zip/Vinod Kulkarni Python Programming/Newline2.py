a = [1,2,3,4]
print ("Print without newline in python 3, x without using for loop ",a)
print ("using symbol prints the list elements in a single line",*a)
for i in range(4):
    print(a[i])
    
    
a = [1,2,3,4]
print ("Print without newline in python 3, x without using for loop",a)
print ("using symbol prints the list elements in a single line",*a)
for i in range(4):
    print(a[i])
        
a = [1,2,3,4]
print ("Print without newline in python 3, x without using for loop", a)
print ("Using symbol prints the list elements in a single line", a)
for i in range(4):
    print(a[i])
    
        
a = [1,2,3,4]
print ("Print without newline in python 3, x without using for loop", a)
print ("Using symbol prints the list elements in a single line",a)
for i in range(4):
    print(a[i])
        
a = [1,2,3,4]
print ("Print without newline in python 3, x without using for loop", a)
print ("Using symbol prints the list elements in a single line", a)
for i in range(4):
    print(a[i])
    
a = [1,2,3,4]
print ("Print without newline in python 3,  without using for loop", a)
print ("Using symbol prints the list elements in a single line", a)
for i in range(4):
    print (a[i])
    
a = [1,2,3,4]
print ("Print without newline in python 3, without using for loop", a)
print ("Using symbol print the list elements in a single line", a)
for i in range(4):
    print (a[i])
    
    
    
    