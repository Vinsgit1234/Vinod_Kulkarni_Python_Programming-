def student(firstname,lastname):
    print("Firstname = ",firstname)
    print("Lastname =",lastname)
    student(firstname = 'Computer', lastname='Science')
    student(lastname='Science',firstname='Computer')
    
def student(firstname,lastname):
    print("Firstname = ",firstname)
    print("Lastname =",lastname)
    student(firstname = 'Computer', lastname='Science')
    
    