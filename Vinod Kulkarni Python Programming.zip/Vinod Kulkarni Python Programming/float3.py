a = 5e-324 
print ("Value of a :" , a)
b = 1e-325 
print ("Value of b : " , b)

a = 5e-324 
print ("Value of a :" , a)
b = 1e-325 
print ("Value of b :" , b)

a = 5e-324 
print ("Value of a :" , a)
b = 1e-325 
print ("Value of b : " , b)

