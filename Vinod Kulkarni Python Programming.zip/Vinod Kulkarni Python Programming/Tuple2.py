Tuple = ()
print(type(Tuple))
Tuple=(11,12,13)
print(type(tuple))
Tuple=10,20,30
print(type(Tuple))
Tuple=(10,20,30)
print(type(Tuple))
Tuple= 10,20,30.
print(type(Tuple))

Tuple = ()
print(type(Tuple))
Tuple=(11,12,13)
print(type(tuple))
Tuple = (10,20,30)
print(type(Tuple))
Tuple = 10,20,30.
print(type(Tuple))

Tuple = ()
print(type(Tuple))
Tuple=(11,12,13)
print(type(tuple))
Tuple = (10,20,30)
print(type(Tuple))
Tuple = 10,20,30
print(type(Tuple))

Tuple = ()
print(type(Tuple))
Tuple = (11,12,13)
print(type(tuple))
Tuple = (10,20,30)
print(type(Tuple))
Tuple = 10,20,30
print(type(Tuple))

Tuple = ()
print(type(Tuple))
Tuple = (11,12,13)
print(type(tuple))
Tuple = (10,20,30)
print(type(Tuple))
Tuple = 10,20,30
print(type(Tuple))

