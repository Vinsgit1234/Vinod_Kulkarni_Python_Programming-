num = 3.4 
if num > 0:
    print(num, "Positive Number")
elif num = 0:
    print(num,"Zero")
else:
    print(num, "Negative number")
    
num = 3.4
if num > 0:
    print(num, "Positive Number")
elif num = 0:
    print(num,"Zero")
else:
    print(num,"Negative number")
    
    
    