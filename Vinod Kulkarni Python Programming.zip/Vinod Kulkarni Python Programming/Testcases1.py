n = int = input(0)
for n in range(0,0):
    if n % 10 == 0:
        count (n)
        print(n)
            
n = int = input(13)
for n in range(0,0):
    if n % 10 == 0:
        count (n)
        print(n)
            
n = int = input(100)
    for n in range(0,0):
        if n % 10 == 0:
            count (n)
            print(n)