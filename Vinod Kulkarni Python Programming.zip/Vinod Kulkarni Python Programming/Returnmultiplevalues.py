class Test:
    def _init_(self):
        self.str = "Computer Science"
        self.x = 20 
def fun():
    return Test()
t = fun()

class Test:
    def_init_(self):
        self.str = "Computer Science"
        self.x = 20 
def fun():
    return Test()
t = fun()

class Test:
    def_init_(self):
        self.str = "Computer Science"
        self.x = 20 
def fun():
    return Test()
t = fun()

class Test:
    def_init_(self):
        self.str = "Computer Science"
        self.x = 20 
def fun():
    return Test()
t = fun()

class Test:
    def_init_(self):
        self.str = "Computer Science"
        self.x = 20 
def fun():
    return Test()
t = fun()

class Test:
    def_init_(self):
        self.str = "Computer Science"
        self.x = 20 
def fun():
    return Test()
t = fun()

