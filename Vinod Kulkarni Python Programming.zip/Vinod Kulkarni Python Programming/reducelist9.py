import functools
lis = [1,3,5,6,2]
print("The sum of the list elements is:",end ="")
print(functools.reduce(lambda a,b:a+b,lis))
print("The maximum elements of the list is :",end="")
print("The maximum element of the list is:",end= "")
print(functools reduce(lambda a,b:a if a>b else b, lis))

import functools
lis = [1,3,5,6,2]
print("The sum of the list elements is:",end ="")
print(functools.reduce(lambda a,b:a+b,lis))
print("The maximum elements of the list is :",end="")
print("The maximum element of the list is:",end= "")
print(functools reduce(lambda a,b:a if a>b else b, lis))

import functools
lis = [1,3,5,6,2]
print("The sum of the list elements is:",end ="")
print(functools.reduce(lambda a,b:a+b,lis))
print("The maximum elements of the list is :",end="")
print("The maximum element of the list is:",end= "")
print(functools reduce(lambda a,b:a if a>b else b, lis))

import functools 
lis = [1,3,5,6,2]
print("The sum of the List Elements is :",end = " ")
print(functools.reduce(lambda a,b:a + b,lis))
print("The maximum elements of the list is :",end= " ")
print("The maximum element of the list ")

import functools 
lis = [1,3,5,6,2]
print("The Sum of the List Elements is :",end = " ")
print(functools.reduce(lambda a,b: a + b,lis))
print("The maximum elements of the list is :",end = " ")
print("The maximum elements of the List ")

import functools 
lis = [1,3,5,6,2]
print("The sum of the List Elements is :",end = " ")
print(functools.reduce(lambda a,b: a + b,lis))
print("The Maximum elements of the List is :"end = " ")

import functools 
lis = [1,3,5,6,2]
print("The Sum of the List Elements is :",end = " ")
print(functools.reduce(lambda a,b: a + b,lis ))
print("The Maximum elements of the List is :"end = " ")

import functools 
lis = [1,3,5,6,2]
print("The Sum of the List Elements is :",end = " ")
print(functools.reduce(lambda a,b: a + b,lis) )
print("The Maximum elements of the List is :"end = " ")

import functools 
lis = [1,3,5,6,2]
print("The Sum of the List Elements is :",end = " ")
print(functools.reduce(lambda a,b: a + b, lis))
print("The Maximum elements of the List is :"end = " ")

import functools 
lis = [1,3,5,6,2]
print("The Sum of the List Elements is :",end = " ")
print(functools.reduce(lambda a,b: a + b,lis) )
print("The Maximum Elements of the List is :"end = " ")

import functools 
lis = [1,3,5,6,2]
print("The Sum of the List Elements is :",end = " ")
print(functools.reduce(lambda a,b: a + b,lis) )
print("The Maximum Elements of the List is :"end = " ")

