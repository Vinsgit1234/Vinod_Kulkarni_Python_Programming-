from array import *
array_num = array('i',[1,3,5,7,1,9,3])
print("Length of the array is:")
print(len(array_num))

from array import * 
array_num = array('i',[1,3,5,7,1,9,3])
print("Length of the array is:")
print(len(array_num))

from array import *
array_num = array('i',[1,3,5,7,1,9,3])
print("Lenght of the array is:")
print(len(array_num))

