for ch in "Python":
    if ch=="t" or ch=="o":
        pass
    print(ch,end="")