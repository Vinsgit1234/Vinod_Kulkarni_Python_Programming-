s1 = 'Cat'
s2 = 'Dog'
print ("s1 > s2 : ", s1 > s2)
print ("s1 >= s2 : " , s1 > s2)
print ("s1 <= s2 : " , s1 < s2)
print ("s1 <= s2 :" , s1 < s2)

s1 = 'Cat'
s2 = 'Dog'
print ("s1 > s2 : ", s1 > s2)
print ("s1 >= s2 : ", s1 > s2)
print ("s1 <= s2 : ", s1 < s2)
print ("s1 <= s2 :" ,s1 < s2)

s1 = 'Cat'
s2 = 'Dog'
print ("s1 > s2 :", s1 > s2)
print ("s1 <= s2 :", s1 < s2)
print ("s1 <= s2 :", s1 < s2)
print ("s1 <= s2 :", s1 < s2)

s1 = 'cat'
s2 = 'Dog'
print ("s1 > s2 :", s1 > s2)
print ("s1 <= s2 :", s1 < s2)
print ("s1 <= s2 :",s1 < s2)
print ("s1 <= s2 :",s1< s2)

s1 = 'Cat'
s2 = 'Dog'
print ("s1 > s2 :", s1 > s2)
print ("s1 <= s2 :", s1 < s2)
print ("s1 <= s2 :" , s1 <s2)
print ("s1 <= s2 :", s1 <s2)

