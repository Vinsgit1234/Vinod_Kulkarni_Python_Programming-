vowel = ['a','e','i','o','u']
word = "Programming"
count = 0 
for character in word:
    if character not in vowel:
        count += 1 
print(count)

vowel = ['a','e','i','o','u']
word = "Programming"
count = 0 
for character in word:
    if character not in vowel:
        count += 1 
print(count)



