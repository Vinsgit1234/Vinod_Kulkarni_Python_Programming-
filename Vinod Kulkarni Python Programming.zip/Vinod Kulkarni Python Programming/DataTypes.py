a = 10 
b = "Hi Python"
c = 10.5 
print ("Class type of a :", type (a))
print ("Class type of b :", type (b))
print ("Class type of c :", type (c))

a = 10 
b = "Hi Python"
c = 10.5 
print ("Class type of a:", type (a))
print ("Class type of b:",type (b))
print ("Class type of c:", type (c))

a = 10 
b = "Hi Python"
c = 10.5 
print ("Class type of a:",type(a))
print ("Class type of b:",type (b))
print ("Class type of c",type (c))

       
       
    