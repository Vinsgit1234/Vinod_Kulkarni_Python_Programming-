my_dict = {"m":1,"l":2}
my_dict = ['l'] = 4
my_dict ['m'] = 6
my_dict ['n'] = 9
new_value = list(my_dict.items())
print("Dictonary content at "
      "index 2 :",new_value[2])

my_dict = {"m":1,"1":2}
my_dict = ['1'] = 4
my_dict ['m'] = 6
my_dict ['n'] = 9 
new_value = list(my_dict.items())
print("Dictonary content at"
      "index 2 :",new_value[2])

