dict = {'Dict' : {1: 'Computer'},
        'Dict2':{'Name': 'Science'}}
print("Dictionary 1 :",Dict['Dict1'])
print("Element at index 1",Dict['Dict'][1])
print("Element at index 0",
      Dict['Dict2']['Name'])

dict = {'Dict' : {1: 'Computer'},
        'Dict2':{'Name': 'Science'}}
print("Dictionary 1 :",Dict['Dict1'])
print("Element at index 1",Dict['Dict'][1])
print("Element at index 0",
      Dict['Dict2']['Name'])

dict = {'Dict' : {1: 'Computer'},
        'Dict2':{'Name': 'Science'}}
print("Dictionary 1 :",Dict['Dict1'])
print("Element at index 1",Dict['Dict'][1])
print("Element at index 0",
      Dict['Dict2']['Name'])

dict = {'Dict' : {1: 'Computer'}
        'Dict2':{'Name':'Science'}}
print("Dictionary 1 :",Dict['Dict1'])
print("Element at index 1",Dict['Dict1'][1])
print("Element at index 0",
      Dict['Dict2']['Name'])

dict = {'Dict' : {1 : 'Computer'}
        'Dict2':{'Name':'Science'}}
print("Dictionary 1 :",Dict['Dict1'])
print("Element at index 1",Dict['Dict1'])
print("Element at index 1",Dict['Dict1'][1])
print("Element at index 0",
      Dict['Dict2']['Name'])

