Months = set(["January","Febraury","March","April","May","June"])
print("Printing the original set...")
print(Months)
print("Removing items through discard() methiod")
Months.discard("Feb");
print("Printing the modified set....")
print("\n Removing items through remove() methiod")
Months.remove("Jan")
print("n Printing the modified set")
print(Months)
             
Months = set(["January","Febraury","March","April","May","June"])
print("Printing the original set...")
print(Months)
print("Removing items through discard() methiod")
Months.discard("Feb");
print("Printing the modified set....")
print("\n Removing items through remove() methiod")
Months.remove("Jan")
print("n Printing the modified set")
print(Months)

Months = set(["January","February","March","April","May","June"])
print("Printing the original set....")
print(Months)
print("Removing items through discard() methiod")
Months.discard("Feb");
print("\n Removing items through remove () methiod")


Tuple1 = ('Cat','Rat','Dog')
Tuple2 = ('Cat','Rat','Dog')
Tuple3 = ('Cat','Rat','DOG')
Tuple4 = ('Rat','Cat','Dog')




