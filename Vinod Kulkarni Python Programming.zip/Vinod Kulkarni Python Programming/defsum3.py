def sum(a,b):
    c = a+b
    return c
    print("The Sum is:",c)

sum(10,20)

    

    
