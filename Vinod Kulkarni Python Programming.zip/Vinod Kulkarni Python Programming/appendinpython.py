List = []
print("Initial blank List")
print(List)
List.append(1)
List.append(2)
List.append(4)
print("\n List after Addition of Three Elements")
print(List)
for i in range(1,4):
    list.append(i)
print("\n List after Addition of a Tuple")
print(List)
List.append((5,6))
print("\n List after Addition of a Tuple")
print(List)
List2 = ["Computer","Science"]
List.append(List2)
print("\n List after Addition of a List:".List)

List = []
print("Initial blank List")
print(List)
List.append(1)
List.append(2)
List.append(4)
print("\n List after Addition of Three Elements")
print(List)
for i in range(1,4):
    list.append(i)
print("\n List after Addition of a Tuple")
print(List)
List.append((5,6))
print("\n List after Addition of a Tuple")
print(List)
List2 = ["Computer","Science"]
List.append(List2)
print("\n List after Addition of a List:".List)