a= 15 
b = 15 
c = a + b  
print(c)

a = 15 
b = 15 
c = a * b 
print(c)

a = 45
b = 15 
d = a / b 
print(d)

a = 45 
b = 15 
d = a / b 
print(d)

a = 45 
b = 15 
d = a // b 
print(d)

a = 45 
b = 15 
d = a % b 
print(d)

