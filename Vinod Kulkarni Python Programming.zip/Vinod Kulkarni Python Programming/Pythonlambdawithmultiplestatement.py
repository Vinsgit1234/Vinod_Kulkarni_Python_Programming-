def sum(*number):
    total=0 
    for x in number:
        total= total+x
    print("The sum:")