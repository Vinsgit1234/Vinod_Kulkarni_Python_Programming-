List = [5,10,20,30,10,'apple']
print(List)
print(type(List))

List = [5,10,20,30,10,'apple']
print(List)
print(type(List))

List = [5,10,20,30,10,'apple']
print(List)
print(type(List))

