days = []
print("This is an Empty list=",days)
print("Type of Data=",type(days))

days_list = ['mon','tue','wed']
print("List with arguments=",days_list)
print("type of data")