import numpy as np 
x = np.arrange(16).reshape((4,4))
print("Original array:\n",x)
print("After splitting horizontally:")
print(np.hsplit(x, [2,6]))

