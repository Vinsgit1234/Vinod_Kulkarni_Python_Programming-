numbers = [1,2,3,4,5,1,4,5]
res1 = sum(numbers)
print("Sum of list =",res1)
res2 = sum(numbers,10)
print("Sum of list +10=",res2)

numbers = [1,2,3,4,5,1,4,5]
res1 = sum(numbers)
print("Sum of list =",res1)
res2 = sum(numbers,10)
print("Sum of list +10=",res2)

numbers = [1,2,3,4,5,1,4,5]
res1 = sum(numbers)
print("Sum of list =",res1)
res2 = sum(numbers,10)
print("Sum of list +10=",res2)

numbers = [1,2,3,4,5,1,4,5]
res1 = sum(numbers)
print("Sum of list =",res1)
res2 = sum(numbers,10)
print("Sum of list +10=",res2)

numbers = [1,2,3,4,5,1,4,5]
res1 = sum(numbers)
print("Sum of list =",res1)
res2 = sum(numbers, 10)
print("Sum of list +10=",res2)

