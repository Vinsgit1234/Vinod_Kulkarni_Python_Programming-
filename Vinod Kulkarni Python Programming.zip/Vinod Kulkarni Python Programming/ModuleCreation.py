def product(a,b):
    a = 89 
    b = 29
    def add(a,b):
        print("Performing the addition Operation")
        print("The Sum is :", a + b)
    
def product(a,b):
    a = 89
    b = 29
    def add(a,b):
        print("Performing the addition Operation")
        print("The Sum is :",a + b)
    
def product(a,b):
    a = 89
    b = 29 
    def add(a,b):
        print("Performing the addition Operation")
        print("The Sum is :",a + b)
        
        
