from array import * 
array_number = array('i',[1,3,5,3,7,1,9,3])
print("Original array:\n" +str(array_num))