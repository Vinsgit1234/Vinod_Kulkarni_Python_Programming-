def fun():
    d['str'] = "Computer Science"
    d['x']=20
    return d
d = fun()
print("Dictionary:")
print(d)

def fun():
    d['str'] = "Computer Science"
    d['x'] = 20
    return d
d = fun()
print("Dictionary:")
print(d)

