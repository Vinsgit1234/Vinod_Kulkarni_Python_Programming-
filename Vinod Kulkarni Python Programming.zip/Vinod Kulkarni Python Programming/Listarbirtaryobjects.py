import math 
a = [2,4,6,8]
print("Elements of list are of same type",a)
a = [21.42, 'foobar', '4', 'bark','false',3.14159]
print("Elements of the list are of varying type",a)

def foo():
    pass
a = [int,len,foo,math]
print("Lists can contain the Complex objects",a)

import math 
a = [2,4,6,8]
print("Elements of list are of same type",a)
a = [21.42, 'foobar', '4', 'bark','false',3.14159]
print("Elements of the list are of varying type",a)

def foo():
    pass
a = [int,len,foo,math]
print("Lists can contain the Complex objects",a)

import math 
a = [2,4,6,8]
print("Elements of list are of same type",a)
a = [21.42, 'foobar', '4', 'bark','false',3.14159]
print("Elements of the list are of varying type",a)

def foo():
    pass
a = [int,len,foo,math]
print("Lists can contain the Complex objects",a)

import math 
a = [2,4,6,8]
print("Elements of list are of same type",a)
a = [21.42, 'foobar', '4', 'bark','false',3.14159]
print("Elements of the list are of varying type",a)

def foo():
    pass
a = [int,len,foo,math]
print("Lists can contain the Complex objects",a)

import math 
a = [2,4,6,8]
print("Elements of list are of same type",a)
a = [21.42, 'foobar', '4', 'bark','false',3.14159]
print("Elements of the list are of varying type",a)

def foo():
    pass
a = [int,len,foo,math]
print("Lists can contain the Complex objects",a)

import math 
a = [2,4,6,8]
print("Elements of list are of same type",a)
a = [21.42, 'foobar', '4', 'bark','false',3.14159]
print("Elements of the list are of varying type",a)

def foo():
    pass
a = [int,len,foo,math]
print("Lists can contain the Complex objects",a)
