def class Acc1:
    User Name:-'Vinod Kulkarni'
    Password :- Vinacc_123
    Acc Id:- 9765312
    Adhaar ID :- 8979 4567 3124 
    
def class Acc2:
    User Name :- 'Aditya Yergolkar' 
    Password :- Adiacc@123
    Acc ID :- 7662 9814 3472 
    Adhaar ID :- 4836 7762 9814     