def find_min_max(arr):
    if not arr:
        return None, None  # Handle empty array case
    return min(arr), max(arr)

# Example usage:
arr = [3, 7, 2, 9, 4]
minimum, maximum = find_min_max(arr)
print("Minimum:", minimum)
print("Maximum:", maximum)