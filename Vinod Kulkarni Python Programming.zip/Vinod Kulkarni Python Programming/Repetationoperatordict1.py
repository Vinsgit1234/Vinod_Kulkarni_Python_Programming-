dict1 = {'A':234,'B':456}
dict2 = {'C':678,'D':890}
dict3 = dict1*3
print(dict3)

dict1 = {'A':234,'B':456}
dict2 = {'C':678,'D':890}
dict3 = dict1*3
print(dict3)

dict1 = {'A':234,'B':456}
dict2 = {'C':678,'D':890}
dict3 = dict1*3
print(dict3)

dict1 = {'A':234,'B':456}
dict2 = {'C':678,'D':890}
dict3 = dict1*3
print(dict3)

dict1 = {'A':234,'B',456}
dict2 = {'C':678,'D':890}
dict3 = dict1*3
print(dict3)

dict1 = {'A':234,'B',456}
dict2 = {'C':678,'D':890}
dict3 = dict1*3
print(dict3)

dict1 = {'A':234,'B',456}
dict2 = {'C':678,'D':890}
dict3 = dict1*3
print(dict3)

dict1 = {'A':234,'B',456}
dict2 = {'C':678,'D':890}
dict3 = dict1*3
print(dict3)

dict1 = {'A':234,'B',456}
dict2 - {'C':678,'D':890}
dict3 = dict*3
print(dict3)

