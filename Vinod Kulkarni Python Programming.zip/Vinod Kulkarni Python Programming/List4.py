x = ['a',['bb'['ccc','ddd'],'ee','ff'], 'g',['hh','ii'],'j']
print("Nested list demo",x)

x = ['a',