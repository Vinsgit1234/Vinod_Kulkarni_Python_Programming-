for i in range(10):
    if i == 5:
        print("Proceessing is enough,\n Please break")
        break
    print(i)
    
for i in range(10):
    if i == 5:
        print("Processing is enough, \n Please break")
        break 
    print(i)
    
for i in range(10):
    if i == 5:
        print("Processing is enough, \n Please break")
        break
    print(i)
    
for i in range(10):
    if i == 5:
        print("Processing is enough, \n Please break")
        break
    print(i)
    
