public class duplicates {
    public static void main(String[] args)
    {
    {
    String = "Vinod Kulkarni"
    new str == str
    for i in str(i==str.len,i<=str.len,i++);
    if str == str;
        count += i 
        System.out.println("The Repeated Characters in strings are",i);
            
        } 
    }
    
}
