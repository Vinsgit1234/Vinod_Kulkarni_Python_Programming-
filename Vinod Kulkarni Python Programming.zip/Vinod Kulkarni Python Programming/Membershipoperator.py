s = "Python Programming"
print ("n" in s)
print ("m"in s)
print("ing" in s)
print("m" not in s )
print ("b" not in s)
print ("shroo" not in s)

s = "Python Programming"
print ("n" in s)
print("m" in s)
print ("ing" in s)
print ("m" not in s)
print ("b" not in s)
print ("shroo" not in s)

s = "Python Programming"
print ("n" in s)
print ("m" in s)
print ("ing" in s)
print ("m" not in s)
print ("b" not in s)
print ("shroo" not in s)



