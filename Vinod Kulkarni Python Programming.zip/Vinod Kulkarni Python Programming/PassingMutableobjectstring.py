def change_string(str):
str = str + "How are You?"
print("Printing the String Inside Function:",str)
string1 = "Hi There"...."
change_string(string1)
print("Printing  the string Outside Function :",string1)

def change_string(str):
str = str + "How are You?"
print("Printing the String Inside Function:",str)
string1 = "Hi There"...."
change_string(string1)
print("Printing the String Outside Function :",string1)

def change_string(str):
str = str + "How are You?"
print("Printing the String Inside Function:",str)
string1 = "Hi There.!!"..."
change_string(string1)
print("Printing the String Outside Function :",string1)

def change_string(str):
str = str + "How are You?"
print("Printing the String Inside Function:",str)
string1 = "Hi There... !!.."..."
change_string(string1)
print("Printing the String Outside Function:",string1)

def change_string(str):
str = str + "How are You?"
print("Printing the String Inside Function:",str)
string1 = "Hi There ...!!"..."
change_string(string1)
print("Printing The String Outside Function:",string1)




