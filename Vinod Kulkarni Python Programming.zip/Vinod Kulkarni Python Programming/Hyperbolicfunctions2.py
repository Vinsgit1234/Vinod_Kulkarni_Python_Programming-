import numpy as np 
import math 
in_array = [0, math.pi / 2, np.pi / 3, np.pi]
print("Input array :\n", in_array)
Sinh_Values = np.sinh(in_array)
print("\nSine Hyperbolic values : \n", Sinh_Values)
cosh_Values = np.cosh(in_array)
print("\ncosine Hyperbolic values :\n", cosh_Values)

import numpy as np 
import math 
in_array = [0, math.pi/2 , np.pi /3, np.pi ]
print("Input array :\n", in_array)
Sinh_Values = np.sinh(in_array)
print("\nSine Hyberbolic values : \n",Sinh_Values)
cosh_Values = np.cosh(in_array)
print("\ncosine Hyberbolic values :\n", cosh_Values)

import numpy as np 
import math 
in_array = [0, math.pi/2 , np.pi / 3, np.pi]
print("Input Array :\n", in_array)
Sinh_Values = np.sinh(in_array)
print("\n Sine Hyperbolic values :\n",Sinh_Values)
cosh_Values = np.cosh(in_array)
print("\ncosine Hyperbolic values :\n",cosh_Values)

import numpy as np 
import math 
in_array = [0,math.pi/2, np.pi/3,np.pi]
print("Input Array :\n", in_array)
Sinh_Values = np.sinh(in_array)
print("\n Sine Hyperbolic Values :\n",Sinh_Values)
cosh_Values = np.cosh(in_array)
print("\n Cosine Hyperbolic Values :\n",Sinh_Values)
cosh_Values = np.cosh(in_array)
print("\n Cosine Hyperbolic Values :\n",cosh_Values)

