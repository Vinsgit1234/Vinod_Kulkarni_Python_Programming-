a = {1,2,3,4,5,6}
b = {1,2,3,9,8,10}
c = a ^ b
print("Using Operator",c)
a = {1,2,3,4,5,6}
b = {1,2,9,8,10}
c = a.symmetric_difference(b)
print("Using symmetric difference methiod",c)

a = {1,2,3,4,5,6}
b = {1,2,3,9,8,10}
c = a ^ b
print("Using Operator",c)
a = {1,2,3,4,5,6}
b = {1,2,9,8,10}
c = a.symmetric_difference(b)
print("Using symmetric difference methiod",c)

a = {1,2,3,4,5,6}
b = {1,2,3,9,8,10}
c = a ^ b
print("Using Operator",c)
a = {1,2,3,4,5,6}
b = {1,2,9,8,10}
c = a.symmetric_difference(b)
print("Using symmetric difference methiod",c)



