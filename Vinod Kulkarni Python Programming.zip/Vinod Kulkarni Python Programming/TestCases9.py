
def add(a, b):
    print(a, b)
    print('function closed')
    
add(5, 10)
add(10, 15)
add(10000, 100000)

