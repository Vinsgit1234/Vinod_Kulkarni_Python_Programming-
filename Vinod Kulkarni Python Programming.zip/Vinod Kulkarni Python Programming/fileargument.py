import io 
dummy_file = io.stringIO()
print('Python Programming!', file=dummy_file)
print ("Content of file : \n",dummy_file.getvalue())

import io
dummy_file = io.stringIO()
print('Python Programming ', file = dummy_file)
print ("Content of file : \n",dummy_file.getvalue())

import io 
dummy_file = io.stringIO()
print('Python Programing', file = dummy_file)
print('Python Programming',file = dummy_file)
print("Content of file:  \n", dummy_file.getvalue())

import io 
dummy_file = io.stringIO()
print ('Python Programming',file =dummy_file)
print('Python Programming', file = dummy_file)
print("Content of file: \n", dummy_file.getvalue())

import io 
dummy_file = io.stringIO()
print ('Python Programming', file = dummy_file)
print('Python Programming', file = dummy_file)
print("Content of file: \n",dummy_file.getvalue())

import io 
dummy_file = io.stringIO()
print('Python Programming', file = dummy_file)
print('Python Programming', file = dummy_file)
print("Content of file: \n", dummy_file.getvalue())

import io 
dummy_file = io.stringIO()
print('Python Programming', file = dummy_file)
print ('Python programming', file = dummy_file) 
print ("Content of file: \n",dummy_file.getvalue())

