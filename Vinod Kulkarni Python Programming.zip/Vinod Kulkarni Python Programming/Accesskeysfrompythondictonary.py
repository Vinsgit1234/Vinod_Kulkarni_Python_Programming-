my_dict = {'Australia' : 200, 'Germany' : 100, 'Europe' :300, 'Switzerland' : 400 }
find_key = 'Germany'
print("dictonary is :" + str(my_dict))
res = list(my_dict.keys().index(find_key))
print("Index of find key is : "+ str(res))

my_dict = {'Australia' : 200, 'Germany' : 100, 'Europe' : 300, 'Switzerland' :400}
find_key = 'Germany'
print("Dictonary is :" + str(my_dict))
res = list(my_dict.keys().index(find_keys))
print("Index of find key is :"+str(res))

my_dict = {'Australia' :200, 'Germany' : 100, 'Europe' : 300,'Switzerland' :400}
find_key = 'Germany'
print("Dictonary is :" + str(my_dict))
res = list(my_dict.keys().index(find_keys))
print("Index of find key is :"+str(res))

