for i in range(0,3):
    print("I see myself in")
print("In the Mirror")

for i in range(0,3):
    print("We see ourself")
print("In the Mirror")w

for i in range(0,3):
    print("You see Yourself")
print("In the Mirror")

for i in range(0,3):
    print("He Sees Herself")
print("In the mirror")

