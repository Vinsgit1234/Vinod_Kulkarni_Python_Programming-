my_list = [1, 2, None]
print("my_list :", my_list)
my_set = {1, None, 5}
print ("my_set: ", my_set)
my_dict = {'A' : None, 'B' : None }
print("my_dict:" , my_dict)

my_list = [1, 2, None]
print ("my_list:", my_list)
my_set = {1, None, 5}
print ("my set:", my_set)
my_dict = { 'A' : None,'B' : None }
print("my_dict:", my_dict)


