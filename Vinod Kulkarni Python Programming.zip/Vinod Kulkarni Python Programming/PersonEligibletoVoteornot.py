age = int (input("Enter your age?"))
if age>=18:
    print("You are Eligible to Vote")
else:
    print("Sorry! You have to Wait")
    
    
age = int (input("Enter your age?"))
if age>=18:
    print("You are Eligible to Vote")
else:
    print("Sorry! You have to Wait")
    
age = int (input("Enter your age?"))
if age>=18:
    print("You are Eligible to Vote")
else:
    print("Sorry! You have to Wait")
    
age = int((input ("Enter your age")))
if age>=18:
    print("You are Eligibe to vote")
else:
    print("Sorry! You have to Wait")
    
    
    
age = int((input("Enter your age")))
if age>=18:
    print("You are Eligible to vote")
else:
    print("Sorry! You have to Wait")
    
age = int((input("Enter your age")))
if age>=18:
    print("You are Eligible to vote")
else:
    print("Sorry! You have to Wait")
    
