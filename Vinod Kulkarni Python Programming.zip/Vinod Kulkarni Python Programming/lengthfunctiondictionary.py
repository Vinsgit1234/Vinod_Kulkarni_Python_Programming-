dict1 = {10,11,12,13,14,15,16,17,18,19,20}
len=len(dict1)
print("Length of the Dictionary is ",len)


dict1 = {10,11,12,13,14,15,16,17,18,19,20}
len = len(dict1)
print("Length of the Dictionary is ",len)

dict1 = {10,11,12,13,14,15,16,17,18,19,20}
len = len(dict1)
print("Length of the Dictionary is ",len)

dict1 = {10,11,12,13,14,15,16,17,18,19,20}
len = len(dict1)
print("Length of the Dictionary is ",len)

dict1 = {10,11,12,13,14,15,16,17,18,19,20}
len = len(dict1)
print("Length of the Dictionary is ",len)

dict1 = {10,11,12,13,14,15,16,17,18,19,20}
len = len(dict1)
print("Length of the Dictionary is ",len)

