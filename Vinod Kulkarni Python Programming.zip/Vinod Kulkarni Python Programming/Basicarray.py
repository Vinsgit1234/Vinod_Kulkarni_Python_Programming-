from array import *
array_num = array('i',[1,3,5,7,9,])
for i in array_num:
    print(i)
print("Access the first three elements individually")
print(array_num[0])
print(array_num[1])
print(array_num[2])

array_num = array('i',[1,3,5,7,9])
for i in array_num:
    print(i)
print("Access the last three elements individually")
print(array_num[0])
print(array_num[1])
print(array_num[2])

