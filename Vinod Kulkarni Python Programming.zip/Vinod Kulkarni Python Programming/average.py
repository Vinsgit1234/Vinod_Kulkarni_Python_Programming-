numbers = [1,2,3,4,5,1,4,5]
res = sum(numbers)
print("Sum of Given numbers =",res)
average = res/len(numbers)
print("Average of given numbers =",average)

numbers = [1,2,3,4,5,1,4,5]
res = sum(numbers)
print("Sum of Given numbers =",res)
average = res/len(numbers)
print("Average of given numbers =",average)

numbers = [1,2,3,4,5,1,4,5]
res = sum(numbers)
print("Sum of Given numbers =",res)
average = res/len(numbers)
print("Average of given numbers =",average)

numbers = [1,2,3,4,5,1,4,5]
res = sum(numbers)
print("Sum of Given numbers =",res)
average = res/len(numbers)
print("Average of given numbers =",average)



