year=int(input("Enter the Year:- "))
if year % 100 == 0:
    if year%400 == 0:
        print("Entered Year is a Leap Year")
    else:
        print("Entered Year is not a Leap Year")
else:
    if year%4==0:
        print("Entered Year is a Leap Year") 
    else:
        print("Entered Year is not a Leap Year")
    
               