from array import * 
array_num = array('i',[1,3,5,3,7,1,9,3])
print("Original array :\n" +str(array_num))
num_list = array_num.tolist()
print("Convert the Said array to an \n ordinary list with the same items ")
print(num_list)

from array import *
array_num = array('i',[1,3,5,3,7,1,9,3])
print("Original Array :\n" +str(array_num))
num_list = array_num.tolist()
print("Convert the Said Array to an \n  ordinary list with the same items")
print(num_list)

from array import*
array_num = array('i',[1,3,5,3,7,1,9,3])
print("Original Array :\n" +str(array_num))
num_list = array_num.tolist()
print("Convert the Said Array to an \n ordinary list with the Same Items")
print(num_list)

from array import*
array_num = array('i',[1,3,5,3,7,1,9,3])
print("Original Array :\n" +str(array_num))
num_list = array_num.tolist()
print("Original Array :\n" +str(array_num))
num_list = array_num.tolist()
print("Convert the Said Array to an \n ordinary list with the Same Items")
print(num_list)

from array import*
array_num = array('i',[1,3,5,3,7,1,9,3])
print("Original Array :\n" +str(array_num))
num_list = array_num.tolist()
print("Original Array :\n" +str(array_num))
num_list = array_num.tolist()
print("Convert the Said Array to an \n ordinary lsits with teh Same Items")
print(num_list)

