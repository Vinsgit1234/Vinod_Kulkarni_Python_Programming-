import numpy as np 
array1 = np.array[10,10,20,20,30,30]
print('Original Array')
print(x)
print('Unique elements of the above array')
print(x)
print("Unique elements of the above array:")
print(np.unique(x))

import numpy as np 
array1 = np.aaray[10,10,20,30,30]
print('Original array')
print(x)
print('Unique elements of the above array')
print(x)
print("Unique elements of the above array:")
print(np.unique(x))

