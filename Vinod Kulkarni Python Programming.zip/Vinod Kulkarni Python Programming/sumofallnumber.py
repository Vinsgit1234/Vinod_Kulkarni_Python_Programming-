s = 0
n = int(input("Enter the number :- "))
for i in range (1, n+1, 1):
    s += i
    print("Sum is: ", s)

