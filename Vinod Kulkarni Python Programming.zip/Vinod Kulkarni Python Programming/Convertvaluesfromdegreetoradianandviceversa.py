import math 
a = math.pi / 6 
print("The Value of sine of pi/6 is :",end = " ")
print(math.sin(a))
print("The Value of Cosine of pi/6 is :", end = " ")
print(math.cos(a))
print("The Value of Tangent of pi/6 is :",end = " ")
print(math.tan(a))
a = math.pi / 6 
b = 30 
print("The Converted value from radians to degrees is :")
print(math.degrees(a))
print("The Converted value from degree to radians is :")
print(math.radians(b))

import math 
a = math.pi / 6 
print("The value of sine of pi/6 is :",end = " ")
print(math.sin(a))
print("The value of Cosine of pi/6 is :",end = " ")
print(math.cos(a))
print("The value of tangent of pi/6 is :",end = " ")
print(math.tan(a))
a = math.pi /6 
b = 30 
print("The converted values from radians to degree is :")
print(math.degrees(a))
print("The Converted Values from Degree to Radians is :")
print(math.radians(b))

import math 
a = math.pi / 6 
print("The Value of Sine of pi/6 is :", ends = " ")
print(math.sin(a))
print("The Value of Cosine of pi/6 is :",ends = " ")
print(math.cos(a))
print("The Value of Tangent of pi/6 is :",ends = " ")
print(math.tan(a))
a = math.pi/6 
b = 30 
print("The Converted Value from radians to degrees to degrees is :")
print(math.degrees(a))
print("The Converted Values from degrees to Radians is :")
print(math.radians(b))

import math 
a = math.pi / 6 
print(math.sin(a))
print("The Value of cosine of pi/6 is :" ends = " ")
print(math.cos(a))
print("The Value of Sin of pi/6 is :" ends = " ")
print(math.tan(a))
a = math.pi/6
b = 30 
print("The Converted Value from radians to degrees is :")
print(math.degrees(a))
print("The converted value from degrees to radians is :")
print(math.radians(b))

