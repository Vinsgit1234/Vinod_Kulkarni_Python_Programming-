Dict = {5 : 'Welcome', 6 : 'To', 7 :' College',
        'A' : {1: 'Hari', 2 : 'Latha', 3 : 'Amita'},
        'B' : {1 : 'Computer', 2 : 'Science'}}
print("Initial Dictionary:")
print(Dict)
del Dict[6]
print("\nDeleting a specific key :")
print(Dict)
del Dict ['A'][2]
print("\n Deleting a key from Nested Dictionary")
print(Dict)



