string_one= input("Enter First String")
string_two= input("Enter Second String")
if string_one == string_two: 
    print("Both the Strings are Equal")
elif string_one<string_two:
    print("First String is Less Than Senond String")
else:
    print("First String is Greater Than Second String")
    
string_one = input("Enter First String")
string_two = input("Enter Second String")
if string_one == string_two:
    print("Both the Strings are Equal")
elseif string_one