List_one = [2,3,4,5,6,7,8,9,10]
print(5 in List_one)
print(11 in List_one)
print(12 not in List_one)

List_one = [2,3,4,5,6,7,8,9,10]
print(5 in List_one)
print(11 in List_one)
print(12 not in List_one)

List_one = [2,3,4,5,6,7,8,9,10]
print(5 in List_one)
print(11 in List_one)
print(12 not in List_one)

List_one = [2,3,4,5,6,7,8,9,10]
print(5 in List_one)
print(11 in List_one)
print(12 not in List_one)

List_one = [2,3,4,5,6,7,8,9,10]
print(5 in List_one)
print(11 in List_one)
print(12 not in List_one)

List_one = [2,3,4,5,6,7,8,10]
print(5 in List_one)
print(11 in List_one)
print(12 not in List_one)

