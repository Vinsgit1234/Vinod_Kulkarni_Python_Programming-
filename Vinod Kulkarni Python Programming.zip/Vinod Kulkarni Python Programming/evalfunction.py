x = eval(input("Enter the Integer"))
print(type(x))
x = eval(input("Enter the Boolean"))
x = eval(type(x))
x = eval('10+56+23')
print("Sum =",x,type(x))


x = eval(input("Enter the Integer"))
print(type(x))
x = eval(input("Enter the Boolean"))
x = eval(type(x))
x = eval('10+56+23')
print("Sum =",x,type(x))

x = eval(input("Enter the Integer"))
print(type(x))
x = eval(input("Enter the Boolean"))
x = eval(type(x))
x = eval('10+56+23')
print("Sum" ,x,type(x))

x = eval(input("Enter the Boolean"))
print(type(x))
x = eval("Enter the Boolean")
x = eval(type(x))
x = eval('10+56+23')
print("Sum",x,type(x))

x = eval(input("Enter the Boolean"))
print(type(x))
x = eval("Enter the Boolean")
x = eval(type(x))
x = eval('10+56+23')
print("Sum",x,type(x))


