list = [10, 'diploma', 20.6,'x']
