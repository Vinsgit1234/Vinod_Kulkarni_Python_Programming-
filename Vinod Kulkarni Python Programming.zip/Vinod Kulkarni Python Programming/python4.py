print("They have asked, " "Whats there in box")
print("They have asked," "Whats there in box?")
print("They asked.\"Whats there in Box?\"")
     