List_one = ['Mon','Tue','Wed']
List_two = [30,40,50]
print(List_one<List_two)
print(List_two>List_one)
print(List_one>=List_two)
print(List_two<=List_one)

List_one = ['Mon','Tue','Wed']
List_two = [30,40,50]
print(List_one<List_two)
print(List_two>List_one)
print(List_one>=List_two)
print(List_two<=List_one)

List_one = ['Mon','Tue','Wed']
List_two = [30,40,50]
print(List_one<List_two)
print(List_two>List_one)
print(List_one>=List_two)
print(List_one>=List_two)
print(List_two<=List_one)

