import numpy as np 
in_array = [.5, 1.5, 2.5, 3.5, 4.5, 10.1]
print("Input array = np.around(in_array)")
round_off_values = np.around(in_array)
print("\n Rounded values :\n",round_off_values)
in_array = [.53, 1.56, .71]
print("\n Input array : \n",in_array)
round_off_values = np.round_(in_array)
print("\n Rounded Values ")
