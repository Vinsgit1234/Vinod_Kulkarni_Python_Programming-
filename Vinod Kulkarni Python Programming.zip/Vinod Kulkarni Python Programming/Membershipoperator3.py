set = {28,32,47,56}
print(47 in set)
print(65 not in set)
print(28 in set)
print(56 in set)

set = {28,32,47,56}
print(47 in set)
print(65 not in set)
print(28 in set)
print(56 in set)

set = {28,32,47,56}
print(47 in set)
print(65 not in set)
print(28 in set)
print(56 in set)

set = {28,32,47,56}
print(47 in set)
print(65 not in set)
print(28 in set)
print(56 in set)
print(32 in set)

