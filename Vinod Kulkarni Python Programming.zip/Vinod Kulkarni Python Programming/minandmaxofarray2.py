arr = [3, 7, 2, 9, 4]
minimum, maximum = find_min_max(arr)
print("Minimum:", minimum)
print("Maximum:", maximum)