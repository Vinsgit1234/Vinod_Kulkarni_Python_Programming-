a = ['apple','banana','grapes','orange','guava']
print("Contents of List",a)
a[1]= 10 
a[2] = 300
print("Contents of list after Modification",a)
b = 'Polytechnic'
b[2] = G

a = ['Apple','Banana','Graped','Oranges','Guava']
print("Contents of List",a)
a[1] = 10 
a[2] = 300 
print("Content of the List After Modification",a)
b = 'Polytechnic'
b [2] = G