fruit = list('Apple')
print("Converting string to list",fruit)
data = list(range(0,10,2))
print("List using range function",data)

fruit = list('Apple')
print("Converting string to list",fruit)
data = list(range(0,10,2))
print("List using range function",data)

fruit = list('Apple')
print("Converting string to list",fruit)
data = list(range(0,10,2))

fruit = list('Apple')
print("Converting string to list",fruit)
data = list(range(0,10,2))
print("List using range function",data)

fruit = list('Apple')
print("Converting string to list",fruit)
data = list(range(0,10,2))
print("List using range function",data)

fruit = list('Apple')
print("Converting string to list",fruit)
data = list(range(0,10,2))
print("List using range function",fruit)

fruit = list('Apple')
print("Converting string to a list",fruit)
data = list(range(0,10,2))
print("List using range Function",fruit)

