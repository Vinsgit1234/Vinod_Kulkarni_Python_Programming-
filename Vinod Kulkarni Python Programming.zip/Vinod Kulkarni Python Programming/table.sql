CREATE TABLE table_name (col_1 datatype,
                         col_2 datatype,
                         col_3 datatype);
