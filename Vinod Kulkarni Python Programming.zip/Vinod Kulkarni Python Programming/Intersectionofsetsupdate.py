a = {"Devansh","bob","castle"}
b = {"castle","dude","emyway"}
c = {"fuson","gaurav","castle"}
a.intersection_update(b,c)
print("Intersection Update = ",a)

a = {"Devansh","bob","castle"}
b = {"castle","dude","emyway"}
c = {"fuson","gaurav","castle"}
a.intersection_update(b,c)
print("Intersection Update = ",a)

a = {"Devansh","bob","castle"}
b = {"castle","dude","emway"}
c = {"fuson","gaurav","castle"}
a.intersection_update(b,c)
print("Intersection Update = ",a)

a = {"Devansh","BoB","Castle"}
b = {"Castle","Dude","Emway"}
c = {"Fuson","Gaurav","Castle"}
a.intersection_update(b,c)
print("Intersection update = ",a)

a = {"Devansh","Bob","Castle"}
b = {"Castle","Dude","Enemy"}
c = {"Fusion","Gaurav","Castle"}
a.intersection_update(b,c)
print("Intersection update = ",a)

a = {"Devansh","Bob","Castle"}
b = {"Castle","Dude","Enemy"}
c = {"Fusion","Gaurav","Castle"}
a.intersection_update(b,c)
print("Intersection update = ",a)

a = {"Devansh","Bob","Castle"}
b = {"Castle","Dude","Enemy"}
c = {"Fusion","Gaurav","Castle"}
a.intersection_update(b,c)
print("Intersection update = ",a)


