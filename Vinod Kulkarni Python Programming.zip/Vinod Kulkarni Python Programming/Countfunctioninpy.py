list1 = [10,40,30,40,10,10,10,10,10,40,50]
print("Count of 40 is == ",list1.count(40))
list2 = ['cat','bat','mat','cat','pet']
print("Count of cat is == ",list2.count('cat'))

list1 = [10,40,30,40,10,10,10,10,10,40,50]
print("Count of 40 is == ",list1.count(40))
list2 = ['cat','bat','mat','cat','pet']
print("Count of Cat is = ",list2.count('cat'))

list1 = [10,40,30,40,10,10,10,10,10,40,50]
print("Count of 40 is ==",list1.count(40))
list2 = ['cat','bat','mat','cat','pet']
print("Count of Cat is = ",list2.count('cat'))

list1 = [10,40,30,40,10,10,10,10,10,40,50]
print("Count of 40 is == ",list1.count(40))
list2 = ['cat','bat','mat','cat','pet']
print("Count of Cat is = ",list2.count ('cat'))

list1 = [10,40,30,40,10,10,10,10,10,40,50]
print("Count of 40 is == ",list1.count(40))
list2 = ['cat','bat','mat','cat','pet']
print("Count of Cat is = ",list2.count('cat'))

list1 = [10,40,30,40,10,10,10,10,40,50]
print("Count of 40 is == ",list1.count(40))
list2 = ['cat','bat','mat','cat','pet']
print("Count of Cat is = ",list2.count('cat'))

list1 = [10,40,30,40,10,10,10,10,40,50]
print("Count of 40 is == ",list1.count(40))
list2 = ['cat','bat','mat','cat','pet']
print("Count of Cat is =",list2.count('cat'))

list1 = [10,40,30,40,10,10,10,40,50]
print("Count of 40 is ==",list1.count(40))
list2 = ['cat','bat','mat','cat','pet']
print("Count of Cat is =",list2.count(cat))

list1 = [10,40,30,40,10,10,10,40,50]
print("Count of 40 is ==",list1.count(40))
list2 = ['cat','bat','mat','cat','pet']
print("Count of Cat is =",list2.count(cat))

list1 = [10,40,30,40,10,10,10,40,50]
print("Count of 40 is ==",list1.count(40))
list2 = ['cat','bat','mat','cat','pet']
print("Count of Cat is =",list2.count(cat))
print("Count of Cat is =",list2.count(cat))

list1 = [10,40,30,40,10,10,10,40,50]
print("Count of 40 is == ",list1.count(40))
list2 = ['cat','bat','mat','cat','pet']
print("Count of Cat is =",list2.count(cat))
print("Count of Cat is =",list2.count(cat))

list1 = [10,40,30,40,10,10,10,40,50]
print("Count of 40 is == ",list1.count(40))
list2 = ['cat','bat','mat','cat','pet']
print("Count of Cat is =",list2.count(cat))
print("Count of Cat is =",list2.count(cat))

