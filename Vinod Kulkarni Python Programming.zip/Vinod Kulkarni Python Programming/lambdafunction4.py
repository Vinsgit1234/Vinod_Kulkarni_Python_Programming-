import math
def square():
    n = lambda x : x*x
print(n)

square(2)




    