n = int(input("Enter the number"))
if n == 13:
    for n in range(0,13):
        if n % 10 == 0:
            count (n)
            print(n)
            
n = int(input("Enter the number"))
if n == 13:
    for n in range(0,13):
        if n % 10 == 0:
            count (n)
            print(n)
            
n = int(input("Enter the nunmber"))
if n == 13:
    for n in range(0,13):
        if n % 10 == 0:
            count (n)
            print(n)
            

            
