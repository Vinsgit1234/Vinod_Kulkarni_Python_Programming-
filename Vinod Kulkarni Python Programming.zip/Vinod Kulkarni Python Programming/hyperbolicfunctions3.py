import numpy as np 
import math 
in_array = [0, math.pi/2, np.pi / 5, np.pi]
print("Input array :\n",in_array)
sinh_values = np. sinh(in_array)
print("\nSine Hyperbolic Values : \n", Sinh_values)

import numpy as np 
import math 
in_array = [0, math.pi/2, np.pi /5, np.pi]
print("Input array :\n",in_array)
sinh_values = np.sinh(in_array)
print("\n Sine Hyperbolic Values : \n",Sinh_values)

import numpy as np 
import math 
in_array = [0, math.pi/2, np.pi /5,np.pi ]
print("Input array :\n",in_array)
sinh_values = np.sinh(in_array)
print("\n Sine Hyperbolic Values : \n",Sinh_values)

import numpy as np 
import math 
in_array = [0, math.pi/2, np.pi/5 , np.pi]
print("Input array :\n",in_array)
sinh_values = np.sinh(in_array)
print("\n Sine Hyperbolic Values : \n",Sinh_values)

import numpy as np 
import math 
in_array = [0, math.pi/2, np.pi/5, np.pi]
print("Input array :\n",in_array)
sinh_values = np.sinh(in_array)
print("\n Sine Hyperbolic Values :\n",Sinh_Values)

import numpy as np 
import math 
in_array = [0, math.pi/2, np.pi/5, np.pi]
print("Input array :\n",in_array)
sinh_values = np.sinh(in_array)
print("\n Sine Hyperbolic Values :\n",Sinh_Values)

import numpy as np 
import math 
in_array = [0,math.pi/2, np.pi/5, np.pi]
print("Input array :\n",in_array)
sinh_values = np.sinh(in_array)
print("\n Sine Hyperbolic Values :\n",Sinh_Values)

