i = int(input("Enter the number :- "))
for i in range(0,i+1,1):
    if i%2 == 0:
        print(i,"The Given Number is a Even Number")
    else:
        print(i,"The Given Number is Odd Number")
    
    
    
