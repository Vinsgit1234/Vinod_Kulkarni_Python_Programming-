def find_min_max(arr):
    arr= [3,7,2,9,4]
    if not arr:
        return None, None  # Handle empty array case
    return min(arr), max(arr)

