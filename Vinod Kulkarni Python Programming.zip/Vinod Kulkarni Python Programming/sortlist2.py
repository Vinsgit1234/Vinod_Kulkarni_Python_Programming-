list = [2,1,3,5,3,8]
print ("Original List:",list)
list.sort()
print("List after sorting:",list)

list = [2,1,3,5,3,8]
print ("Original List:",list)
list.sort()
print("List after sorting:",list)

list = [2,1,3,5,3,8]
print ("Original List:",list)
list.sort()
print("List after sorting:",list)


