num_set = set([0,1,3,4,5])
print("Original Set")
print(num_set)
num_set.pop()
print("\After removing the first element"
      "\n from the said set:")
print(num_set)

num_set = set([0,1,3,4,5])
print("Original Set")
print(num_set)
num_set.pop()
print("\After removing the first element"
        "\n from the said set:")
print(num_set)

num_set = set([0,1,3,4,5])
print("Original set:")
print(num_set)
num_set.pop()
print("\After removing the first element"
        "\n from the said set:")
print(num_set)

