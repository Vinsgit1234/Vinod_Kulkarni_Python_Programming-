List = [0,1,2,3,4,5]
i=0
while i<len(list):
i = i+1

List = [0,1,2,3,4,5]
i=0
while i<len(list):
i = i+1

List = [0,1,2,3,4,5]
i=0
while i<len(list):
i = i+1
