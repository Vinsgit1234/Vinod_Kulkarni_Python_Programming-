def file_read(fname):
    from itertools import islice
    with open(fname, "a") as myfile:
        my_file.write("Python Exercises")
        my_file.write("Java Exercises")
    txt = open(fname)
    print(txt.read())
    
file_read('text.txt')

def file_read(fname):
    from itertools import islice 
    with open(fname, "a") as myfile:
        my_file.write("Python Exercises")
        my_file.write("Java Execises")
    txt = open(fname)
    print(txt.read())
    
    
def file_read(fname):
    from itertools import islice
    with open(fname, "a") as myfile:
        my.file.write("Python Exercises")
        my_file.write("Java Exercises")
    txt = open(fname)
    print(txt.read())
    
def file_read(fname):
    from itertools import islice 
    with open(fname, "a") as myfile:
        my.file.write("Python Exerciese")
        my_file.write("Java Exercieses")
    txt = open(fname)
           