print("Computer Science")
print ("Computer\n Science")
print ("Computer \t Science ")

print("Compuetr Science")
print ("Computer \n Science")
print ("Computer \t Science")

print("Computer Science")
print ("Computer \n Science")
print ("Computer \t Science")

print ("Computer Science")
print ("Computer \n Science")
print ("Computer \t Science")

print ("Computer Science")
print ("Computer \n Science")
print ("Computer \t Science ")

print ("Computer Science")
print ("Computer \n Science")
print ("Computer \t Science")

