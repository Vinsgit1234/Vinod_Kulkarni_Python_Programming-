num = int (input("Enter the number:- "))
if num < 0:
    print("absolute value :", num*-1)
else:
    print("Absolute Value :", num)
    
num = int (input ("Enter  the number :- "))
if num < 0:
    print ("Absolute Value :", num*-1)
else:
    print("Absolute Value :", num)
    
num = int (input("Enter the number :-"))
if num < 0:
    print("Absolute Value :", num*-1)
else:
    print("Absolute Value :",num)

num = int (input("Enter the number :-"))
if num < 0:
    print("Absolute Value :", num*-1)
else:
    print("Absolute Value :", num)

    
