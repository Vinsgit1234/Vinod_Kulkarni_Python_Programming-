def bar(x=[]):
    x.append(1)
    return x 
print(bar())
print(bar())

def bar(x=[]):
    x.append(1)
    return x 
print(bar())
print(bar())

