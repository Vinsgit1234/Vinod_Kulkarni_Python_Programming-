def foo():
    yield 1 
    return 2 
g = foo()
print(next(g))
print(next(g))

