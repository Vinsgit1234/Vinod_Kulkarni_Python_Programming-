def normal_test():
    return "Hello World"
def generator_test():
    yield "Hello World"
print(normal_test())
print(generator_test())

def normal_test():
    return "Hello World"
def generator_test():
    yield "Hello World"
print(normal_test())
print(generator_test())

def normal_test():
    return "Hello World"
def generator_test():
    yield "Hello World"
print(normal_test())
print(generator_test())