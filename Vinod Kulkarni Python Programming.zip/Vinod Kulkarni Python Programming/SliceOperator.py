s = "Python"
print ("[] operator : ",s[3])

s = "Python"
print ("[] operator : ", s[3])

s = "Python"
print ("[] operator  : ", s[3])

s = "Python"
print ("[] operator : ", s[3])

s = "Python"
print ("[] operator : ", s[3])

s = "Python"
print ("[] operator :", s[3])

s = "Python"
print ("[] operator :", s[3])

s = "Python"
print("[] operator :", s[3])

s = "Python"
print ("[] operator :",  s[3])

s = "Python"
print ("[] operator : ", s[3])

s = "Python"
print ("[] operator :", s[3])

s = "Python"
print ("[] operator : ", s[3])

s = "Python"
print ("[] operator : ", s[3])


