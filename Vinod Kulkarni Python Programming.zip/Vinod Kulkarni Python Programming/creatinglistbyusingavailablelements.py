list = [10,'diploma',20.6,'x']
print("List Elements of different"
      "datatypes",list)

