def simple_intrest(p,t,r):
    return (p*t*r)/100
p = float(input("Enter the Principle Amount = "))
r = float(input("Enter the Rate of Intrest=="))
t = float(input("Enter the time in years = "))
print("Simple Intrest:",simple_intrest(p,r,t))

def simple_intrest(p,t,r):
    return (p*t*r)/100
p = float(input("Enter the Principle Amount ="))
r = float(input("Enter the Rate of Intrest=="))
t = float(input("Enter the Time in Years ="))
print("Simple Interest:",simple_intrest(p,r,t))

def simple_intrest(p,t,r):
    return (p*t*r)/100
p = float(input("Enter the Principle Amount ="))
r = float(input("Enter the Rate of Intrest == "))
t = float(input("Enter the Time in Years ="))
print("Simple Intrest :",simple_intrest(p,r,t))


def simple_intrest(p,t,r):
    return (p*t*r)/100
p = float(input("Enter the Principle Amount"))
r = float(input("Enter the Rate of Intrest == "))
t = float (input("Enter the Time in Years ="))
print("Simple Intrest :",simple_intrest(p,r,t))