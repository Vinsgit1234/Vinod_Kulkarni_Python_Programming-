class A:
    def __init__(self):
        self.x = 1
a = A()
b = a 
b.x = 5 
print(a.x)

