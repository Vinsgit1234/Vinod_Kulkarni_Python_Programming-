from _future_ import print_function
for i in range(1,5):
    for j in range(i):
        print (i, end = " ")
    print()
    
    
from _future_ import print_function
for i in range(1,5):
    for j in range(i):
        print(i,end = " ")
    print()
    
from _future_ import print_function
for i in range(1,5):
    for j in range(i):
        print(i,end = " ")
    print()
    
    
    