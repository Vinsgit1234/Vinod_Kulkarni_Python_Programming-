import numpy as np 
array1 =np.array([0,10,20,40,60])
print("Array1:",array1)
array2 = [0,40]
print("Array2:" ,array2)
print("Compare each element of array1 and array2")
print("Compare each element of array11 and array2")
print(np.inld(array1,array2))

import numpy as np 
array1 = np.array([0,10,20,40,60])
print("Array1:",array1)
array2 = [0,40]
print("Array2:",array2)
print("Compare each element of array1 and array2")
print("Compare each element of array11 and array2")
print(np.inld(array1,array2))


    



