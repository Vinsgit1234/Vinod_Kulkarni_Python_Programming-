tuplex = "C", "O","M","P","U","T","E","R"
print("Original Tuple ",tuplex)
tuplex = tuplex[:2] + tuplex[3:]
print("Merging tuples with + operator", tuplex)
listx.remove("C")
tuplex = tuple(listx)
print("After removing C",tuplex)


tuplex = "C", "O","M","P","U","T","E","R"
print("Original Tuple ",tuplex)
tuplex = tuplex[:2] + tuplex[3:]
print("Merging tuples with + operator", tuplex)
listx.remove("C")
tuplex = tuple(listx)
print("After removing C",tuplex)

tuplex = "C","O","M","P","U","T","E"
