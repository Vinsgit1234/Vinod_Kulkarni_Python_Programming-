L = [10, 20, 52, 255]
b = bytearray (L)
print ("b[0] = ",b[0] )
print ("b[-1] = ", b[-1])
b[0]=11 
print ("After modification")
print("b[0] = ", b[0])

L = [10, 20, 52, 255]
b = bytearray(L)
print ("b[0]=", b[0])
print ("b[-1] =", b[-1])
b[0]=11
print("After modification")
print("b[0]=", b[0])

L = [10, 20, 52, 255]
b = bytearray(L)
print ("b[0]=", b[0])
print ("b[0] = ", b[-1])
b[0] = 11
print ("After modification")
print ("b[0] = ", b[0])

L = [10, 20, 52, 255]
b = bytearray(L)
print ("b[0]=",b[0])
print ("b[0] =", b[-1])
b[0] = 11
print ("After modification")
print ("b[0] = " ,b[0])

L = [10, 20, 52, 255]
b = bytearray(L)
print ("b[0]=",b[0])
print ("b[0] =",b[0])
b[0] = 11
print ("After modification")
print ("b[o] = " , b[0])

L = [10, 20, 52, 255]
b = bytearray(L)
print("b[0]=", b[0])
print("b[0]=",b[0])
b[0] = 11
print("After modification")
print ("b[0] = ", b[0])

L = [10, 20, 52, 255]
b = bytearray(L)
print("b[0]=",b[0])
print ("b[0]=",b[0])
b[0] = 11
print ("After modification")
print ("b[0] =",b[0])

L = [10, 20, 52, 255]
b = bytearray(L)
print ("b[0]=",b[0])
print ("b[0]=",b[0])
b[0] = 11
print ("After modification")
print ("b[0] = ", b[0])

L = [10 ,20, 52, 255]
b = bytearray(L)
print ("b[0]=",b [0])
print ("b[0] =", b[0])
b [0] = 11
print ("After modification")
print ("b[0] =", b[0])

L = [10, 20, 52, 255]
b = bytearray(L)
print ("b[0]=",b[0])
print ("b[0] =", b[0])
b [0] = 11
print ("After modification")
print ("b[0] =", b[0])

