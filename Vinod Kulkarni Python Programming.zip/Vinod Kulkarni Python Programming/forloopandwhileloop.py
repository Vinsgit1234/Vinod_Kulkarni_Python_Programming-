for i in range (5):
    print(i)
    
c = 0
while c < 5:
    print(c)
    c += 1 
    
import math
n = 7.3 
f_num = math.floor(n)
print(f_num)

