def fun():
    b = 23
    print("The Value of b inside fun = ",b)
    
def fun1():
    print("The value of b inside fun= ",b)
    
    