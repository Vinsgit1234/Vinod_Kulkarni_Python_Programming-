a = "sudha"
b = "sudha"
print ("reference of a :", id(a))
print ("reference of b :", id(b))
print ("a is b:",a is b)
print ("a is not b:", a is not b)

a = "sudha"
b = "sudha"
print ("reference of a : ", id(a))
print ("reference of b:", id(b))
print ("a is b:",a is b)
print ("a is not b:",a is not b)

a = "sudha"
b = "sudha"
print ("reference of a : ", id(a))
print ("refernce of b:", id (b))
print ("a is b:",a is b)
print ("a is not b:",a is not b)

a = "sudha"
b = "sudha"
print ("reference of a :", id(a))
print ("reference of b :", id(b))
print ("a is b :",a is b)
print ("a is not b:",a is not b)

a = "sudha"
b = "sudha"
print ("reference of a :", id (a) )
print ("reference of b :", id(b))
print ("a is b:",a is b)
print ("a is not b:",a is not b)

a = "sudha"
b = "sudha"
print ("reference of a :",id (a))
print ("reference of b:",id (b))
print ("a is b",a is b)
print ("a is not b:",a is not b)

