Employee = {"Name": "John",
            "Age":29,
            "Salary":25000,
            "Company": "GOOGLE"}
for x in Employee:
    print(x)
    
Employee = {"Name": "John",
            "Age":29,
            "Salary":25000,
            "Company":"Google"}
for x in Employee:
    print(x)
    
Employee = {"Name": "John",
            "Age":29,
            "Salary":25000,
            "Company":"Google"}
for x in Employee:
    print(x)
    
Employee = {"Name": "John",
              "Age":29,
              "Salary": 25000,
              "Company":"Google"}
for x in Employee:
    print(x)

Employee = {"Name" : "John",
            "Age":29,
            "Salary": 25000,
            "Company": "Google"}
for x in Employee:
    print(x)
    
    
    