Dict = {5 : 'Welcome', 6 : 'To', 7 : 'College'
        'A' : {1: 'Hari',2 'Latha',3:'Amita'},
        'B' : {1 'Computer', 2 :'Science'}
print("Initial Dictionary")
print(dict)
del Dict[6]
print("\n Deleting a Specific Key:")
print(Dict)
del Dict['A'][2]
print("\n Deleting a Key From Nested Dictionary")
print(Dict)

