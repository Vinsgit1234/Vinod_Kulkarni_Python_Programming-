days = []
print("This is an empty list ",days)
print("Type of Data =",type(days))
days_list = ['mon','tue','wed']
print("List with arguments=",days_list)
print("Type of Data=",type(days))

days = []
print("This is an Empty List",days)
print("Type of Data =",type(days))
days_list = ['mon','tue','wed']
print("List with arguments=",days_list)
print("Type of Data=",type(days))

