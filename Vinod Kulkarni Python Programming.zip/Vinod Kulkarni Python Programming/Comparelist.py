list1 = [1,2,4,3]
list2 = [1,2,5,8]
list3 = [1,2,5,8,10]
list4 = ['a','b','c']
print("Comparision of list2 with list1")
print(cmp(list2,list2))
print("Comparision of list2 with list3(larger.size)")
print(cmp(list2,list3))
print("Comparision of list3 with list4:",)
print(cmp(list3,list4))

list1 = [1,2,4,3]
list2 = [1,2,5,8]
list3 = [1,2,5,8,10]
list4 = ['a','b','c']
print("Comparision of list2 with list1")
print(cmp(list2,list2))
print("Comparision of list2 with list3(larger.size)")
print(cmp(list2,list3))
print("Comparision of list3 with list4:",)
print(cmp(list3,list4))

list1 = [1,2,4,3]
list2 = [1,2,5,8]
list4 = ['a','b','c']
print(cmp(list2,list2))
print("Comparision of list2 with list3(larger.size)")
print(cmp(list2,list3))
print("Comparision of list3 with list4:",)
print(cmp(list3,list4))

list1 =[1,2,4,3]
list2 = [1,2,5,8]
list4 = ['a','b','c']
print(cmp(list1,list2))
print("Comparision of list2 with list3(larger.size)")
print(cmp(list2,list3))
print("Comparision of list3 with list4:",)
print(cmp(list3,list4))

list1 = [1,2,4,3]
list2 = [1,2,5,8]
list4 = ['a','b','c']
print(cmp(list1,list2))
print("Comparision of list2 with list3(larger.size)")
print(cmp(list2,list3))
print("Comparision of list3 with list4:",)
print(cmp(list3,list4))

