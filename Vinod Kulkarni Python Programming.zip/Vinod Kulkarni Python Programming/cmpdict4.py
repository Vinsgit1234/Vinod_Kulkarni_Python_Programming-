dict1 = {'1','2','3','4','5','6','7','8'}
dict2 = {'1','2','3','4','5','6','7','8'}
cmp=cmp(dict1)=cmp(dict2)
print("Comparing dict1 with dict2 we Get",cmp)


