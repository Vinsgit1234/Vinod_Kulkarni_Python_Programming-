Months = set["January","February","March","April","May","June"]
print("Printing the Original Set....")
print(Months)
print("Removing some months from the set")
Months.pop()
Months.pop()
print ("\nPrinting the modified")
print(Months)

Months = set["January","February","March","April","May","June"]
print("Printing the Original Set...") 
print(Months) 
print("Removing some months from the set")
Months.pop()
Months.pop()
print("\nPrinting the modified")
print(Months)



  
    
    