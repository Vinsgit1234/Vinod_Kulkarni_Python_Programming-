Tuple1 = (10,20,30)
Tuple2 = (40,50,60)
Tuple3 = Tuple1 + Tuple2 
print("Concatination result=",Tuple3)
Tuple2 = 10 
Tuple4 = Tuple1 + Tuple2 
print(Tuple4)

Tuple1 = (10,20,30)
Tuple2 = (40,50,60)
Tuple3 = Tuple1 + Tuple2 
print("Concatination result=",Tuple3)
Tuple2 = 10 
Tuple4 = Tuple1 + Tuple2 
print(Tuple4)

Tuple1 = (10,20,30)
Tuple2 = (40,50,60)
Tuple3 = Tuple1 + Tuple2 
print("Concatination  results",Tuple3)
Tuple2 = 10
Tuple4 = Tuple1 + Tuple2 
print(Tuple4)

Tuple1 = (10,20,30)
Tuple2 = (40,50,60)
Tuple3 = Tuple1 + Tuple2 
print("Concatination results",Tuple3)
Tuple2 = 10
Tuple4 = Tuple1 + Tuple2 
print(Tuple4)

Tuple1 = (10,20,30)
Tuple2 = (40,50,60)
Tuple3 = Tuple1 + Tuple2
print("Concatination results",Tuple3)
Tuple2 = 10
Tuple4 = Tuple1 + Tuple2 
print(Tuple4)

Tuple1 = (10,20,30)
Tuple2 = (40,50,60)
Tuple3 = Tuple1 + Tuple2 
print("Concatination results",Tuple3)
Tuple2 = 10
Tuple4 = Tuple1 + Tuple2
print(Tuple4)

Tuple1 = (10,20,30)
Tuple2 = (40,50,60)
Tuple3 = Tuple1 + Tuple2 
print("Concatination results",Tuple3)
Tuple2 = 10
Tuple4 = Tuple1 + Tuple2 
print(Tuple4)

Tuple1 = (10,20,30)
Tuple2 = (40,50,60)
Tuple3 = Tuple1 + Tuple2 
print("Concatanation results",Tuple3)
Tuple2 = 10 
Tuple4 = Tuple1 + Tuple2 
print(Tuple4)

