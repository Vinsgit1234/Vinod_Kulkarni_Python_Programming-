a = 10 
b = a 
print ('value of b:',b)
b += a 
print ('Add and assign:',b)
b -= a
print ('Subtract and assign:',b)
b *= a
print ('Mulitiply and assign:',b)
b <<= a
print ('bitwise shift :',b)

a = 10 
b = a
print ('Value of b:',b)
b += a 
print ( 'Add and assign:',b)
b -= a 
print ('subtract and assign',b)
b *= a 
print  ('Multiply and assign',b)
b <<= a
print ('bitwise shift :',b)

a = 10
b = a
print ('Value of b:', b)
b += a 
print ('Add and assign')
b -= a
print ('Subtract and assign',b)
b *= a 
print ('Multiple and assign',b)
b <<= a 
print ('bitwise shift :',b)