my_list = ["Hari",3,"Sudha","Madhu",4.8, "z"]
print("my_List = ",my_list)
if "Ami" not in my_list: 
    print("Item not found")
else:
    print("Item found")

my_list = ["Hari",3,"Sudha","Madhu",4.8,"z"]
print("my_List = ",my_list)
if "Ami" not in my_list:
    print("Item not found")
else:
    print("Item Found")
    
my_list = ["Hari",3,"Sudha","Madhu",4.8,"z"]
print("my_List = ",my_list)
if "Ami" not in my_list:
    print("Item not found")
else:
    print("Item not Found")
    
my_list = ["Hari",3,"Sudha","Madhu",4.8,"z"]
print("my_list = ",my_list)
if  "Ami" not in my_list:
    print("Item not Found")
else:
    print("Item not Found") 
    
my_list = ["Hari",3,"Sudha","Madhu",4.8,"z"]
print("my_list = ",my_list)
if "Ami" not in my_list:
    print("Item not Found")
else:
    print("Item not Found")
    
