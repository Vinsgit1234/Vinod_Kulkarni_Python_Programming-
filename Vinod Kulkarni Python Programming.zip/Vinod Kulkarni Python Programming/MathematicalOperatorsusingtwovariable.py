num1 = int(input("Enter First number"))
num2 = int (input("Enter second number"))
op = input("Enter mathematical Operator")
if op == '+':
    print("Result is ", num1 + num2 )
if op == '-':
    print("Result is ", num1 - num2)
if op == '*':
    print ("Result is ",num1 * num2)
if op == '-':
    print("Result is ", num1 - num2 )
    
num1 = int(input("Enter First number"))
num2 = int (input("Enter second number"))
op = input("Enter mathematical Operator")
if op == '+':
    print("Result is ", num1 + num2 )
if op == '-':
    print("Result is ", num1 - num2)
if op == '*':
    print ("Result is ",num1 * num2)
if op == '-':
    print("Result is ", num1 - num2 )
    
num1 = int(input("Enter First number"))
num2 = int (input("Enter second number"))
op = input("Enter mathematical Operator")
if op == '+':
    print("Result is ", num1 + num2 )
if op == '-':
    print("Result is ", num1 - num2)
if op == '*':
    print ("Result is ",num1 * num2)
if op == '-':
    print("Result is ", num1 - num2 )
    
num1 = int(input("Enter First number"))
num2 = int (input("Enter second number"))
op = input("Enter mathematical Operator")
if op == '+':
    print("Result is ", num1 + num2 )
if op == '-':
    print("Result is ", num1 - num2)
if op == '*':
    print ("Result is ",num1 * num2)
if op == '-':
    print("Result is ", num1 - num2 )

num1 = int(input("Enter First number"))
num2 = int (input("Enter second number"))
op = input("Enter mathematical Operator")
if op == '+':
    print("Result is ", num1 + num2 )
if op == '-':
    print("Result is ", num1 - num2)
if op == '*':
    print ("Result is ",num1 * num2)
if op == '-':
    print("Result is ", num1 - num2 )    



    
    

    
