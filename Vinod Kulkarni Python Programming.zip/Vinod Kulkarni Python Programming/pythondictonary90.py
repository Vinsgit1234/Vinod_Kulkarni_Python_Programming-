my_dict = {'Mon' : 4, 'Tue': 6, 'Wed': 9,'Thur':7,'Fri' : 5}
index_key = 'Wed'
out = list(my_dict.items())
new_value = [x for x, key in enumerate(out) if key[0] = index_key]
print("Index of Search key is :" + str(new_value))
