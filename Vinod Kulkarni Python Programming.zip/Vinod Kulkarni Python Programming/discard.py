months = set["January","February","March","April","May","June"]
print ("Printing the Original Set")
print(months)
print("\n Removing some months from the set....")
months.discard("January"):
months.discard("May"):
print("\nPrinting the Modified Set...")
print(months)

Months = set["January","February","March","April","May","June"]
print("Printing the original Set")
print(months)
months.discard("January"):
months.discard("May"):
print("\nPrinting the Modified Set...")
print(months)


