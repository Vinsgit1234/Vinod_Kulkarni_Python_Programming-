list = [0,1,2]
print(tuple(list))
print(tuple('Python'))

list = [0,1,2]
print(tuple(list))
print(tuple('Python'))

list = [0,1,2]
print(tuple(list))
print(tuple('Python'))

list = [0,1,2]
print(tuple(list))
print(tuple('Python'))

list = [0,1,2]
print(tuple(list))
print(tuple('Python'))

list = [0,1,2]
print(tuple(list))
print(tuple('Python'))

