def testyield():
    yield "Computer Science and Engineering"
output = testyield()
for i in output:
    print(i)
    
    
def testyield():
    yield "Computer Science and Engineering"
output = testyield()
for i in output:
    print(i)
    
def testyield():
    yield "Computer Science and Engineering"
output = testyield()
for i in output:
    print(i)
    
def testyield():
    yield "Computer Science and Engineering"
output = testyield()
for i in output:
    print(i)
    
def testyield():
    yield "Computer Science and Engineering"
output = testyield()
for i in output:
    print(i)
    
