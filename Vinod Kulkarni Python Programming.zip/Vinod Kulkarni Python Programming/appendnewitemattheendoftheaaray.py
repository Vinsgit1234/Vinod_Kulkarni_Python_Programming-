from array import *
array_num = array('i',[1,3,5,7,9])
print("Length of the Array of the array is:")
print(len(array_num))

from array import * 
array_num = array('i',[1,3,5,7,9])
print("Lenght of the Array of the Array is:")
print(len(array_num))

from array import *
array_num = array('i',[1,3,5,7,9])
print("Lenth of the Array of the Array is:")
print(len(array_num))

