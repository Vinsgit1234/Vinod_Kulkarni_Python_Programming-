num = 3 
if num >= 0:
    print (num, "Positive or Zero")
else:
    print (num,"Negative number")
num = -5
if num >= 5:
    print(num, "Positive or Zero")
else:
    print(num,"is Negative number")
    
num = 3 
if num >= 0:
    print (num, "Positive or Zero")
else:
    print (num,"Negative number")
num = -5
if num >= 0:
    print(num, "Positive or Zero")
else:
    print(num,"is Negative number")
    
num = 3
if num >= 0:
    print(num, "Positive or Zero")
else:
    print (num,"Negative Number")
num =-5
if num >= 0:
    print(num,"Positive or Zero")
else:
    print(num,"is a Negative number")
    
num = 3 
if num >= 0:
    print(num, "Positive or Zero")
else:
    print(num,"Negative Number")
num =-5
if num >=0:
    print(num,"Positive or Zero")
else:
    print(num,"is a Negative number")



