ice_cream_flavors = ('Choclate','Vanilla','Mint','Strwberry','Choco-chip')
for f in ice_cream_flavors:
    print(f)
    
ice_cream_flavors = ('Choclate','Vanilla','Mint','Strawberry','choco-chip')
for f in ice_cream_flavors:
    print(f)
    
