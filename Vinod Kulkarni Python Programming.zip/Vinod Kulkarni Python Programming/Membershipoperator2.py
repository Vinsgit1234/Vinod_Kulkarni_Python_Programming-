Tuple=(10,26,44)
print(10 in Tuple)
print(50 in Tuple)
print(65 not in Tuple)

Tuple = (10,26,44)
print(10 in Tuple)
print(50 in Tuple)
print(65 not in Tuple)

Tuple = (10,26,44)
print(10 in Tuple)
print(50 in Tuple)
print(65 not in Tuple)


