import math 
def print_till_zero(n):
    if (n==0):
        return
    print(n)
    n = n - 1 
    print_till_zero(n)
print_till_zero(8)

import math 
def print_till_zero(n):
    if (n==0):
        return
    print(n)
    n = n - 1 
    print_till_zero(n)
print_till_zero(8)

import math 
def print_till_zero(n):
    if (n==0):
        return
    print(n) 
    n = n - 1 
    print_till_zero(n)
print_till_zero(8)
    
import math 
def print_till_zero(n):
    if (n==0):
        return
    print(n)
    n = n - 1 
    print_till_zero(n)
print_till_zero(8)

import math 
def print_till_zero(n):
    if (n ==0):
        return 
    print(n)
    n = n - 1 
    print_till_zero(n)
print_till_zero(8)

import math 
def print_till_zero(n):
    if (n==0):
        return 
    print(n)
    n = n - 1
    print_till_zero(n)
print_till_zero(8)

import math 
def print_till_zero(n):
    if (n==0):
        return
    print(n)
    print_till_zero(n)
print_till_zero(8)

import math 
def print_till_zero(n):
    if (n==0):
        return
    print(n)
    print_till_zero(n)
print_till_zero(8)

import math 
def print_till_zero(n):
    if (n==0):
        return
    print(n)
    print_till_zero(n)
print_till_zero(8)

import math 
def print_till_zero(n):
    if(n==0):
        return
    print(n)
    print_till_zero(n)
print_till_zero(8)

import math 
def print_till_zero(n):
    if(n==0):
        return
    print(n)
    print_till_zero(n)
print_till_zero(8)

