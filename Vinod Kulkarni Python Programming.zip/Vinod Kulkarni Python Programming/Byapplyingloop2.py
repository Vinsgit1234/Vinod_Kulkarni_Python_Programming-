List = [0,1,2,3,4,5]
print("Content of list using for loop")
for x in List:
    print(x)
    
List = [0,1,2,3,4,5]
print("Content of list using for loop")
for x in List:
    print(x)
    
List = [0,1,2,3,4,5]
print("Content of List using for loop")
for x in List:
    print(x)
    
List = [0,1,2,3,4,5]
print("Content of list using for loop")
for x in List:
    print(x)
    
List = [0,1,2,3,4,5]
print("Content of list using for loop")
for x in List:
    print(x)
    
