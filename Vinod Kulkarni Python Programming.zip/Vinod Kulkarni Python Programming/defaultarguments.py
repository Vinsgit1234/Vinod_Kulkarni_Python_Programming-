def myFun(x,y=50):
    print("x:",x)
    print("y:",y)
    
    myfun(10)
    
def myFun(x,y=50):
    print("x:",x)
    print("y:",y)
    
    myfun(10)
    
    
    
