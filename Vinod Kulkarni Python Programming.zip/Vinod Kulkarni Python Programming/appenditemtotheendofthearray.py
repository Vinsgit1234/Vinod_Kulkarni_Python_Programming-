from array import *
array_num = array('i',[1,,3,5,7,9])
print("length of the array is:")
print(len(array_num))

print("\n Original array:\n" +str(array_num))
array_num.reverse()
print("Reverse the order of the items:/n")
print(str(array_num))

