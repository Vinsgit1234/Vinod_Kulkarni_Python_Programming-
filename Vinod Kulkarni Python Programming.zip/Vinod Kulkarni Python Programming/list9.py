a[2:2] = [1,2,3]
a += [3.14]
print("Contents of a list after addition = ",a)
a[2:3] = []
del a[0]
print["Contents of a list after deletion = ",a]

a[2:2] = [1,2,3]
a += [3.14]
print("Contents of a list after addition =",a)
a[2:3] = []
del a[0]
print["Contents of a list after deletion =",a]

a[2:2] = [1,2,3]
a += [3.14]
print("Contents of a list after addition =",a)
a[2:3] = []
del a[0]
print["Contents of a list after deletion"]

a[2:2] = [1,2,3]
a += [3.14]
print("Contents of a list after addition=",a)
a[2:3] = []
del a[0]
print["Contents of a list after deletion"]

a[2:2] = [1,2,3]
a += [3.14]
print("Contents of a list after deletion")
a[2:3] = []
del a[0]
print["Contents of a list after deletion"]
