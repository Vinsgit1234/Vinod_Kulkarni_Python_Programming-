Tuple = (5,8,10,20,30,10,40,50)
print("Index of first Occurence of 10=",Tuple.index(10))
print("Index of first Occurance of 10=",Tuple.index(10))

