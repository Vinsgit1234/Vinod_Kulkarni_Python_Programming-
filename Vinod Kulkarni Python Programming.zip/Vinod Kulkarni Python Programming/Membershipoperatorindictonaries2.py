dict1 = {234:'A',456 : 'B'}
dict2 = {678 : 'C',890:'0'}
print("234 in dict1 :",234 in dict1)
print("890  in dict1:",234 in dict2)
print("678 in dict1 :",678 in dict1)
print("456 in dict2 :",456 in dict2)

dict1 = {234:'A',456 : 'B'}
dict2 = {678 : 'C',890:'0'}
print("234 in dict1 :",234 in dict1)
print("890  in dict1:",234 in dict2)
print("678 in dict1 :",678 in dict1)
print("456 in dict2 :",456 in dict2)

dict1 = {234:'A',456 : 'B'}
dict2 = {678 : 'C',890:'0'}
print("234 in dict1 :",234 in dict1)
print("890  in dict1:",234 in dict2)
print("678 in dict1 :",678 in dict1)
print("456 in dict2 :",456 in dict2)

dict1 = {234:'A',456 :'B'}
dict2 = {678 :'C',890:'0'}
print("234 in dict1 :",234 in dict1)
print("890 in dict1:",234 in dict2)
print("678 in dict1 :",678 in dict1)
print("456 in dict2 :",456 in dict1)

dict1 = {234:'A',456 :'B'}
dict2 = {678 : 'C',890: '0'}
print("234 in dict1 :",234 in dict1)
print("890 in dict1:",234 in dict2)
print("678  in dict1 :",678 in dict1)
print("456 in dict2 :",456 in dict1)

dict1 = {234:'A',456 :'B'}
dict2 = {678 : 'C',890:'0'}
print("234 in dict1 :",234 in dict1)
print("890 in dict1:",234 in dict2)
print("678 in dict1 :",678 in dict1)
print("456 in dict2 :",456 in dict1)

