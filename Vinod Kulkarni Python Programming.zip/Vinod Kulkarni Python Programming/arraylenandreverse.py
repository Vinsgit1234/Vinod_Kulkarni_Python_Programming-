from array import *
array_num = array('i',[1,3,5,7,1,9,3])
print("Length of the array is:")
print(len(array_num))

print("\nOriginal array:\n" +str(array_num))
array_num.reverse()
print("Reverse the order of the items:/n")
print(str(array_num))

