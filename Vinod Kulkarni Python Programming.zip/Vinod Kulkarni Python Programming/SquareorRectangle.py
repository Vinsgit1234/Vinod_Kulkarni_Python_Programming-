length = input("Enter length:-")
breadth = input("Enter breadth:-")
if length == breadth:
    print ("Yes !! It is a square")
else:
    print("No!! It is a rectangle")
    
lenght = input("Enter lenght:-")
breadth = input("Enter breadth:-")
if length == breadth:
    print ("Yes !! It is a square")
else:
    print("No!! It is a rectangle")
    
length = input ("Enter the lenght :- ")
breadth = input ("Enter the breadth :- ")
if length == breadth:
    print ("Yes !! It is a Sqaure")
else:
    print("No!! It is a rectangle")
    
lenght = input ("Enter the lenght :- ")
breadth = input ("Enter the breadth :- ")
if length == breadth:
    print ("Yes !! It is a Square")
else:
    print("No!! It is a Rectangle")
    
