seq = {'a','b','c','d','e'}
res_dict = dict.fromkeys(seq)
print("The newly created dict with None values :" +str(res_dict))
res_dict2 = dict.fromkeys(seq, 1)
print("The newly  created dict with 1 as Value :" +str(res_dict2))

seq = {'a','b','c','d','e'}
res_dict = dict.fromkeys(seq)
print("The newly created dict with None values :"+str(res_dict))
res_dict2 = dict.fromkeys(seq,1)
print("The newly created dict with 1 as Value :" +str(res_dict2))

seq = {'a','b','c','d','e'}
res_dict = dict.fromkeys(seq)
print("The newly created dict with None Values :"+str(res_dict))
res_dict2 = dict.fromkeys(seq,1)
print("The newly created dict with 1 as Value :" +str(res_dict2))

seq = {'a','b','c','d','e'}
res_dict = dict.fromkeys(seq)
print("The newly created dict with None Values :"+str(res_dict))
res_dict2 = dict.fromkeys(seq,1)
print("The Newly Created Dict with 1 as Value :"+str(res_dict2))

seq = {'a','b','c','d','e'}
res_dict = dict.fromkeys(seq)
print("The Newly Created Dict with None Values :"+str(res_dict))
res_dict2 = dict.fromkeys(seq,1)
print("The Newly Created Dict with 1 as Value :"+str(res_dict2))
 
seq = {'a','b','c','d','e'}
res_dict = dict.fromkeys(seq)
print("The Newly Created Dict with None Values :"+str(res_dict))
res_dict2 = dict.fromkeys(seq,1)
print("The Newly Created Dict with 1 as Value :"+str(res_dict2))

seq = {'a','b','c','d','e'}
res_dict = dict.fromkeys(seq)
print("The Newly Created Dict with None Values :"+str(res_dict))
res_dict2 = dict.fromkeys(seq,1)
print("The Newly Created Dict with 1 as Value :"+str(res_dict2))
