class even:
    i = 1,10:
    for (i==1,i<=10,i%2=0):
        if (i%2=0):
            print(i)

