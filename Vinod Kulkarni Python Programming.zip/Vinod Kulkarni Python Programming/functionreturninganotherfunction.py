def create_adder(x):
    def adder(y):
        return x + y 
    return adder 
add_15 = create_adder(15)
print("The Result is :", add_15(10))

def create_adder(x):
    def adder(y):
        return x + y 
    return adder 
add_15 = create_adder(15)
print("The Result is :", add_15(10))

def create_adder(x):
    def adder(y):
        return x + y 
    return adder 
add_15 = create_adder(15)
print("The Result is :", add_15(10))

def create_adder(x):
    def adder(y):
        return x + y 
    return adder 
add_15 = create_adder(15)
print("The Result is :", add_15(10))

def create_adder(x):
    def adder(y):
        return x + y
    return adder
add_15 = create_adder(15)
print("The Result is :",add_15(10))



