Days1 = {"Monday","Tuesday","Wednesday","Thursday"}
Days2 = {"Monday","Tuesday"}
Days3 = {"Monday","Tuesday","Friday"}
print("Days1>Days2 === ",Days1>Days2)
print("Days1<Days2 ===",Days1<Days2)
print("Days1 = Days2 === ",Days2 == Days2)
print("Days1 = Days2===",Days2 == Days3)
print("Days := Days2 === ",Days2 != Days3)

Days1 = {"Monday","Tuesday","Wednesday","Thursday"}
Days2 = {"Monday","Tuesday"}
Days3 = {"Monday","Tuesday","Friday"}
print("Days1>Days2 === ",Days1>Days2)
print("Days1<Days2 == ",Days1 <Days2)
print("Days1 = Days2 === ",Days2 == Days3)
print("Days := Days2 === ", Days2 != Days3)

Days1 = {"Monday","Tuesday","Wednesday","Thursday"}
Days2 = {"Monday","Tuesday"}
Days3 = {"Monday","Tuesday","Friday"}
print("Days1>Days2 === ",Days1>Days2)
print("Days1<Days2 === ", Days2 == Days3)
 
Days1 = {"Monday","Tuesday","Wednesday"}
Days2 = {"Monday","Tuesday"}
Days3 = {"Monday","Tuesday","Friday"}
print("Days1>Days2 === ", Days1>Days2)
print("Days1<Days2 === ", Days2 == Days3)

