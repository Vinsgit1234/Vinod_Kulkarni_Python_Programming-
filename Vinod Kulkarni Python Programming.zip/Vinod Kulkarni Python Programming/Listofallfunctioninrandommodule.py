print("grinning face = \U0001f600")
print("grinning squinting face = \U0001F606")
print("rolling on the floor laughing = \U0001F923")
print("CLDR grinning face = \N{grinning face}")
print("CLDR slightly smiling face = "
      "\N{slightly smiling face}")
print("CLDR winking face = |N{winking face}")

print("Grinning face = \U0001f600")
print("Grinning squinting face = \U0001F686")
print("Rolling on the floor laughing = \U0001F923")
print("CLDR grinning face = \N{grinning face}")
print("CLDR slightly smiling face ="
        "\N{slighting smiling face}")
print("CLDR winking face = |N{winking face}")

