import math
print("The Square Root of Number 09 is",math.sqrt(4))

import math 
print("The Square Root of Number 16 is",math.sqrt(16))

import math 
print("The Square Root of Number 25 is ",math.sqrt(25))

import math 
print("The Square Root of Number 36 is ",math.sqrt(36))

import math 
print("The Sqaure Root of Number 49 is",math.sqrt(49))

