for i in range(5):
    print(i)
    
for i in range(10):
    print(i)
    
for i in range (15):
    print(i)
    
for i in range (20):
    print (i)
    
for i in range (25):
    print (i)
    
for i in range (30):
    print (i)
    

