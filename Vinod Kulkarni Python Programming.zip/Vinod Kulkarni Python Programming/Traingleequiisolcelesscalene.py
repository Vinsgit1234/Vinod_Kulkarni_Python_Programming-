s1 = int(input("Enter First side of the traingle:-"))
s2 = int(input("Enter Second Side of the Traingle:-"))
s3 = int(input("Enter the Third Side of the Traingle:-"))
if (s1 == s2 == s3):
    print("The traingle is a Equilateral Traingle")
if (s1 == s2 != s3) or (s1 != s2 == s3) or (s1 != s3 == s2):
    print("The Traingle is a Isolceles Traingle")
if (s2 != s2) or (s2 != s3) or (s3 != s1):
    print ("The Traingle is a Scalene Traingle")
    
    
s1 = int(input("Enter First side of the traingle:-"))
s2 = int(input("Enter Second Side of the Traingle:-"))
s3 = int(input("Enter the Third Side of the Traingle:-"))
if (s1 == s2 == s3):
    print("The traingle is a Equilateral Traingle")
if (s1 == s2 != s3) or (s1 != s2 == s3) or (s1 != s3 == s2):
    print("The Traingle is a Isolceles Traingle")
if (s2 != s2) or (s2 != s3) or (s3 != s1):
    print ("The Traingle is a Scalene Traingle")
    
    
s1 = int(input("Enter First side of the traingle:-"))
s2 = int(input("Enter Second Side of the Traingle:-"))
s3 = int(input("Enter the Third Side of the Traingle:-"))
if (s1 == s2 == s3):
    print("The traingle is a Equilateral Traingle")
if (s1 == s2 != s3) or (s1 != s2 == s3) or (s1 != s3 == s2):
    print("The Traingle is a Isolceles Traingle")
if (s2 != s2) or (s2 != s3) or (s3 != s1):
    print ("The Traingle is a Scalene Traingle")
    
    
    
    





    
    
    
    





    
