x = 0 
y = 20 
0 and 20 

x = 0 
y = 20
0 and 20 

x = 0 
y = 20 
0 and 20 

x = 0 
y = 20 
0 and 20 

x = 20
y = 20 
0 and 20 

x = 20
y = 20 
0 and 20 

x = 0 
y = 20 
0 and 20 

x = 0 
y = 20 
0 and 20 

x = 0 
y = 20 
0 and 20 

x = 0 
y = 20 
0 and 20 

x = 0 
y = 20 
0 and 20 

x = 0 
y = 20 
0 and 20 

x = 0 
y = 20 
0 and 20 

x = 0 
y = 20 
0 and 20 

x = 0 
y = 20 
0 and 20 

x = 0 
y = 20 
0 and 20 

x = 0 
y = 20 
0 and 20 

x = 0 
y = 20 
0 and 20 

x = 0 
y = 20
0 and 20 

