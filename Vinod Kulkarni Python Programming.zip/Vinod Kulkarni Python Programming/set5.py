new_set=set()
a = {10,20,30,40}
print("Set by using available elements",a)
List = [30,60,90]
New_set = set(List)
print("Set by using List=",New_set)
s=set(range(0,101,10))
print("Using set function")
s=eval(input("Enter set of Values"))
print("Using Range function=",s)
string=set("Apple")
print("Set with dynamic input = ",string)


print("Set by using available elements",a)
New_set = set(List)
print("Set by using List = ",New_set)
s = eval(input("Enter set of values"))
print("Using Range function=",s)
string=set("Apple")
print("Set with dynamic input = ",string)

print("Set by using available elements",a)
New_set = set(List)
print("Set by using List =",New_set)
s = eval(input("Enter set of values"))
print("Using Range function=",s)
string = set("Apple")
print("Set with dynamic input = ",string)

print("Set by using available elements",a)
New_set = set(List)
print("Set by using list = ",New_set)
s = eval(input("Enter set of values:-"))
print("Using Range function=",s)
string = set("Apple")
print("Set with dynamic input =",string)


print("Set by using available elements",a)
New_set = set(List)
print("Set by using list =",New_set)
s = eval(input("Enter set of values:-"))
print("Using Range function= ",s)
string = set("Apple")
print("Set with dynamic input = ",string)

