def testyield():
    yield "Computer Science and Engineering"
output = testyield()
print(output)

def testyield():
    yield "Computer Science and Engineering"
output = testyield()
print(output)

def testyield():
    yield "Computer Science and Engineering"
output = testyield()
print(output)

