setn = {5,10,3,15,2,20}
print("Original set elements")
print(setn)
print(type(setn))
print("Maximum value of the said set:")
print(max(setn))
print("Minimum Value of the Said Set:")
print(min(setn))

setn = {5,10,3,15,2,20}
print("Original set elements")
print(setn)
print(type(setn))
print("Maximum value of the said set:")
print(max(setn))
print("Minimum Value of the Said Set:")
print(min(setn))

setn = {5,10,3,15,2,20}
print("Original set elements")
print(setn)
print(type(setn))
print("Maximum value of the said set:")
print(max(setn))
print("Minimum Value of the Said Set:")
print(min(setn))


setn = {5,10,3,15,2,20}
print("Original set elements")
print(setn)
print(type(setn))
print("Maximum value of the said set:")
print(max(setn))
print("Minimum Value of the Said Set:")
print(min(setn))