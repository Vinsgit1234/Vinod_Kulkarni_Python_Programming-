x = 5 
y = 3
z = x + y * 2
print(z)

x = 5 
y = 3
z = x + y * 2
print(z)

x = 5 
y = 3
z = x + y * 2
print(z)

x = 5 
y = 3
z = x + y * 2
print(z)
