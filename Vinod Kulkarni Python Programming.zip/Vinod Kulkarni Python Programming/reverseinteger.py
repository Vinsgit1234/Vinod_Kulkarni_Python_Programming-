num = int(input("Enter the number :-"))
reverse_number =  0
print ("Given Number ", num)
while num > 0:
    reminder = num % 10
    reverse_number = (reverse_number * 10) + reminder
    num = num // 10
print ("Reverse number ", reverse_number)

num = int(input("Enter the number :-"))
reverse_number = 0
print ("Given number", reverse_number)
while num > 0 :
    reminder = num % 10
    reverse_number = (reverse_number * 10) + reminder
    num = num // 10
print ("Reverse number ", reverse_number)

num = int(input("Enter the number :-"))
reverse_number = 0
print ("Given number", reverse_number)
while num > 0 :
    reminder = num % 10
    reverse_number = (reverse_number * 10) + reminder
    num = num // 10
print ("Reverse number ", reverse_number)

num = int (input("Enter the number :- "))
reverse_number = 0
print ("Given number", reverse_number)
while num > 0 :
    reminder = num % 10
    reverse_number = (reverse_number * 10) + reminder
    num = num // 10
print("Reverse number", reverse_number)

num = int (input ("Enter the number :- "))
reverse_number = 0
print ("Given number" , reverse_number)
while num > 0 :
    reminder = num % 10
    reverse_number = (reverse_number * 10) + reminder
    num = num // 10
print("Reverse number", reverse_number)

num = int(input("Enter the number :- "))
reverse_number = 0
print("Given number", reverse_number)
while num > 0:
    reminder = num % 10
    reverse_number = (reverse_number * 10) + reminder
print("Reverse number", reverse_number)

