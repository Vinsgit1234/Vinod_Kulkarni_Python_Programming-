UPDATE table_name
SET col_1 = value_1, column_2 = value_2
WHERE condition;