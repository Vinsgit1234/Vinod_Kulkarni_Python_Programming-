def add(a, b):
    return a + b
# initializing numbers
a = 10
b = 5
# calling function
res = add(a,b)
print(res)

def add(a,b):
    return a + b
a = 10 
b = 5 
res = add(a,b)
print(res)

def add(a,b):
    return a + b 
a = 10 
b = 5 
res = add(a,b)
print(res)

def add(a,b):
    return a + b
a = 10 
b = 5 
res = add(a,b)
print(res)

def add(a,b):
    return a + b 
a = 10 
b = 5 
res = add(a,b)
print(res)

