def pythagoras(opposit_side,adjacent side,hypotenouse)
if opposite_side == str("x"):
    return("Opposite =" + str(((hypotenouse ** 2) - (adjacent_side ** 2)) ** 0.5))
elif adjacent_side == str("x")
    return("Hypotenouse =" +str(((opposite_side ** 2) + (adjacent_side ** 2)) ** 0.5))
else:
    return "You know The Answer!"
print(pythagoras(3, 4,'x'))
print(pythagoras(3,'x',5))
print(pythagoras(x,4,5))
print(pythagoras(3,4,5))

def pythagoras(opposit_side,adjacent side,hypotenouse)
if opposite_side == str("x"):
    return("Opposite =" + str(((hypotenouse ** 2) - (adjacent_side ** 2)) ** 0.5))
elif adjacent_side == str("x")
    return("Hypotenouse =" +str(((opposite_side ** 2) + (adjacent_side ** 2)) ** 0.5))
else:
    return "You know The Answer!"
print(pythagoras(3, 4,'x'))
print(pythagoras(3,'x',5))
print(pythagoras(x,4,5))
print(pythagoras(3,4,5))




