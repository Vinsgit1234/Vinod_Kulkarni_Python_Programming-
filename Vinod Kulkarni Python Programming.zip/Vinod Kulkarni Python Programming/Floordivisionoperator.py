a = 10
b = 2
print ('a/b = ', a/b)
print ('a// b = ', a // b)
print ('10/2 = ', 10 / 2)
print ('10 // 2 = ', 10 // 2)

a = 10 
b = 2 
print ('a/b = ', a/b)
print ('a//b = ', a // b)
print ('10/2 = ', 10/ 2)
print ('10 // 2 = ', 10 // 2)

a = 10 
b = 2 
print ('a/b =', a/b)
print ('a // b ', a//b )
print ('10/2 = ', 10/2)
print ('10//2 = ', 10 // 2)

a = 10
b = 2 
print ('a/b =', a/b)
print ('a//b =', a//b)
print ('10 / 2 = ', 10 /2)
print ('10 // 2 = ', 10 // 2)

a = 10 
b = 2
print ('a/b = ', a / b)
print ('a // b =', a//b )
print ('10 /2 = ', 10 /2)
print ('10 // 2 = ',10 // 2)

a = 10 
b = 2 
print ('a/b = ', a /b)
print ('a // b = ', a //b )
print ('10 /2 = ', 10 /2 )
print ('10 // 2 = ', 10 //2)

a = 10 
b = 2
print ('a / b = ', a /b)
print ('a // b = ', a // b)
print ('10 /2 = ', 10/2)
print ('10 // 2 = ', 10//2)

a = 10 
b = 2
print ('a / b = ', a / b )
print ('a // b = ', a //b)
print ('10 /2 = ', 10/2)
print ('10 //2  = ', 10/2)

a = 10 
b = 2 
print ('a / b = ', a / b)
print ('a //b = ', a // b)
print ('10 /2 = ', 10 /2)
print ('10//2  = ', 10/2)

a = 10 
b = 2
print ('a / b = ', a / b)
print ('a // b = ',a // b)
print ('10/2   =  ', 10 /2)
print ('10 //2 = ', 10 /2)

 