import array 
arr = array.array('i',[1,2,3,1,2,5])
print("The Length of the array =", len(arr))

import array 
arr = array.array('i',[1,2,3,1,2,5])
print("The Length of the array =", len(arr))

import array 
arr = array.array('i',[1,2,3,1,2,5])
print("The Length of the array =",len(arr))

import array 
arr = array.array('i',[1,2,3,1,2,5])
print("The Lenght of the Array =",len(arr))

