try:
    print("try")
    print(10/2)
except:
    print("Except")
else:
    print("Else")
finally:
    print("Finally")

    