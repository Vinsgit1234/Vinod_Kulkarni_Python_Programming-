a = 1+2j
print("Value of a :" , a)
print ("Real part :" , (a.real))
print("Imaginary part :", (a.imag))
a = 10 + 20j
print ("Value of a :" , a)
a = 10.5 + 20j
print ("Value of a :",a)
a = 0b1111 + 20j
print ("Value of a :", a)


a = 1+2j
print ("Value of a" , a)
print ("Real part" , (a.real))
print("Imaginary part:", (a.imag))
a = 10 + 20j
print("Value of a : " , a)
a = 10.5 + 20j
print ("Value of a : ", a)
a = 0b1111 + 20j
print("Value of a:", a)



       