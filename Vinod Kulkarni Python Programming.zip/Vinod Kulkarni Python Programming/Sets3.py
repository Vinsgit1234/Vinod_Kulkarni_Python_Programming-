Months = set(["January","Febraury","March","April","May","June"])
print("Printing the original set...")
print(Months)
print("Removing items through discard")

Months = set["January","Febraury","March","April","May","June"]
print("Printing the original set...")
print(Months)
print("Removing items through discard")

Months = set["January","Febraury","March","April","May","June"]
print("Printing the original set...")
print(Months)
print("Removing items through discard() methiod")
Months.discard("Feb")
print("printing the modified set...")
Months.remove("Jan")
print("\nRemoving items through remove() methiod..")
Months.remove("Jan")
print("\n Printing the modified set")
print(Months)


