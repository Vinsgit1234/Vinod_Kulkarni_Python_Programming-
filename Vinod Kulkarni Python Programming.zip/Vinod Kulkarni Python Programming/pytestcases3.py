x = 5 
y = "python"
print(type(x))
print(type(y))

