from array import * 
array_num = array('i', [1,3,5,3,7,1,9,3])
print("Original array :\n" +str(array_num))
print("Remove the first occurance of the 3/n from t")
array_num.remove(3)
print("New Array:\n" +str(array_num))
      
from array import * 
array_num = array('i', [1,3,5,3,7,1,9,3])
print("Original array :\n" +str(array_num))
print("Remove the first occurance of the 3/n from t")
array_num.remove(3)
print("New Array:\n" +str(array_num))

from array import * 
array_num = array('i', [1,3,5,3,7,1,9,3])
print("Original array :\n" +str(array_num))
print("Remove the first occurance of the 3/n from t")
array_num.remove(3)
print("New Array:\n" +str(array_num))


      