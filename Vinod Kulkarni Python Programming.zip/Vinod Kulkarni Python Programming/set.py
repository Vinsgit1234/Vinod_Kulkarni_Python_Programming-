set1 = { 1, 2 , 3, "JavaTPoint", 20.5, 14}
print("Immutable elements ",type(set1))
set2 ={1,2,3,["Javatpoint",4]}
print("Mutable elements",type(set2))


set1 = {1, 2, 3, "JavaTpoint",20.5,14}
print("Immutable elements ",type(set1))
set2 = {1,2,3,["JavaTpoint",4]}
print("Mutable elements ", type(set2))


set1 = {1,2,3, "JavaTpoint",20.5,14}
print("Immutable elements",type(set1))
set2 = {1,2,3,["JavaTpoint",4]}
print("Mutable elements ",type(set2))






