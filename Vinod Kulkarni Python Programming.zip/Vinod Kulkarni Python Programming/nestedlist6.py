x = ['a',['bb', ['ccc','ddd'],'ee','ff'],'g',['hh','ii'],'j']
print("Nested List Demo",x)
print("x[1] =",x[1])
print("x[1][1] =", x[1][1])
print("x[1][1][0] =", x[1][1][0])

