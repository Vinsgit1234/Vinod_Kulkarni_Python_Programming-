Tuple = (10,20,30,"Banana")
print("Element at 0th Place=",tuple[0])
print("Element at -1 place = ",tuple[-1])
print("Element from 1st to 4th Place= ", Tuple[1:4])

Tuple = (10,20,30,"Banana")
print("Element at 0th Place =",tuple[0])
print("Element at -1 place ",tuple[-1])
print("Elements from 1st to 4th place=",Tuple[1:4])

