SELECT * FROM table_name
ORDER BY col_1;

