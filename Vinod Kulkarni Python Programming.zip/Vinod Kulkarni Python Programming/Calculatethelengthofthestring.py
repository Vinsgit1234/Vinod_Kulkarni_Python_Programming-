def string_lenght(str1):
    count = 0
    for char in str1:
        count += 1
    return count 
print("Length of a string=",
      string_length('Python Programming'))

def string_length(str1):
    count = 0
    for char in str1:
        count += 1
        return count 
print("Length of a String =",
      string_length('Python Programming'))
