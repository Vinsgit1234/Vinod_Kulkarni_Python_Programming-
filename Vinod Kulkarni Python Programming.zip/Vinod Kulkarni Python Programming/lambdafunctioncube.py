def cube(y):
    return y*y*y 
lambda_cube = lambda y: y*y*y 
print("Using def Function",cube(5))
print("Using Lambda Function",lambda_cube(5))

def cube(y):
    return y*y*y
lambda_cube = lambda y: y*y*y
print("Using def Function",cube(5))
print("Using Lambda Function",lambda_cube(5))

def cube(y):
    return y*y*y
lambda_cube = lambda y: y*y*y
print("Using def Function",cube(5))
print("Using Lambda Function",lambda_cube(5))

def cube(y):
    return y*y*y
lambda_cube = lambda y: y*y*y
print("Using def Function",cube(5))
print("Using Lambda Function",lambda_cube(5))

def cube(y):
    return y*y*y
lambda _cube = labmda y: y*y*y 
print("Using def Function",cube(5))
print("Using Lambda Function",lambda_cube(5))

