a = [1,2,3] * 2
print(a)

a = [1,2,3] * 2
print(a)

