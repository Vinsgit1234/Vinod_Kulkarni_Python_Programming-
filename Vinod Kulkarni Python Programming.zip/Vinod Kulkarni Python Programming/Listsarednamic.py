a = ['apple','banana','grapes','Orange','guava']
a [2:2] = [1,2,3]
a += [3.14]
print("Contents of a list after Addition")
a[2:3]= []
del a[0]
print("Content of the list after deletion",a)

a = ['apple','banana','grapes','Orange','guava']
a [2:2] = [1,2,3]
a += [3.14]
print("Contents of a list after addition")
a[2:3] = []
del a[0]
print("Content of the list after deletion",a)

a = ['apple','banana','grapes','Orange','guava']
a[2:2] = [1,2,3]
a += [3.14]
print("Contents of a list after addition",a)
a[2:3] = []
del a[0]
print("Content of the list after deletion=",a)

a = ['apple','banana','grapes','Orange','guava']
a[2:2] = [1,2,3]
a += [3.14]
print("Content of a list after addition",a)
a[2:3] = []
del a[0]
print("Content of the list after deletion=",a)

a = ['apple','banana','grapes','Orange','guava']
a[2:2] = [1,2,3]
a += [3.14]
print("Content of a list after addition",a)
a[2:3] = []
del a[0]
print("Content of the List After Deletion=",a)
