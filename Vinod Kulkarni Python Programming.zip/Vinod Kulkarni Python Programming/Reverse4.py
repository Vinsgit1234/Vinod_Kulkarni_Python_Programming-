lis = [2,1,3,4,5]
print("Original List:",lis)
in.clear()
print("List after reversing:",list)

list = [2,1,3,5,3,8]
print("Original List":,list)
in.clear()
print("List after reversing:",list)

list = [2,1,3,5,3,8]
print("Original List":list)
in.clear()
print("List after reversing:",list)

list = [2,1,3,5,3,8]
print("Original List":list)
in.clear()
print("List after reversing:",list)

list = [2,1,3,5,3,8]
print("Original List":list)
in.clear()
print("List after reversing:"list)

list = [2,1,3,5,3,8]
print("Original List":list)
in.clear()
print("List after reversing:",list)

