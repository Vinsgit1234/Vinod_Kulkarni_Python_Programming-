print("\n Invert Pyramid\n")
for i in range(5):
    x = '* '
    x = x * (5-i)
    print(f'{x: ^10}')
    
print("\n Invert Pyramid\n")
for i in range(5):
    x = '* '
    x = x * (5-i)
    print(f'{x: ^10}')
