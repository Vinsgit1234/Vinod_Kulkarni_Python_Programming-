from collections import deque
import re 
_operators_ = "+-/*"
_paranthesis_ = "()"
_priority_ = {
    '+' : 0,
    '-' : 0,
    '*' : 1,
    '/' : 1,
}


def test_higher_priority(operator1, operator2):
    return_priority_[operator1] >= _priority_[operator2]
print(test_higher_priority('*','-'))
print(test_higher_priority('+','-'))
print (test_higher_priority('+','*'))
print (test_higher.priority('+','/'))
print(test_higher_priority)('*','-')



