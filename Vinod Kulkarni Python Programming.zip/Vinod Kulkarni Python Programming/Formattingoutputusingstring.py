str = "I Love coding"
print ("Centre aligned string with filchr:")
print (str.center(40, '#'))
print ("The left aligned string is:")
print (str.ljust(40,'-'))
print ("The right aligned string is :")
print (str.rjust(40,'-'))

str = "I Love Coding"
print ("Centre aligned string with filchr:")
print (str.center(40, '#'))
print ("The left aligned string is :")
print (str.ljust(40,'-'))
print ("The right aligned string is :")
print (str.rjust(40,'-'))


