 var_a = input("Enter a value")
 print("var_a: ", var_a)
 print(type(var_a))
 
 var_a = input("Enter a Value")
 print("var_a: ", var_a)
 print(type(var_a))
 
 var_a = input("Enter a Value")
 print("var_a: ", var_a)
 print(type(var_a))
 
 var_a = input("Enter a Value")
 print("var_a:", var_a)
 print(type(var_a))
 
 var_a = input("Enter a Value")
 print("var_a", var_a)
 print(type(var_a))
  
var_a = input("Enter a Value")
print("var_a",var_a)
print(type(var_a))

var_a = input("Enter a Value")
print("var_a",var_a)
print(type(var_a))

var_a = input("Enter a Value")
print("var_a",var_a)
print(type(var_a))

var_a = input("Enter a Value")
print("var_a",var_a) 
print(type(var_a))

var_a = input("Enter a Value")
print("var_a",var_a)
print(type(var_a))

var_a = input("Enter a Value") 
print("var_a",var_a)
print(type(var_a))    
    
var_a = input("Enter a Value")
print("var_a",var_a)
print(type(var_a))

var_a = input("Enter a Value")
print("var_a",var_a)
print(type(var_a))

var_a = input("Enter a Value")
print("var_a",var_a)
print(type(var_a))

var_a = input("Enter a Value")
print("var_a",var_a)
print(type(var_a))

var_a = input("Enter a Value")
print("var_a",var_a)
print(type(var_a))

var_a = input("Enter a Value")
print("var_a",var_a)
print(type(var_a))

