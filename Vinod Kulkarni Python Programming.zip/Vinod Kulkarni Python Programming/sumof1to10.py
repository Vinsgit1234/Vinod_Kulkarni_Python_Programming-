sum = 0
for i in range(0,11,1):
    sum += i
    print(f"The sum of 1 to 10 is {sum}")
