a = 9 
b = 4 
add = a + b
sub = a - b 
mul = a * b 
div1 = a / b
div2 = a // b
mod = a % b
p = a ** b
print ("addition result :", add)
print ("subtraction result" ,sub)
print ("division float res" , mul )
print ("division floor res :",div2)
print ("Modulo res : ", mod)
print ("Modulo res: ", mod)
print ("Power result :",p)

a = 9
b = 4
add = a + b
sub = a - b 
mul = a * b 
div1 = a / b 
div2 = a % b
mod = a % b
p = a ** b
print ("addition result:", add)
print ("subtraction result",sub)
print ("multipication result", mul)
print ("Division float res:", div1)
print ("Division Floor res :", div2)
print ("Modulo res :", mod)
print ("Power result :", p)

