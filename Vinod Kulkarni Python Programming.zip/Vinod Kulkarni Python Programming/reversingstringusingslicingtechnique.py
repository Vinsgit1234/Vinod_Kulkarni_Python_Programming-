string = "Python Programming"
print(string[::-1])

string = "Python Programming"
print(string[::-1])

string = "Python Programming"
print(string[::-1])

