x = 888 
y = 999 
def add(a,b):
    print("The Sum:",(a+b))
def product(a,b):
    print("The product is :",(a+b))
class A:
    pass 

