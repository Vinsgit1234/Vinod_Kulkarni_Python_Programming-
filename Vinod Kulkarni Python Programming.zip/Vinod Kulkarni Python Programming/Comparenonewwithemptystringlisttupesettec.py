string_1 = " "
print("String_1 =None:", string_1 == None)
list_1 = []
print("list_1 == None: ", list_1 == None)
tuple_1 = tuple()
print("tuple_1 = None:", tuple_1 == None)
set_1 = {}
print("tuple_1 == None:", set_1 == None)
dict_1 = dict()
print("dict_1 == None:",dict_1 == None)

string_1 = " "
print("String_1 = None", string_1 == None)
list_1 = []
print("list_1 == None :", list_1 == None)
tuple_1 = tuple()
print("tuple_1 = None:", tuple_1 == None)
set_1 = {}
print("dict_1 == None:",dict_1 == None)

string_1 = " "
print("String_1 = None", string_1 == None)
list_1 = []
print("list_1 == None :", list_1 == None)
tuple_1 = tuple()
print("tuple_1 = None:", tuple_1 == None)
set_1 = {}
print("dict_1 == None:",dict_1 == None)

