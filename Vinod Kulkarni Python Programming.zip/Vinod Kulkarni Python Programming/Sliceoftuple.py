tuplex = (2,4,3,5,4,6,7,8,6)
print("Original Tuple",tuplex)
_slice = tuplex[3:5]
print("tuple[3:5]",_slice)
_slice = tuplex[:6]
print("tuplex[:6]",_slice)
_slice = tuplex[5:]
print("tuplex[5:]",_slice)
_slice = tuplex[:]
print("tuplex[:]",_slice)
_slice = tuplex[-8:-4]
print("tuplex[-8:-4]",_slice)

tuplex = (2,4,3,5,4,6,7,8,6)
print("Original Tuple",tuplex)
_slice = tuplex[3:5]
print("tuple[3:5]",_slice)
_slice = tuplex[:6]
print("tuplex[:6]",_slice)
_slice = tuplex[5:]
print("tuplex[5:]",_slice)
_slice = tuplex[:]
print("tuplex[:]",_slice)
_slice = tuplex[-8:-4]
print("tuplex[-8:-4]",_slice)

tuplex = (2,4,3,5,4,6,7,8,6)
print("Original Tuple",tuplex)
_slice = tuplex[3:5]
print("tuple[3:5]",_slice)
_slice = tuplex[:6]
print("tuplex[:6]",_slice)
_slice = tuplex[5:]
print("tuplex[5:]",_slice)
_slice = tuplex[:]
print("tuplex[:]",_slice)
_slice = tuplex[-8:-4]
print("tuplex[-8:-4]",_slice)

