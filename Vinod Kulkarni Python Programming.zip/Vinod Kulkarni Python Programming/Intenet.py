i = 25 
j = 5 
print(i // j)

i = 25 
j = 5 
print(i // j)

i = 25 
j = 5 
print(i // j)

i = 25
j = 5 
print(i // j)

i = 25 
j = 5
print(i // j)

i = 25  