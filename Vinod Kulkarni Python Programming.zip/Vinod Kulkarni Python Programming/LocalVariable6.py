c = 25 
def fun():
    c = 34 
    print("The Value of c inside fun =" ,c)
def fun1():
    print("The value of c inside fun1 =",c)
fun()
fun1()

c = 25 
def fun():
    c = 34
    print("The value of c inside fun =" ,c) 
def fun1():
    print("The value of c inside fun1 =",c)
fun()
fun1() 

c = 25 
def fun():
    c = 34
    print("The value of c inside fun =" ,c) 
def fun1():
    print("The valye of c inside fun1 =",c)
fun() 
fun1()

