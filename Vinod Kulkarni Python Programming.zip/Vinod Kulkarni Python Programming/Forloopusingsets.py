List = [0,1,2,3,4,5]
i = 0
while i <len(List):
    print(List[i])
    i = i + 1 
    
List = [0,1,2,3,4,5]
i = 0
while i <len(List):
    print(List[i])
    i = i + 1 
    
List = [0,1,2,3,4,5]
i = 0
while i <len(List):
    print(List[i])
    i = i + 1 
    
List = [0,1,2,3,4,5]
i = 0
while i <len(List):
    print(List[i])
    i = i + 1
    
list = [0,1,2,3,4,5]
i = 0 
while i <len(List):
    print(List[i])
    i = i + 1
    
list = [0,1,2,3,4,5]
i = 0
while i <len(List):
    print(List[i])
    i = i + 1
    
list = [0,1,2,3,4,5]
i = 0 
while i <len(List):
    print(List[i])
    i = i + 1
    
    