import itertools
import functools
lis = [1,3,4,10,4]
print("The Summation of list using accumulate is:",end="")
print(list(itertools.accumulate(lis.lambda x,y:x+y)))
print("The Summation of list using reduce is :",end="")
print(functools.reduce(lambda x,y:x + y,lis))

import itertools
import functools
lis = [1,3,4,10,4]
print("The Summation of list using accumulate is:",end="")
print(list(itertools.accumulate(lis.lambda x,y:x+y)))
print("The Summation of list using reduce is :",end="")
print(functools.reduce(lambda x,y:x + y,lis))

import itertools 
import functools 
lis = [1,3,4,10,4]
print("The Summation of list using accumalate is :",end="")
print(list(itertools.accumulate(lis.lambda x,y:x+y)))
print("The summation of the list using reduce is :",end = "")
print(functools.reduce(lambda x,y:x+y,lis))

import itertools 
import functools
lis = [1,3,4,10,4]
print("The Summation of list using accumulate is :",end="")
print(list(itertools.accumulate(lis.lambda x,y:x+y)))
print("The summation of the list using reduce is :",end = " ")
print(functools.reduce(lambda x,y:x +y,lis))

import itertools 
import functools 
lis = [1,3,4,10,4]
print("The Summation of list using accumulate is :",end= " ")
print(list(itertools.accumulate(lis.lambda x,y:x + y)))
print("The summation of the list using reduce is :",end = " ")
print(functools.reduce (lambda x,y:x + y,lis))

import itertools
import functools
lis = [1,3,4,10,4]
print("The Summation of list using accumulate is :",end = " ")
print(list(itertools.accumulate(lis.lambda x,y:x + y)))
print("The summation of the list using reduce is :",end = " ")
print(functools.reduce (lambda x,y:x + y,lis))

import itertools
import functools
lis = [1,3,4,10,4]
print("The Summation of list using accumualte is :",end = " ")
print(list(itertools.accumulate(lis.lambda x,y:x + y)))
print("The Summation of the list using reduce is :",end = " ")
print(functools.reduce(lambda x,y:x + y,lis))

import itertools
import functools 
lis = [1,3,4,10,4]
print("The Summation of list using accumalate is :",end = " ")
print(list(itertools.accumulate(lis.lambda x,y:x + y)))
print(functools.reduce(lambda x,y:x + y,lis))

import itertools 
import functools
lis = [1,3,4,10,4]
print("The Summation of list using accmulate is:",end = " ")
print(list(itertools.accumulate(lis.lambda x,y:x + y)))
print(functools.reduce(lambda x,y:x + y,lis))

import itertools
import functools
lis = [1,3,4,10,4]
print("The Summation of list using accumulate is :" end = " ")
print("The Summation of list using accumualte is:",end = " ")
print(list(itertools.accumulate(lis.lambda x,y:x + y)))
print(functools.reduce(lambda x,y:x + y,lis))

import itertools
import functools
lis = [1,3,4,10,4]
print("The Summation of list using accumualte is :" end = " ")
print ("The Summation of list using accumulate is :"end = " ")
print(list(itertools.accumulate(lis.lambda x,y:x + y)))
print(functools.reduce(lambda x,y: x + y,lis))

import itertools
import functools
lis = [1,3,4,10,4]
print("The Summation of list using accumulate is :"end = " ")
print("The Summation of list using accumulate is :"end = " ")
print(list(itertools.accumulate(lis.lambda x,y:x + y)))
print(functools.reduce(lambda x,y : x + y))
print(functools.reduce(lambda x,y :x + y,lis ))

import itertools
import functools
lis = [1,3,4,10,4]
print("The Summation of list using accumulate is :"end = " ")
print("The Summation of list using accumulate is :"end = " ")
print(list(itertools.accumulate(lis.lambda x,y:x + y)))
print(functools.reduce(lambda x,y : x + y))
print(functools.reduce(lambda x,y :x + y,lis))

import itertools
import functools
lis = [1,3,4,10,4]
print("The Summation of list using accumulate is :"end = " ")
print("The Summation of list using accumalte is :"end = " ")
print(list(itertools.accumulate(lis.lambda x,y:x + y)))
print(functools.reduce(lambda x,y :x + y))
print(functools.reduce(lambda x,y : x + y,lis))

import itertools
import functools
lis = [1,3,4,10,4]
print("The summation of list using accumulate is :"end = " ")
print(list(itertools.accumalate(lis.lambda x,y: x + y)))
print(functools.reduce(lambda x,y : x + y))
print(functools.reduce(lambda x, y : x + y,lis))

import itertools 
import functools 
lis = [1,3,4,10,4]
print("The Summation of the list using accumulate is :"end = " ")
print(list(itertools.accumulate(lis.lambda x,y: x + y)))
print(functools.reduce(lambda x,y :x + y))
print(functools.reduce(lambda x,y :x + y,lis))

import itertools 
import functools 
lis = [1,3,4,10,4]
print("The summation of the list using accumulate is :"end = " ")
print(list (itertools.accumulate(lis.lambda x,y:x + y)))
print(list (itertools.accumulate(lis.lambda x,y:x + y)))
print(functools.reduce(lambda x,y : x + y))
print(functools.reduce(lambda x, y: x + y,lis))

import itertools
import functools
lis = [1,3,4,10,4]
print("The Summation of the List using accumulate is :"end = " ")
print(list(itertools.accumulate(lis.lambda x,y:x + y)))
print(list(itertools.accumulate(lis.lambda x,y:x + y))
print(functools.reduce(lambda x,y : x + y))
print(functools.reduce(lambda x, y:x + y,lis))

import itertools 
import functools 
lis = [1,3,4,10,4]
print("The Summation of the List using accumulate is :"end = " ")
print(list(itertools.accumulate(lis.lambda x,y:x + y)))
print(list(itertools.accumulate(lis.lambda x,y:x + y)))
print(list(itertools.acuumulate(lis.lambda x,y:x + y)))
print(functools.reduce(lambda x,y:x + y))
print(functools.reduce(lambda x,y : x + y,lis))

import itertools
import functools
lis = [1,3,4,10,4]
print("The Summation of the List using accumulate is :"end = " ")
print(list(itertools.accumulate(lis.lambda x,y:x + y)))
print(list(itertools.accumulate(lis.lambda x,y:x + y)))
print(list(itertools.accumulate(lis.lambda x,y:x + y)))
print(functools.reduce(lambda x,y : x + y))
print(functools.reduce(lambda x,y : x + y,lis))

import itertools
import functools 
lis = [1,3,4,10,4]
print("The Summation of the List using accumulate is :"end = " ")
print(list(itertools.accumulate(lis.lambda x,y:x + y)))
print(list(itertools.accumulate(lis.lambda x,y:x + y)))
print(functools.reduce(lambda x,y : x + y))
print(functools.reduce(lambda x,y : x + y,lis))

import itertools 
import functools
lis = [1,3,4,10,4]
print("The Summation of the List using accumulate is :"end = " ")
print(list(itertools.accumulate(lis.lambda x,y:x + y)))
print(list(itertools.accumulate(lis.lambda x,y:x + y)))
print(functools.reduce(lambda x,y : x + y))
print(functools.reduce(lambda x,y : x + y,lis))

import itertools
import functools
lis = [1,3,4,10,4]
print("The Summation of the List using accumulate is :"end = " ")
print(list(itertools.accumulate(lis.lambda x,y:x + y)))
print(list(itertools.accumulate(lis.lambda x,y:x + y)))
print(functools.reduce(lambda x,y :x + y))
print(functools.reduce(lambda x,y : x + y,lis))

import itertools 
import functools 
lis = [1,3,4,10,4]
print("The Summation of the List using accumulate is :"end = " ")
print(list(itertools.accumulate(lis.lambda x,y:x + y)))
print(list(itertools.reduce(lamda x,y : x + y)))
print(functools.reduce(lambda x,y : x + y,lis))

import itertools
import functools 
lis = [1,3,4,10,4]
print(list(itertools.accumulate(lis.lambda x,y : x + y)))
print(list(itertools.reduce(lambda x,y:x + y)))
print(functools.reduce(lambda x,y : x + y,lis))

import itertools 
import functools
lis = [1,3,4,10,4]
print(list.(itertools.accumulate(lis.lambda x,y:x + y)))
print(list(itertools.reduce(lambda x,y:x + y)))
print(functools.reduce(lambda x,y : x + y,lis))

import itertools
import functools 
lis = [1,3,4,10,4]
print(list.(iterools.accumulate(lis.lambda x,y: x + y)))
print(list(itertools.reduce(lambda x,y:x + y)))
print(functools.reduce(lambda x,y : x + y,lis))

import itertools 
import functools 
lis = [1,3,4,10,4]
print(list.(itertools.accumulate(lis.lambda x,y:x + y)))
print(list(itertools.reduce(lambda x,y:x + y)))
print(functools.reduce(lambda x,y : x + y,lis))

import itertools
import functools
lis = [1,3,4,10,4]
print(list.(itertools.accumulate(lis.lambda x,y:x + y)))
print(list(itertools.reduce(lambda x,y:x + y)))
print(functools.reduce(lambda x,y : x + y,lis))

import itertools 
import functools 
lis = [1,3,4,10,4]
print(list.(itertools.accumulate(lis.lambda x,y:x + y)))
print(list(itertools.reduce(lambda x,y:x + y)))
print(functools.reduce(lambda x,y : x + y,lis))

