dict1 = {10, 'a', 20:[1,2,3],30: 'c'}
print("Given Dictionary:",dict1)
dict2 = dict1.copy()
print("New Copy:",dict2)
dict2[10]= 10 
dict2[20][10]= '45' 
print("Updated Copy :",dict2)

dict1 = {10, 'a', 20:[1,2,3],30: 'c'}
print("Given Dictionary :",dict1)
dict2 = dict1.copy()
print("New Copy:",dict2)
dict2[10] = 10
dict2 [20][10] = '45'
print("Updated Copy :",dict2)

dict1 = {10, 'a', 20: [1,2,3],30: 'c'}
print("Given Dictionary :",dict1)
dict2 = dict1.copy()
print("New Copy:",dict2)
dict2[10] = 10
dict2 [20][10] = '45'
print("Updated Copy :",dict2)

dict1 = {10, 'a', 20: [1,2,3],30:'c'}
print("Given Dictionary :",dict1)
dict2 = dict1.copy()
print("New Copy:",dict2)
dict2[10] = 10 
dict2 [20][10] = '45'
print("Updated Copy :",dict2)

dict1 = {10,'a',20 : [1,2,3],30:'c'}
print("Given Dictionary :",dict1)
dict2 = dict1.copy()
print("New Copy:",dict2)
dict2[10] = [10]
dict2[20][10] = '45'
print("Updated Copy :",dict2)

