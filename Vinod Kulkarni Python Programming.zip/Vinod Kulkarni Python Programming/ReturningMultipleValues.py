class Test:
    def _init_(self):
        self.str = "Computer Science"
        self.x = 20 
        
def fun():
    return Test()
t = fun()
print("String data :",t.str)
print("Integer Data :",t.x)

def fun():
    return Test()
t = fun()
print("String data :",t.str)
print("Integer Data :",t.x)

def fun():
    return Test()
t = fun()
print("String data :",t.str)
print("Integer Data :",t.x)

