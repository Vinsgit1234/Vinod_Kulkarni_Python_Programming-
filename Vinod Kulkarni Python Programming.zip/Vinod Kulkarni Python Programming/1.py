import numpy as np
data = {
    'A': [1, 2, np.nan, 4],
    'B': [np.nan, 2, 3, 4],
    'C': [1, np.nan, np.nan, 4],
     eval (A):
     eval (B):
     eval (C):
     
     print(A)
     print(B)
     print(C)
}
