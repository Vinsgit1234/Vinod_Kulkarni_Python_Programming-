x = lambda a:a+10
print(x)
print("sum=",x(20))

x = lambda a:a+10
print(x)
print("sum=",x(20))

x = lambda a:a+10
print(x)
print("Sum=",x(20))

x = lambda a:a+10
print(x)
print("Sum=",x(20))

x = lambda a:a+10
print(x)
print("Sum=",x(20))

