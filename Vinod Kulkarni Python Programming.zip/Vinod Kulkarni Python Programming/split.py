string = "Computer Science and Engineering Departments"
List = string.split()
print(List)

string = "Computer Science and Engineering Departments"
List = string.split()
print(List)

string = "Computer Science and Engineering Departments"
List = string.split()
print(List)

string = "Computer Science and Engineering Departments"
List = string.split()
print(List)

