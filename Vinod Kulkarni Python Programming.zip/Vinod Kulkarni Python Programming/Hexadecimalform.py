a = 0 * 123 
print ("Value of a : " , a)
a = 0 * 1556 
print ("Value of a : '", a)
a = 0 * face 
print ("value of a " , a)
a = 0 * beef
print("Value of a : " , a)


a = 0 * 123 
print ("Class type of a : ", type(a))
a = 0 * 156 
print ("Value of a : ", a)
a = 0 * face 
print ("Value of a " , a)
a = 0 * beef 
print("Value of a : ",a )


