rows = 6 
for i in range(rows):
    for j in range(i):
        print (i, end = '')
    print('')
    
rows = 6
for i in range(rows):
    for j in range(i):
        print(i, end = '')
    print('')
    
rows = 6
for i in range(rows):
    for j in range(i):
        print(i, end = '')
    print('')

row = 6 
for i in range(rows):
    for j in range(i):
        print(i, end = '')
    print('')
    
row = 6
for i in range(row):
    for j in range(i):
        print(i, end = '')
    print('')

row = 6
for i in range(row):
    for j in range(i):
        print(i, end = '')
    print('')
    
row = 6
for i in range(row):
    for j in range(i):
        print(i, end = '')
    print('')
    
