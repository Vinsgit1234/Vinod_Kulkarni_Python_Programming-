L = [10,20,52,255 ]
b = bytes (L)
print ("Type of L ", type(b))
M = [10,20,52,256]
c = bytes(M)
print ("Type of M = " , type (c))

L = [ 10,20,52,255 ]
b = bytes (L)
print ("Type of L ", type (b) )
M = [10,20,52,256]
c = bytes (M)
print ("Type of M = " , type (c))

L = [10,20,52,255]
b = bytes (L)
print ("Type of L ", type (b))
M = [10.20,52,256]
c = bytes (M)
print ("Type of M =", type (c))

L = [10,20,52,255]
b = bytes (L)
print ("Type of L", type (b))
M = [10,20,52,256]
print ("Type of M=",type (c))

