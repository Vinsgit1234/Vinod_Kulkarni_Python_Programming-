a = 1.79e308 
print ("Value of a : ", a)
b = 1.8e308 
print ("Value of b : ", b)

a = 1.79e308 
print ("Value of a : ", a)
b = 1.8e308
print("Value of b : ", b)

a = 1.79e308 
print ("Value of a : ", a)
b = 1.8e308 
print ("Value of b : ", b)


a = 1.79e308 
print ("Value of a :" , a)
b = 1.8e308 
print  ("Value of b : ", b)

