def check(n):
    x = int(n)%2
    if x == 0:
        print("The Number is Even")
    else:
        print("The Number is Odd")
        
def check(n):
    x = int(n)%2
    if x == 0:
        print("The Number is Even")
    else:
        print("The Number is Odd")
        
def check(n):
    x = int(n)%2
    if x == 0:
        print("The Number is Even")
    else:
        print("The Number is Odd")
        
def check(n):
    x = int(n)%2
    if x == 0:
        print("The Number is Even")
    else:
        print("The Number is Odd")
        
