i = int
for i in range(0,100):
    if i%2==0:
        print("The Given Number is ",i ,"Even")
    else:
        print("The Given Number is ",i ,"Odd")
        
        
        
    