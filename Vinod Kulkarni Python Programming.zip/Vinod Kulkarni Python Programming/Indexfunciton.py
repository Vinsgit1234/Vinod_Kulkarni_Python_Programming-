Tuple = (5,8,10,20,10,40,50)
print("Index of the First Occurence of 10=",Tuple.index(10))
print("Index of the first Occurence of 10 = ",Tuple.index(1))

Tuple = (5,8,10,20,10,40,50)
print("Index of the First Occurence of 10=",Tuple.index(10))
print("Index of the first Occurence of 10 = ",Tuple.index(1))

Tuple = (5,8,10,20,10,40,50)
print("Index of the First Occurence of 10=",Tuple.index(10))
print("Index of the first Occurence of 10=",Tuple.index(1))

Tuple = (5,8,10,20,10,40,50)
print("Index of the First Occurance of 10=",Tuple.index(10))
print("Index of the First Occurence of 10=",Tuple.index(1))

Tuple = (5,8,10,20,10,40,50)
print("Index of the First Occurance of 10=",Tuple.index(10))
print("Index of the First Occurance of 10=",Tuple.index(10))



