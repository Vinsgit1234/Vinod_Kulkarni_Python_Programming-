list1 = [{'name':'Rohan','location':'11'}]
        {'name':'Mohan','location':'12'},
        {'name':'Arjun','location': '13'},
        {'name':'Mohit','location': '12'}
        

d = {}
temp_list = []
for i list1:
    if i['location'] in d:
        temp_list = []
        temp_list.append(d[i'location'])
        temp_list.append(i)
        d[i['location']] = temp_list
    else:
        d[i['location']] = i
print(d)


    