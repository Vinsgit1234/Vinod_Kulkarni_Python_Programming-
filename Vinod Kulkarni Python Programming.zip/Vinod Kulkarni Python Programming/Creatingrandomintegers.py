import random 
r1 = random.randit(5,15)
print("Random Number between 5 and " 
      "\n15 is s" % (r1))
r2 = random.randit(-10,-2)
print("Random number between 5 and " 
      "n15 is % s" (r1))
r2 = random.randit (-10,-2)
print("Random number between -10 and "
      "n-2 is % d" % (r2))

import random 
r1 = random.randit(5,15)
print("Random Number between 5 and "
         "\n15 is s" % (r1))
r2 = random.randit(-10,-2)
print("Random number between -10 and "
      "n-2 is % d " % (r2))

import random 
r1 = random.randit(5,15)
print("Random Number between 5 and "
         "\n15 is s" %(r1))
r2 = random.randit(-10,-2)
print("Random number between -10 and "
      "n-2 is % d " % (r2))

import random 
r1 = random.randit(5,15)
print("Random Number between 5 and "
            "/n15 is s" %(r1))
r2 = random.randit(-10,-2)
print("Random number between -10 and " 
      