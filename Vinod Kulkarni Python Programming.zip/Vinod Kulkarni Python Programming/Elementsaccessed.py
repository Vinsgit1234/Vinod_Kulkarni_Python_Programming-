n = ['apple','banana','grapes','orange','mint']
print("Element at 0th index",a[0])
print("Element at 2nd index ", a[2])
print("Elements at 4th index",a[4])
print("Elements at -1 index",a[-1])
print("Element at -2 index",a[-2])
print("Element at -5 index",a[-5])

n = ['apple','banana','grapes','orange','mint']
print("Element at 0th index",a[0])
print("Element at 2nd index ", a[2])
print("Elements at 4th index",a[4])
print("Elements at -1 index",a[-1])
print("Element at -2 index",a[-2])
print("Element at -5 index",a[-5])

n = ['apple','banana','grapes','orange','mint']
print("Element at 0th index",a[0])
print("Element at 2nd index ", a[2])
print("Elements at 4th index",a[4])
print("Elements at -1 index",a[-1])
print("Element at -2 index",a[-2])
print("Element at -5 index",a[-5])



