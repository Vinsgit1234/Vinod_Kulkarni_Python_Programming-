import main as M 
print(M,x)
print(M,y)
M.add(50,60)
M.product(45,4)

import main as M 
print(M,x)
print(M,y)
M.add(50,60)
M.product(45,4)

import main as M 
print(M,x)
print(M,y)
M.add(50,60)
M.product(45,4)

import main as M 
print(M,x)
print(M,y)
M.add(50,60)
M.product(45,4)

import main as M 
print(M,x)
print(M,y)
M.add(50,60)
M.product(45,4)

import main as M 
print(M,x)
print(M,y)
M.add(50,60)
M.add(50,60)
M.product(45,4)

import main as M 
print(M,x)
print(M,y)
M.add(50,60)
M.add(50,60)
M.product(45,4)

import main as M 
print(M,x)
print(M,y)
M.add(50,60)
M.add(50,60)
M.product(45,4)

