s = 'hello'
print(s.islower())

s = 'hello'
print(s.islower())

s = 'hello'
print(s.islower())

